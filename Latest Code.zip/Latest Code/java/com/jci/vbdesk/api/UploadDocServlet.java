package com.jci.vbdesk.api;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.json.JSONObject;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;


import com.jci.vbdesk.Service;

/**
 * Servlet implementation class UploadDocServlet
 */
@WebServlet(urlPatterns = "/api/UploadDocServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      	// 50 MB
maxRequestSize=1024*1024*100)
public class UploadDocServlet extends HttpServlet {
	
	private Logger logger = Logger.getLogger(getClass().getName());

	private Service service = Service.getInstance();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject response = new JSONObject();
		System.out.println("Upload servlet reached.....");
		JSONObject order_docid = new JSONObject(request.getParameter("id"));
	    System.out.println("Content Type::::"+request.getContentType());
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        InputStream filecontent = null;
        Object result=null;
                 
        for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            System.out.println("File Name ::"+fileName);
            
            filecontent = part.getInputStream();
            int read = 0;
            final byte[] data = new byte[1024];

            while ((read = filecontent.read(data)) != -1) {
                           buffer.write(data, 0, read);
            }
            buffer.flush();
            byte[] byteArray = buffer.toByteArray();

            if (fileName != null && fileName != "" ) {
            //fileName = new File(fileName).getName();
            System.out.println("File Name ::"+fileName);
            //result = service.uploadDoc(fileName, order_docid);
            result = service.uploadDoc(byteArray, order_docid, fileName);
            System.out.println("UploadDocument Resulet:::"+result);
            }
            response.put("result", result != null ? result : JSONObject.NULL);
           
        }
      
        
    	resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();

	
        }     
	    
		    private String extractFileName(Part part) {
		        String contentDisp = part.getHeader("content-disposition");
		        String[] items = contentDisp.split(";");
		        for (String s : items) {
		        	System.out.println("FileName:::"+s);
		            if (s.trim().startsWith("filename")) {
		                return s.substring(s.indexOf("=") + 2, s.length()-1);
		            }
		        }
		        return "";
		    }
	
	}



package com.jci.vbdesk.api;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jci.vbdesk.Service;

/*import com.jci.vbdesk.ServiceImpl;*/
import com.jci.vbdesk.model.Order;

import com.jci.vbdesk.Database;

@WebServlet(urlPatterns = "/api/search_orders")
public class SearchOrdersServlet extends HttpServlet {
	private Logger logger = Logger.getLogger(getClass().getName());

	//private Service service = Service.getInstance();

	private Database db = Database.getInstance();
	
	String name = "VBDesk_AccessPrivilege.txt";
	
 	String[] privilege_value = null;
 	String[] users = null;
 	String line;
 	
 	String AccessGroup = null,user = null;
	
 	int i=0,j=0;
 	
 	

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			
			
			
			BufferedReader br=new BufferedReader(new FileReader("d:/"+name));
			
			
			Order orders = new Order();
			JSONObject response = new JSONObject();

			System.out.println("CustomerName::"+req.getParameter("customer_name"));
			
			orders.setCustomername(req.getParameter("customer_name"));
			orders.setOrdernumber(req.getParameter("order_number"));
			orders.setPonumber(req.getParameter("po_number"));
			orders.setAssignee(req.getParameter("order_assigned_to"));
			System.out.println("Assignee from Servlet"+req.getParameter("order_assigned_to"));
			
			orders.setCreationdatefrom(req.getParameter("creation_date_from"));
			orders.setCreationdateto(req.getParameter("creation_date_to"));
			orders.setRequestedshipdatefrom(req.getParameter("requested_ship_date_from"));
			orders.setRequestedshipdateto(req.getParameter("requested_ship_date_to"));
			orders.setExpectedshipdatefrom(req.getParameter("expected_ship_date_from"));
			orders.setExpectedshipdateto(req.getParameter("expected_ship_date_to"));
			orders.setConfirmedshipdatefrom(req.getParameter("confirmed_ship_date_from"));
			orders.setConfirmedshipdateto(req.getParameter("confirmed_ship_date_to"));
			orders.setActualshipdatefrom(req.getParameter("actual_ship_date_from"));
			orders.setActualshipdateto(req.getParameter("actual_ship_date_to"));
			orders.setDeliverydatefrom(req.getParameter("delivery_date_from"));
			orders.setDeliverydateto(req.getParameter("delivery_date_to"));
			orders.setOrderstatus(req.getParameter("order_status"));
			
			orders.setCustomeruser(req.getParameter("buyer_name"));
			
			//Logged-in user information from Waffle ( Native Windows Authentication Framework  )
			String username=req.getRemoteUser();
			System.out.println("Users :::"+username);
			orders.setRemoteUser(username);
			
			whileloop:
			while( (line = br.readLine() ) != null) {
			    privilege_value=line.split(":");
			    
			    for( i=0; i<privilege_value.length; i++)
				{
			    	users = privilege_value[1].split(";");
			    	for(j=0;j<users.length;j++)
			    	{
			    		if(username.equalsIgnoreCase(users[j]))
			    		{
			    			AccessGroup=privilege_value[i];
			    			user=users[j];
			    			break whileloop;
			    		}
			    	}
			    	
						
				}
				

			}
			
		
			try {
			
			Object result = db.getOrderByFilters(orders.getCustomername(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
					orders.getCreationdateto(), orders.getRequestedshipdatefrom(), orders.getRequestedshipdateto(),
					orders.getExpectedshipdatefrom(), orders.getExpectedshipdateto(),
					orders.getConfirmedshipdatefrom(), orders.getConfirmedshipdateto(),
					orders.getActualshipdatefrom(), orders.getActualshipdateto(),
					orders.getDeliverydatefrom(), orders.getDeliverydateto(),
					orders.getOrderstatus(), orders.getCustomeruser()) ;
			
			System.out.println(":::::::::"+result.toString());
			response.put("result", result != null ? result : JSONObject.NULL);
			response.put("user", username);
			response.put("AccessGroup", AccessGroup);
			
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
			response.put("error", e.getMessage());
		
		}
		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
	}
}

package com.jci.vbdesk.api;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jci.vbdesk.Service;

@WebServlet(urlPatterns = "/api/create_order")
public class CreateOrderServlet extends HttpServlet {
	private Logger logger = Logger.getLogger(getClass().getName());

	private Service service = Service.getInstance();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject response = new JSONObject();

		try {
			System.out.println("Printing Item from Save Servlet:::"+req.getParameter("item"));
			JSONObject order = new JSONObject(req.getParameter("item"));
			Object result = service.createOrder(order);
			System.out.println("Printing Result:::"+result);
			response.put("result", result != null ? result : JSONObject.NULL);
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
			response.put("error", e.getMessage());
		}

		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}

package com.jci.vbdesk.api;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Map;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.jci.vbdesk.Database;
import com.jci.vbdesk.Service;


import com.mongodb.client.gridfs.model.GridFSFile;
import com.mongodb.gridfs.GridFSDBFile;

/**
 * Servlet implementation class DownloadServlet
 */
@WebServlet(urlPatterns = "/api/downloadDoc")
public class DownloadServlet extends HttpServlet {
	
  
	private Logger logger = Logger.getLogger(getClass().getName());

	private Service service = Service.getInstance();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject response = new JSONObject();
		
		System.out.println("Download servlet reached.......");
		
		BufferedInputStream bis = null;

		ServletOutputStream stream = null;
		
		 
		
		//JSONObject order_docid = new JSONObject(request.getParameter("id"));
		//System.out.println("ID for Download document::::::"+request.getParameter("id"));

		try {

			//String fileIdMongo = "5996bead0709bf20583c9d15";
			String fileIdMongo = request.getParameter("id");
			Map<GridFSFile, byte[]> downloadMap = service.DownloaDocument(fileIdMongo);

			byte[] byteArray = null;
			GridFSFile downloadFile = null;
			
			
		

			for (GridFSFile key : downloadMap.keySet()) {

				downloadFile = key;
				
			
				byteArray = downloadMap.get(key);
				System.out.println("Download MAP KEY::::"+downloadMap.get(key).toString());
			}
		
		
			
			stream = resp.getOutputStream();
			
			
		/*	String value = "attachment;filename=\"" + URLEncoder.encode(downloadFile.getFilename(), "UTF-8") +'"';
			resp.setContentType("application/x-www-form-urlencoded");
			resp.setHeader("Content-disposition", value);*/
			
			String headerKey = "Content-Disposition";
			resp.addHeader("Content-Type", "*/*");
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getFilename());
			resp.setContentType("application/octet-stream");
			resp.setHeader(headerKey, headerValue);

			
            //resp.addHeader("Content-Disposition", "attachment; filename=" + downloadFile.getFilename());
			
		
			stream.write(byteArray);
			
			System.out.println("Downloaded File Details::::"+ downloadFile.getFilename());
			
			System.out.println("File Contents::::"+stream.toString());

		} catch (IOException ioe) {

			throw new ServletException(ioe);

		} finally {

			if (stream != null)
				stream.close();
			if (bis != null)
				bis.close();

		}
		
	/*	resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();*/
	}
}


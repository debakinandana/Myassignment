package com.jci.vbdesk.api;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.json.JSONObject;

import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbFile;



//@WebServlet("/UploadServlet")
@WebServlet(urlPatterns = "/UploadServlet")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class UploadServlet extends HttpServlet {
	private Logger logger = Logger.getLogger(getClass().getName());
    /**
     * Name of the directory where uploaded files will be saved, relative to
     * the web application directory.
     */
	private static final String SAVE_DIR = "uploadFiles";
	
	private static final String user = "user:password";
    
    /**
     * handles file upload
     */
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        // gets absolute path of the web application
    	System.out.println("UploadServlet POST:::;");
    	
        String appPath = request.getServletContext().getRealPath("");
    	
        System.out.println("AppPath::"+appPath);
        // constructs path of the directory to save uploaded file
        String savePath = appPath + File.separator + SAVE_DIR;
        System.out.println("savePath::"+savePath);
        // creates the save directory if it does not exists
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();
        }
         
        for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            System.out.println("File Contents"+part.getContentType()+"File Separator::"+File.separator);
            // refines the fileName in case it is an absolute path
            fileName = new File(fileName).getName();
            part.write(savePath + File.separator + fileName);
        }
      
    }
    /**
     * Extracts file name from HTTP header content-disposition
     */
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }


	/*@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		JSONObject response = new JSONObject();

		try {
			logger.log(Level.INFO,"Save Servlet is called");
			JSONObject order = new JSONObject(req.getParameter("item"));
			
			logger.log(Level.INFO,"Save Servlet is processing"+req.getParameter("item"));
			logger.log(Level.INFO,order.getString("order_number"));
			Object result = UploadServlet.uploadFile(order);
     		response.put("result", result != null ? result : JSONObject.NULL);
		} catch (Exception e) {
			logger.log(Level.WARNING, null, e);
			response.put("error", e.getMessage());
		}

		resp.setContentType("application/json");
		resp.setCharacterEncoding("UTF-8");
		resp.addDateHeader("Expires", 0);
		PrintWriter pw = resp.getWriter();
		response.write(pw);
		pw.close();
	}
	private static Object uploadFile(JSONObject order) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	

}
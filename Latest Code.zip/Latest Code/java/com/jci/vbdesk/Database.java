package com.jci.vbdesk;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Part;

import org.apache.commons.lang3.StringUtils;
import org.bson.BSONObject;
import org.bson.BasicBSONObject;
import org.bson.BsonObjectId;
import org.bson.BsonString;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jci.vbdesk.model.Order;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.DB;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
import com.mongodb.client.model.Filters;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

import com.mongodb.client.gridfs.*;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.mongodb.client.gridfs.model.GridFSUploadOptions;

public class Database {

	private static Database instance = new Database();

	public static Database getInstance() {
		return instance;
	}
	
	
	private MongoClient mongoClient = new MongoClient("127.0.0.1");
	
	//private MongoClient mongoClient = new MongoClient("c700m079.cg.eu.jci.com");

	private MongoDatabase database = mongoClient.getDatabase("VBDesk");
	
	
	//private String FILE_DIR="d:\\Temp\\";
    
	


	private MongoCollection<Document> collection = database.getCollection("Orders_VB");
	private MongoCollection<Document> filecollection = database.getCollection("VB_Files");
	
	public JSONObject getOrder(String id) {
		System.out.println("Get Order By Id method......");
		Bson filter = Filters.eq("_id", id);
		JSONArray array = new JSONArray();
		collection.find(filter).forEach(new Block<Document>() {
			@Override
			public void apply(Document orderDoc) {
				System.out.println("Printing OrderDoc from Get Order Method ::"+orderDoc);
				JSONObject orderJson = new JSONObject(orderDoc.toJson());
				String id = orderJson.getString("_id");
				orderJson.remove("_id");
				orderJson.put("id", id);
				array.put(orderJson);
				System.out.println("Printing OrderJSON from Get Order Method ::"+orderJson);
			}
			
		});
		return array.length() != 0 ? array.getJSONObject(0) : null;
	}
	
/*	public JSONArray getOrderByFilters(String customernumber,String ordernumber, String ponumber, String assignee, Date creationdatefrom, Date creationdateto,
			Date requesteddelivdatefrom, Date requesteddelivdateto, Date expecteddelivdatefrom, Date expecteddelivdateto, 
			Date confirmeddelivdatefrom, Date confirmeddelivdateto, Date actualdelivdatefrom, Date actualdelivdateto,
			String orderstatus, String customeruser) {*/
		
		public JSONArray getOrderByFilters(String customername, String ordernumber, String ponumber, String assignee,
				String creationdatefrom, String creationdateto,
				String requestedshipdatefrom, String requestedshipdateto,
				String expectedshipdatefrom, String expectedshipdateto,
				String confirmedshipdatefrom, String confirmedshipdateto,
				String actualshipdatefrom, String actualshipdateto,
				String deliverydatefrom, String deliverydateto,
				String orderstatus, String customeruser) {
		
			
		List<Bson> filters = new ArrayList<>();

		String status="DELETED";
		if (StringUtils.isNotBlank(customername)) {
			System.out.println("Searching for Customer_name"+customername);
		
			filters.add(Filters.regex("customer_name", customername, "i"));
		}
		if (StringUtils.isNotBlank(ordernumber)) {
			filters.add(Filters.regex("order_number", ordernumber));
		}
		if (StringUtils.isNotBlank(ponumber)) {
			filters.add(Filters.regex("po_number", ponumber, "i"));
		}
		System.out.println("Assignee::"+assignee);
		if (StringUtils.isNotBlank(assignee)) {
			System.out.println("Assignee::"+assignee);
			filters.add(Filters.regex("order_assignee", assignee, "i"));
		}
		
		if (StringUtils.isNotBlank(creationdatefrom) && StringUtils.isNotBlank(creationdateto)) {
			filters.add(new BasicDBObject("order_date",
					new BasicDBObject("$gte", creationdatefrom)
							.append("$lt", creationdateto)));
		}
	    if (StringUtils.isNotBlank(requestedshipdatefrom) && StringUtils.isNotBlank(requestedshipdateto)) {
			filters.add(new BasicDBObject("requested_order_ship_date",
					new BasicDBObject("$gte", requestedshipdatefrom)
							.append("$lt", requestedshipdateto)));
		}
		if (StringUtils.isNotBlank(expectedshipdatefrom) && StringUtils.isNotBlank(expectedshipdateto)) {
			filters.add(new BasicDBObject("order_ship_date",
					new BasicDBObject("$gte", expectedshipdatefrom)
							.append("$lt", expectedshipdateto)));
		}
		if (StringUtils.isNotBlank(confirmedshipdatefrom) && StringUtils.isNotBlank(confirmedshipdateto)) {
			filters.add(new BasicDBObject("confirmed_ship_date",
					new BasicDBObject("$gte", confirmedshipdatefrom)
							.append("$lt", confirmedshipdateto)));
		}
		if (StringUtils.isNotBlank(actualshipdatefrom) && StringUtils.isNotBlank(actualshipdateto)) {
			filters.add(new BasicDBObject("actual_ship_date",
					new BasicDBObject("$gte", actualshipdatefrom)
							.append("$lt", actualshipdateto)));
		}
		
		if (StringUtils.isNotBlank(deliverydatefrom) && StringUtils.isNotBlank(deliverydateto)) {
			filters.add(new BasicDBObject("delivery_date",
					new BasicDBObject("$gte", deliverydatefrom)
								.append("$lt", deliverydateto)));	
		
		}
		if (StringUtils.isNotBlank(orderstatus)) {
			filters.add(Filters.regex("order_status", orderstatus, "i"));
			//filters.add(Filters.ne("order_status", status));
		}
		else
		{
			filters.add(Filters.ne("order_status", status));
		}
		if (StringUtils.isNotBlank(customeruser)) {
			filters.add(Filters.regex("buyer_name", customeruser,"i"));
		
		}
		
	
		
		
		
		Bson filter = filters.size() > 0 ? Filters.and(filters) : new Document();
		JSONArray array = new JSONArray();
		System.out.println("Display Filter ::"+filter);
		collection.find(filter).forEach(new Block<Document>() {
			@Override
			public void apply(Document orderDoc) {
				System.out.println("Printing OrderDoc::"+orderDoc.toString());
				JSONObject orderJson = new JSONObject(orderDoc.toJson());
				System.out.println("Printing _ID::"+orderJson.getString("_id"));
				String id = orderJson.getString("_id");
				orderJson.remove("_id");
				orderJson.put("id", id);
				array.put(orderJson);
				System.out.println("Printing OrderJSON ::"+orderJson);
			}
		});
		return array;

}
		
		public void insertOrder(JSONObject orderJson) {
			Document orderDoc = Document.parse(orderJson.toString());
			String id = orderDoc.getString("id");
			//String id="D-693432";
			orderDoc.remove("id");
			orderDoc.put("_id", id);
			collection.insertOne(orderDoc);
		}
		
		public void updateOrder(JSONObject orderJson) {
			Bson filter = Filters.eq("_id", orderJson.getString("id"));
			System.out.println("Order ID:::"+filter);
			Document orderDoc = Document.parse(orderJson.toString());
			System.out.println("Printing OrderDoc:::"+orderDoc);
			String id = orderDoc.getString("id");
			System.out.println("String ID:::"+id);
			orderDoc.remove("id");
			orderDoc.put("_id", id);
			collection.replaceOne(filter, orderDoc);
		}
		
		public String generateOrderNumber() {
	        String newOrderNumber = null;
	       // String vbordernumber="1000000";
	        Bson filter = Filters.eq("_id", "vbordernumber");
	        MongoIterable<Document> orderCounters = database.getCollection("Order_Counter").find(filter);
	        Document orderCounter = orderCounters.first();
	        JSONObject orderJson = new JSONObject(orderCounter.toJson());
	        long lastOrderNumber = Long.valueOf(orderJson.getString("order_count"));
	        newOrderNumber = String.valueOf(lastOrderNumber+1);
	        orderCounter.put("order_count", newOrderNumber);
	        database.getCollection("Order_Counter")
	                     .replaceOne(filter, orderCounter);
	        return newOrderNumber;

	 } 
		
		
		public BsonObjectId uploadDocument(byte[] byteArray, JSONObject order_docid, String fileName) throws FileNotFoundException
		{	
				System.out.println("Printing UUID for Upload Document::"+order_docid);
				GridFSBucket gridFSFilesBucket = GridFSBuckets.create(database, "VB_Files");
			  	//InputStream streamToUploadFrom = new FileInputStream(new File("C:\\Users\\10609420\\Desktop\\screenshot\\Capture.png"));
				
				//String path=FILE_DIR.concat(byteArray);
				//ystem.out.println"Final Path::"+path);
			  	
				//InputStream streamToUploadFrom = new FileInputStream(new File(path));
			  	
				InputStream streamToUploadFrom = new ByteArrayInputStream(byteArray);
				
				GridFSUploadOptions options = new GridFSUploadOptions()
                        .chunkSizeBytes(358400)
                        .metadata(new Document("type", "presentation"));
			   
			  	
			  	//ObjectId fileId = gridFSFilesBucket.uploadFromStream(file, streamToUploadFrom, options);
			  	//BsonString bs=new BsonString(order_docid.getString("file_id"));
					
				ObjectId obj_id=new ObjectId(order_docid.getString("file_id"));
				BsonObjectId bson_obj_id=new BsonObjectId(obj_id);
				  	
			  	System.out.println("BsonValue:::"+bson_obj_id);
			  	
			 // method for Upload documents in mongodb GridFSBucket with custom id (BSONValue type)
			  	gridFSFilesBucket.uploadFromStream(	bson_obj_id , fileName, streamToUploadFrom,  options);  
			               
	           
	            //return bs;
	            return bson_obj_id;
			
		}
		
	
		
		public Map<GridFSFile, byte[]> downloadDocument(String fileIdMongo) throws FileNotFoundException {
			ObjectId fileObjectId = new ObjectId(fileIdMongo);

			GridFSBucket gridFSFilesBucket = GridFSBuckets.create(database, "VB_Files");

            Map<GridFSFile, byte[] > downloadMap = new HashMap<GridFSFile, byte[] >();
            
            //GridFSFile fileToDownload = gridFSFilesBucket.find(Filters.eq("_id", fileObjectId)).first();

            ByteArrayOutputStream byteOutput = new ByteArrayOutputStream(16777216);
            
            //BsonObjectId bson_obj_id=new BsonObjectId(fileObjectId);
            //GridFSDBFile fileToDownload = (GridFSDBFile) filecollection.find(fileObjectId);
            
            
            GridFSFile fileToDownload = gridFSFilesBucket.find(Filters.eq("_id", fileObjectId)).first();
              		
            //OutputStream bOutput = new FileOutputStream("d:\\img\\Fields in Order.docx");
            //gridFSFilesBucket.downloadToStream(fileObjectId, bOutput);
            gridFSFilesBucket.downloadToStream(fileObjectId, byteOutput);
          

            byte[] bytesToWriteTo = byteOutput.toByteArray();
                
            downloadMap.put(fileToDownload, bytesToWriteTo);
            
            System.out.println("Download MAP:::::"+downloadMap.values());
            
            return downloadMap;

		}


		
}

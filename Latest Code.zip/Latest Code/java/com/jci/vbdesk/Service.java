package com.jci.vbdesk;



import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import org.bson.BsonObjectId;
import org.bson.BsonString;
import org.bson.types.ObjectId;
import org.json.JSONArray;
import org.json.JSONObject;

import com.jci.vbdesk.model.Order;
import com.mongodb.client.gridfs.model.GridFSFile;

public class Service {
	private static Service instance = new Service();
	
	private static String buildRandomString() {
		StringBuffer sb = new StringBuffer();
		int i = 5 + (int) (5 * Math.random());
		for (int j = 0; j < i; j++) {
			sb.append((char) ('A' + (int) (26 * Math.random())));
		}
		return sb.toString();
	}
	
	public static Service getInstance() {
		return instance;
	}

	private Database database = Database.getInstance();

	public Service() {
	}
	
	/*public JSONArray getOrderByFilters(String customernumber, String ordernumber, String ponumber, String assignee,
			String creationdatefrom, String creationdateto,
			String requesteddelivdatefrom, String requesteddelivdateto,
			String expecteddelivdatefrom, String expecteddelivdateto,
			String confirmeddelivdatefrom, String confirmeddelivdateto,
			String actualdelivdatefrom, String actualdelivdateto,
			String orderstatus, String customeruser) {
		Order orders = new Order();
		return database.getOrderByFilters(orders.getCustomername(),orders.getOrdernumber(),orders.getPonumber(),orders.getAssignee(), orders.getCreationdatefrom(),
				orders.getCreationdateto(), orders.getRequesteddelivdatefrom(), orders.getRequesteddelivdateto(),
				orders.getExpecteddelivdatefrom(), orders.getExpecteddelivdateto(),
				orders.getConfirmeddelivdatefrom(), orders.getConfirmeddelivdateto(),
				orders.getActualdelivdatefrom(), orders.getActualdelivdateto(),
				orders.getOrderstatus(), orders.getCustomeruser());
	}*/
	
	/*public JSONObject createOrder() {
		JSONObject order = new JSONObject();
		order.put("id", UUID.randomUUID().toString());

		order.put("jci_order_number", buildRandomString());
		order.put("order_status", buildRandomString());
		order.put("customer_number", buildRandomString());
		order.put("customer_order_number", buildRandomString());

		order.put("billing_address_name", buildRandomString());
		order.put("billing_address_street", buildRandomString());
		order.put("billing_address_city", buildRandomString());
		order.put("billing_address_state", buildRandomString());
		order.put("billing_address_zip", buildRandomString());
		order.put("billing_address_country", buildRandomString());

		order.put("shipping_address_name", buildRandomString());
		order.put("shipping_address_street", buildRandomString());
		order.put("shipping_address_city", buildRandomString());
		order.put("shipping_address_state", buildRandomString());
		order.put("shipping_address_zip", buildRandomString());
		order.put("shipping_address_country", buildRandomString());

		JSONArray order_items = new JSONArray();
		int i = 5 + (int) (5 * Math.random());
		for (int j = 0; j < i; j++) {
			JSONObject line = new JSONObject();
			line.put("id", UUID.randomUUID().toString());
			line.put("line_number", j + 1);
			line.put("product_code", buildRandomString());
			line.put("description", buildRandomString());
			line.put("quantity", 1);
			line.put("delivery_date", "2017-10-01");
			line.put("unit_price", 2);
			line.put("line_price", 2);
			order_items.put(line);
		}
		order.put("order_items", order_items);

		database.insertOrder(order);
		return getOrder(order.getString("id"));
	}
*/	
	public JSONObject getOrder(String id) {
		return database.getOrder(id);
	}
	
	public JSONObject createOrder(JSONObject order)
	{
		order.put("id", UUID.randomUUID().toString());
		order.put("order_number", database.generateOrderNumber());
		database.insertOrder(order);
		return getOrder(order.getString("id"));
	}
	
	public JSONObject saveOrder(JSONObject order) {
		database.updateOrder(order);
		return getOrder(order.getString("id"));
	}
	
	public String getOrderNumber()
	{
		return database.generateOrderNumber();
	}
	
	public BsonObjectId uploadDoc(byte[] byteArray, JSONObject order_docid, String fileName) throws FileNotFoundException
	{
		 
		 return database.uploadDocument(byteArray, order_docid, fileName);
	}
	
/*	public BsonObjectId uploadDoc(String fileName, JSONObject order_doc_id) throws FileNotFoundException
	{
		 
		return database.uploadDocument(fileName,order_doc_id);
	}*/

	
	public Map<GridFSFile, byte[]> DownloaDocument(String fileIdMongo) throws FileNotFoundException {
			// TODO Auto-generated method stub
		return database.downloadDocument(fileIdMongo);
	}
	
}
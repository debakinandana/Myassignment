/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import './footer.css';

class Footer extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (
			<footer className="footer text-center text-muted text-uppercase">
				<p>© 2017 Johnson Controls. All rights reserved.</p>
			</footer>
		);
	}
}

export default Footer;

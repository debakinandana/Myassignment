/* global $ b:true 
 global ajax b:true 
 global google b:true 

import React, { Component } from 'react';
import './h1.css';

class H1 extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (<h1 className="h1">{ this.props.title }</h1>);
	}
}

export default H1;*/
/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import Breadcrumb from 'react-bootstrap/lib/Breadcrumb';
import BreadcrumbItem from 'react-bootstrap/lib/BreadcrumbItem';


import './h1.css';


class H1 extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		return (<h4><Breadcrumb> <BreadcrumbItem active> { this.props.title } </BreadcrumbItem> </Breadcrumb> </h4>) ;	
	}
}

export default H1;

/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';

class Layout extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}
	render() {
		return (
			<div>
				<div className="container-fluid">
					<div className="row">
						<div className="col-sm-12">
							{ this.props.header }
						</div>
					</div>
					<div className="row">
						<div className="col-sm-12">
						{ this.props.center }
						</div>
					</div>
					<div className="row">
						<div className="col-sm-12">
							{ this.props.left }
						</div>
						
					</div>
			
					<div className="row">
						<div className="col-sm-12">
							{ this.props.footer }
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export default Layout;

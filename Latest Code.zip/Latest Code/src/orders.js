/* global $ b:true */
/* global ajax b:true */
/* global google b:true */

import React, { Component } from 'react';
import Moment from 'react-moment'; 


import moment from 'moment';
import 'moment-timezone';
import '/table.css';
import DeleteConfirm from 'react-delete-confirm';
import ReactConfirmAlert, { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css'

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import RaisedButton from 'material-ui/RaisedButton';
import Dropzone from 'react-dropzone';
import FontIcon from 'material-ui/FontIcon';
import {blue500, red500, greenA200} from 'material-ui/styles/colors';


import request from 'superagent'; 

import uuidv4 from 'uuid/v4';

const customStyles = {
		  content : {
		    top                   : '50%',
		    left                  : '50%',
		    right                 : 'auto',
		    bottom                : 'auto',
		    marginRight           : '-50%',
		    transform             : 'translate(-50%, -50%)'
		  }
		};


class Orders extends React.Component {
	constructor(props) {
		super(props);
		this.close = this.close.bind(this);
		this.create = this.create.bind(this);
		this.open = this.open.bind(this);
		this.save = this.save.bind(this);
		this.search = this.search.bind(this);
		// this.firstcall=1;
		this.search({});
	}

	close() {
		this.search({});
	}

	create(item) {
		ajax({
			url: 'api/create_order',
			method: 'POST',
			data: {
				item: JSON.stringify(item)
			}
		}, (data) => {
			if (data.error == null) {
				//this.search({});
			} else {
				alert(data.error);
			}
		});
	}

	open(id) {
		
		ajax({
			url: 'api/get_order',
			method: 'GET',
			data: {
				id: id
			}
		}, (data) => {
			if (data.error == null) {
				this.setState({ view: 'Details', item: data.result });
			} else {
				alert(data.error);
			}
		});
	}

	save(item) {
		ajax({
			url: 'api/save_order',
			method: 'POST',
			data: {
				item: JSON.stringify(item)
			}
		
		}, (data) => {
			if (data.error == null) {
				confirmAlert({
					message: 'Order has been saved successfully', 
					confirmLabel: 'Ok', 
				})
				//this.search({});
			} else {
				alert(data.error);
			}
		});
	}

	
	search(data) {
		this.state  = { view: 'Search', results: [] };
				
		ajax({
			url: 'api/search_orders',
			method: 'GET',
			data: data
			}, (data) => {
				if (data.error == null) {
					this.setState({ results: data.result, user: data.user, AccessGroup: data.AccessGroup });
										
				}else {
					
					alert(data.error);
				}
				
			});
		
	}
	
		
	render() {
		
		if (this.state.view == 'Search') return (<div class="mr-auto"> User : {this.state.user} Group : {this.state.AccessGroup} <SearchForm  search={ this.search }   /><SearchResults results={ this.state.results } open={ this.open }  /></div>);
		if (this.state.view == 'Details') return (<Details item={ this.state.item } close={ this.close } save={ this.save } create={ this.create } upload={ this.upload } user={this.state.user}  group={this.state.AccessGroup}/>);
	
	}
}

class SearchForm extends React.Component {
	constructor(props) {
		super(props);
		this.handleCreate = this.handleCreate.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleSearch = this.handleSearch.bind(this);
		this.order_assigned_to= this.order_assigned_to.bind(this);
		this.orders_status=this.orders_status.bind(this);
		this.handleactiondate=this.handleactiondate.bind(this);
		this.state = { 		};
	}
	
	handleCreate(e) {
		e.preventDefault();
		this.props.create();
	}

	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		this.setState({ [name]: value });
		
	}
	
	handleClear() {
		this.refs.inputTitle.value="";
		this.refs.inputEntry.value="";
		this.refs.someName.value = '';
		}
	
	validateEmail(value) {
	    var re = null;
	    return re.test(value);
	    alert('!Required')
	  }
	
	order_assigned_to(event) {
	    this.setState({order_assigned_to: event.target.value});
	  }
	orders_status(event) {
		this.setState({order_status: event.target.value});
	}
	
	handleactiondate(e){
		
		this.setState({action:e.target.value});
		
	}


	handleSearch(e) {
			e.preventDefault();
			this.props.search(this.state);
	}
	    
	
	handlePageChange(pageNumber) {
	    console.log(`active page is ${pageNumber}`);
	    this.setState({activePage: pageNumber});
	  }
	
	actionDatefield()
	{
		if(this.state.action == "Creation Date")
		{ return (<form className="form-horizontal"><div className="form-group">
		<label for="creation_date_from" className="col-sm-2 control-label">Creation Date From</label>
		<div className="col-md-3">
		<input id="txtDate" name="creation_date_from" type="date"  value={ this.state.creation_date_from } max={moment().format("DD-MMM-YYYY")} className="form-control" onChange= { this.handleInputChange} />		
		</div>
		<label for="creation_date_to" className="col-sm-2 control-label">To</label>
		<div className="col-md-3">
		<input  name="creation_date_to" type="date" value={ this.state.creation_date_to } min={ this.state.creation_date_from }
		className="form-control" onChange={ this.handleInputChange } />
		</div></div></form> );}
		
		if(this.state.action == "Requested Ship_Date")
		{ return (<form className="form-horizontal"><div className="form-group">
		<label for="requested_ship_date_from" className="col-sm-2 control-label">Requested ship date from</label>
		<div className="col-md-3">
		<input id="txtDate" name="requested_ship_date_from" type="date"  value={ this.state.requested_ship_date_from } max={moment().format("DD-MMM-YYYY")} className="form-control" onChange= { this.handleInputChange} />		
		</div>
		<label for="requested_ship_date_to" className="col-sm-2 control-label">To</label>
		<div className="col-md-3">
		<input  name="requested_ship_date_to" type="date" value={ this.state.requested_ship_date_to} min={ this.state.requested_ship_date_from }
		className="form-control" onChange={ this.handleInputChange } />
		</div></div></form> );}
		
		if(this.state.action == "Confirmed Ship_Date")
		{ return (<form className="form-horizontal"><div className="form-group">
		<label for="confirmed_ship_date_from" className="col-sm-2 control-label">Confirmed ship date from</label>
		<div className="col-md-3">
		<input id="txtDate" name="confirmed_ship_date_from" type="date"  value={ this.state.confirmed_ship_date_from } max={moment().format("DD-MMM-YYYY")} className="form-control" onChange= { this.handleInputChange} />		
		</div>
		<label for="confirmed_ship_date_to" className="col-sm-2 control-label">To</label>
		<div className="col-md-3">
		<input  name="confirmed_ship_date_to" type="date" value={ this.state.confirmed_ship_date_to } min={ this.state.confirmed_ship_date_from }
		className="form-control" onChange={ this.handleInputChange } />
		</div></div></form> );}
		
		if(this.state.action == "Expected Ship_Date")
		{ return (<form className="form-horizontal"><div className="form-group">
		<label for="expected_ship_date_from" className="col-sm-2 control-label">Expected ship date From</label>
		<div className="col-md-3">
		<input id="txtDate" name="expected_ship_date_from" type="date"  value={ this.state.expected_ship_date_from } max={moment().format("DD-MMM-YYYY")} className="form-control" onChange= { this.handleInputChange} />		
		</div>
		<label for="expected_ship_date_to" className="col-sm-2 control-label">To</label>
		<div className="col-md-3">
		<input  name="expected_ship_date_to" type="date" value={ this.state.expected_ship_date_to } min={ this.state.expected_ship_date_from }
		className="form-control" onChange={ this.handleInputChange } />
		</div></div></form> );}
		
		if(this.state.action == "Actual ship_Date")
		{ return (<form className="form-horizontal"><div className="form-group">
		<label for="actual_ship_date_from" className="col-sm-2 control-label">Actual Ship Date From</label>
		<div className="col-md-3">
		<input id="txtDate" name="actual_ship_date_from" type="date"  value={ this.state.actual_ship_date_from } max={moment().format("DD-MMM-YYYY")} className="form-control" onChange= { this.handleInputChange} />		
		</div>
		<label for="actual_ship_date_to" className="col-sm-2 control-label">To</label>
		<div className="col-md-3">
		<input  name="actual_ship_date_to" type="date" value={ this.state.actual_ship_date_to } min={ this.state.actual_ship_date_from }
		className="form-control" onChange={ this.handleInputChange } />
		</div></div></form> );}
		
	}
 

	
 
	render() {
		
		
	
		return (
				
				<form className="form-horizontal">
				
				<div className="form-group">
					<label for="customer_name" className="col-sm-2 control-label">Customer Name</label>
					<div className="col-sm-3">
					<input name="customer_name"  type="text" value={ this.state.customer_name } className="form-control" onChange={ this.handleInputChange } validations={['required']}/>
					</div>
					
					<label for="order_number" className="col-sm-2 control-label">Order Number</label>
					<div className="col-sm-3">
						<input name="order_number" id="order_number" type="text" value={ this.state.order_number } className="form-control" onChange={ this.handleInputChange } validations={['required']} />
					</div>
				</div>
				
				<div className="form-group ">
					<label for="order_assignee" className="col-sm-2 control-label">Orders Assigned To</label>
					<div className="col-sm-3">
					<select name="order_assigned_to" value={this.state.order_assigned_to} onChange={this.order_assigned_to}   className="form-control" >
					<option value=""></option>
					<option value="Jim">Jim</option>
					<option value="Norman">Norman</option>
					<option value="Susan">Susan</option>
					<option value="Mary">Mary</option>
					<option value="Ann">Ann</option>
					<option value="BE-VB-Orders@jci.com">BE-VB-Orders@jci.com</option>
					</select>
					</div>
					
					
					<label for="po_number" className="col-sm-2 control-label">Customer PO</label>
					<div className="col-sm-3">
					<input name="po_number" type="text" value={ this.state.po_number } className="form-control" onChange={ this.handleInputChange } />             
					</div>
				</div>
				
				<div className="form-group">
					<label for="order_status" className="col-sm-2 control-label">Order Status</label>
					<div className="col-sm-3">
					<select name="order_status" value={ this.state.order_status } onChange={this.orders_status } className="form-control" >
					<option value=""></option>
					<option value="OPEN">OPEN</option>
					<option value="CONFIRMED">CONFIRMED</option>
					<option value="WAITING FOR CUST. CONF">WAITING FOR CUST. CONF</option>
					<option value="NOT ACCEPTABLE">NOT ACCEPTABLE</option>
					<option value="CANCELLED">CANCELLED</option>
					<option value="INVOICED">INVOICED</option>
					<option value="SHIP DATE CHANGED">SHIP DATE CHANGED</option>
					<option value="SHIP DATE CONFIRMED">SHIP DATE CONFIRMED</option>
					<option value="SHIPPED">SHIPPED</option>
					<option value="SPLITTED">SPLITTED</option>
					<option value="DELETED">DELETED</option>
					</select>
					</div>
					<label for="buyer_name" className="col-sm-2 control-label">Customer User</label>
					<div className="col-sm-3">
					<input name="buyer_name" type="text" value={ this.state.buyer_name } className="form-control" onChange= { this.handleInputChange } />
					</div>
				</div>
				
				<div className="form-group">
				<label for="select_date" className="col-sm-2 control-label">Select Date</label>
				<div className="col-sm-3">
				<select name="action" value={ this.state.action } onChange={ this.handleactiondate } className="form-control" >
				<option value="Select Date">-----Select Date----</option>
				<option value="Creation Date">Creation Date</option>
				<option value="Requested Ship_Date">Requested Delivery Date</option>
				<option value="Expected Ship_Date">Expected Delivery Date</option>
				<option value="Confirmed Ship_Date">Offered Delivery Date</option>
				<option value="Actual ship_Date">Actual Delivery Date</option>
								
				</select>
				
				</div>
				
				
				</div>
					
				{this.actionDatefield()}
	 		
				
 				<div className="form-group">
					<div className="col-sm-offset-7 col-sm-3">
						<div>
						    <button type="submit" className="btn btn-primary" onClick={ this.handleSearch }>Search</button>
						    { '        ' }
						   	<button type="submit" className="btn btn-default" onClick={ this.handleClear }>Reset</button>
						</div>
					</div>
				
					</div>
					
			</form>
		);
	}
}

class SearchResults extends React.Component {
	constructor(props) {
		super(props);
		this.state = {  };
	}
	
	
	render() {
		return (
				 
          
				
					
			<table className="paginated"  style={{
               minWidth: 600,
                margin: 8,
                padding: 8,
                fontSize: 10,
                
               
              }} >
				<thead >
					<tr>
						<th>Order Number</th>
						<th>Customer Name</th>
						<th>Customer User</th>
						<th>Customer PO</th>
						<th>Assignee</th>
						<th>Order Status</th>
						<th>Creation Date </th>
						<th>Total Net Amount</th>
						<th>Total Discount%</th>
						<th>No. Of Lines</th>
						<th>Requested Delivery Date</th>
						<th>Expected Delivery Date</th>
						<th>Offered Delivery Date</th>
						<th>Actual Delivery Date</th>
    					<th>Accept Split Order</th>
						<th>Created By</th>
						
					</tr>
				</thead>
				<SearchResultsList items={ this.props.results } open={ this.props.open } />
				
				</table>
				
				
			
		);
		
		
	}
	
	
}



class TodoApp extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        todos: <SearchResultsList items={ this.props.results } open={ this.props.open } />,
        currentPage: 1,
        todosPerPage: 3
      };
      this.handleClick = this.handleClick.bind(this);
    }

    handleClick(event) {
      this.setState({
        currentPage: Number(event.target.id)
      });
    }

    render() {
      const { todos, currentPage, todosPerPage } = this.state;

      // Logic for displaying current todos
      const indexOfLastTodo = currentPage * todosPerPage;
      const indexOfFirstTodo = indexOfLastTodo - todosPerPage;
      const currentTodos = todos.slice(indexOfFirstTodo, indexOfLastTodo);

      const renderTodos = currentTodos.map((todo, index) => {
        return <li key={index}>{todo}</li>;
      });

      // Logic for displaying page numbers
      const pageNumbers = [];
      for (let i = 1; i <= Math.ceil(todos.length / todosPerPage); i++) {
        pageNumbers.push(i);
      }

      const renderPageNumbers = pageNumbers.map(number => {
        return (
          <li
            key={number}
            id={number}
            onClick={this.handleClick}
          >
            {number}
          </li>
        );
      });

      return (
        <div>
          <ul>
            {renderTodos}
          </ul>
          <ul id="page-numbers">
            {renderPageNumbers}
          </ul>
        </div>
      );
    }
  }




class SearchResultsList extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}

	render() {
		 return (<tbody>{ this.props.items
			.sort((a, b) => moment(b.order_date) - moment(a.order_date))
			.map((item) => <SearchResultsItem key={ item.id } item={ item } open={ this.props.open }  />) }</tbody>);
		}
	
}

class SearchResultsItem extends React.Component {
	constructor(props) {
		super(props);
		this.handleOpen = this.handleOpen.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.state = {  };
		
	}
	
	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		this.setState({ [name]: value });
	}

	handleOpen(e) {
		e.preventDefault();
		this.props.open(this.props.item.id);
		
	}
 
	
	 render() {
		
		 return(  
				 <tr onClick={ this.handleOpen } style={{fontsize: '10',cursor: 'pointer'}}>
					<td>{ this.props.item.order_number }</td>
					<td>{ this.props.item.customer_name }</td>
					<td>{ this.props.item.buyer_name }</td>
					<td>{ this.props.item.po_number }</td>
					<td>{ this.props.item.order_assignee }</td>
					<td>{ this.props.item.order_status }</td>
					<td>{ this.props.item.order_date ? <Moment format="DD-MMM-YYYY">{ this.props.item.order_date }</Moment> : null }</td>
					<td>{ this.props.item.total_net_amount }</td>
					<td>{ this.props.item.discount_amount }</td>
					<td>{ this.props.item.order_items.length }</td>
					<td>{ this.props.item.requested_order_ship_date ? <Moment format="DD-MMM-YYYY">{ this.props.item.requested_order_ship_date }</Moment> : null }</td>
					<td>{ this.props.item.order_ship_date ? <Moment format="DD-MMM-YYYY">{ this.props.item.order_ship_date}</Moment> : null }</td>
					<td>{ this.props.item.confirmed_ship_date ? <Moment format="DD-MMM-YYYY">{ this.props.item.confirmed_ship_date }</Moment> : null }</td>
					<td>{ this.props.item.order_status=="SHIPPED" && this.props.item.actual_ship_date ? <Moment format="DD-MMM-YYYY">{ this.props.item.actual_ship_date }</Moment> : null }</td>
					
					<td><input name="accept_split_order" type="checkbox" style={{width: '15', height: '15'}}checked={this.props.item.accept_split_order==true ?'true':''} className="form-control" /></td>
					<td>{ this.props.item.buyer_email }</td>
					
				</tr>
			
		); 
		
	}
}

class Details extends React.Component {
	constructor(props) {
		super(props);
		this.removeLine = this.removeLine.bind(this);				/// For removing existing line item from the Order
		this.handleAddLine = this.handleAddLine.bind(this);			/// For adding new line item to the Order
		this.handleClose = this.handleClose.bind(this);
		this.handleInputChange = this.handleInputChange.bind(this); /// Listener for state item if changed 
		this.handleSave = this.handleSave.bind(this); 			/// Save (update) orders, line items, files attached ( generic method )
		this.handleAction = this.handleAction.bind(this);		/// Listener for Actions ( like duplicate, delete, edit, autosplit )
		
		this.handleDuplicate = this.handleDuplicate.bind(this);  /// For duplicating the Orders.
		this.handleUpload = this.handleUpload.bind(this);   /// For uploading documents
		
		this.removeFile = this.removeFile.bind(this);	  /// For removing uploaded files ( unlinking file_id from the order_id )
		this.handleAutoSplit = this.handleAutoSplit.bind(this);   /// For splitting the orders based on split number provided from VB. ( if criteria matched )
		this.downloadDocument = this.downloadDocument.bind(this);  /// For downloading documents ( once new files uploaded and the state should be saved then only can able to download files )
		
		this.handleBlankSpace = this.handleBlankSpace.bind(this);
	
		this.handlePublish = this.handlePublish.bind(this);   /// For sending Order's details to the Buyers & Order's Assignee.
		this.shipDateChange = this.shipDateChange.bind(this);  /// For getting the latest ship date whenever a new order item is created by the Order's Assingee.
		this.totalAmountChange = this.totalAmountChange.bind(this); /// For calculating the total amount from all the individual order item Net Amount. When a new order item is created by the Order's Assingee.
		this.onfocus = this.onfocus.bind(this);
		
		//this.handleLogBook = this.handleLogBook.bind(this);
		this.getSelectionStart =this.getSelectionStart.bind(this);
		
		this.state = { item: props.item,
				
				filesPreview:[],
				filesToBeSent:[],
				results:[],
			    printcount:10,
			    modalIsOpen: false };
				
	}
	
		
	removeFile(id)
	{
		var item = this.state.item;
		var files = item.order_files;;
		var i = null;
		for (var j=0; j<files.length;j++)
			{
					if (files[j].file_id == id) {
					i=j;
					break;
				}
				
			}
		files.splice(i, 1);
		this.setState({ item: item });
	}
	
	
	
	removeLine(id) {
		var item = this.state.item;
		var lines = item.order_items;
	
		
		var totalAmount=0;
		var i = null;
		var count = 0 
		var latest = lines[0].expected_ship_date;
		for (var j = 0; j < lines.length; j++) {
			if (lines[j].line_id == id) {
				i=j;
				break;
			}
	
       
			}
		
		lines.splice(i, 1);
		
		
		 
		this.setState({ item: item });
		{this.shipDateChange()}
		{this.totalAmountChange()}
	}
	
	

	handleAddLine(e) {
		e.preventDefault();
		var item = this.state.item;
		var lines = item.order_items;
		//var latest = lines[0].expected_ship_date; 

		var line = { line_id: uuidv4(), net_amount: 0 };
		/* console.log("Line ID need to add:::"+line.line_id); */
		item.order_items.push(line);
		 //this.state.item.NumberofLines=lines.length; 
		
		this.setState({ item: item });
	}
	
	shipDateChange()
	{
		var item = this.state.item;
		var lines = item.order_items;
		
		if(lines.length !=0 ){
		var latest = lines[0].expected_ship_date; 
		 for(var i=0;i<lines.length;i++) {
			 if(moment(lines[i].expected_ship_date) >= moment(latest)) {
				 latest=lines[i].expected_ship_date;
				 }
			 }
		}
		 	this.state.item.actual_ship_date=latest;
		this.setState({ item: item });
	 }
	
	totalAmountChange()
	{
		var item = this.state.item;
		var lines = item.order_items;
		var totalAmount=0;
		
		for (var j = 0; j < lines.length; j++) {
			totalAmount=parseInt(totalAmount)+parseInt(lines[j].net_amount); 
			}
			this.state.item.total_net_amount=totalAmount;
			this.setState({ item: item });
	}
	
	
	

	handleClose(e) {
		e.preventDefault();
		this.props.close();
	}

	handleInputChange(e) {
		var count=0;
		const target = e.target;
		const name = target.name;
		const item = this.state.item;
		const status=item.order_status;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		
		const confirmedStatus = e.target.value;
		var uDate = new Date();
		var user = this.props.user;
		
		var norder = item.order_status;
		var ordern = item.order_number;
		var log = item.log_book;
		var Inotes = item.internal_note;
		console.log(log);
		console.log(norder);
	    var update = log +  "\n" + "Order Number:" + ordern + "-has been updated as:" + norder  + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes + "\n" 
	    + "-----------------------------------------------------------------------------------------------------------------------------------------";
	   	console.log(update);
	   	this.state.item.log_book=update;
	   	this.setState({ item: item,update: update,log: log });
	   	this.setState({value: e.target.value});
		if ( confirmedStatus == "CONFIRMED")
			{
				var confirmedDate =this.state.item.order_confirmation_date;
				var today =moment().format("YYYY-MM-DD");
				this.state.item.order_confirmation_date= today;
			}
		
		if(this.state.action == "DeleteOrder")
			{
			e.preventDefault();
			const name = "order_status";
			const value = "DELETED";
			
			confirmAlert({
							message: 'Are You Sure, You want to Delete Order ?', 
							confirmLabel: 'Confirm', 
							cancelLabel: 'Cancel', 
						onConfirm: () => {
							item[name] = value;
							this.setState({ item: item });
							this.state.item.log_book=update;
					 		this.setState({ item: item,update: update,log: log });
					 		this.props.save(this.state.item);}
						})
			}else {
				item[name] = value;
				this.setState({ item: item });
			}
		
		
	}
	
	 handleSave(e) {
       e.preventDefault();
		var iNumber= this.state.item.invoice_number;
		var Itrim = iNumber.trim();
		console.log(Itrim);
		
		var oNmuber= this.state.item.order_number;
		console.log(oNmuber.trim());
		var cNmuber= this.state.item.customer_number;
		console.log(cNmuber.trim());
		var cName= this.state.item.customer_name;
		var Ctrim = cName.trim();
		console.log(Ctrim);
		
		if(iNumber.trim() == ""  || oNmuber.trim() == "" || cNmuber.trim() == "" || cName.trim() == "" ){
			confirmAlert({
	 			
	 			message: 'Mandetory * fields are should Not blank!', 
	 			confirmLabel: 'Ok',
			})
		}
		else{
		var uDate = new Date();
		var user = this.props.user;
		var item = this.state.item;
		var norder = item.order_status;
		var ordern = item.order_number;
		var log = item.log_book;
		var Inotes = item.internal_note;
		console.log(log);
		
		console.log(norder);
		
	    var update = log +  "\n" + "Order Number:" + ordern + "-has been updated as:" + norder + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes + "\n" 
	    + "-----------------------------------------------------------------------------------------------------------------------------------------";
	   
	   	this.state.item.log_book= update;
	   	this.setState({ item: item,update:update});
	   	this.props.save(this.state.item);
		}
		
	}
	
	handleDuplicate(e) {
		e.preventDefault();
		var item = this.state.item;
		var lines = item.order_items;
		const name = "order_status";
	 	const value = "SPLITTED";
	 	var uDate = new Date();
		var user =this.props.user;
		var norder = item.order_status;
		var ordern = item.order_number;
		var Inotes = item.internal_note;
		var log = item.log_book;
		console.log(log);
		console.log(norder);
	    var update = log +  "\n" +  "Order Number:" + ordern + "-has been updated as:" + norder + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes + "\n" 
	    + "-----------------------------------------------------------------------------------------------------------------------------------------";
	   	console.log(update);
	   	this.state.item.log_book=update;
	   	this.setState({ item: item,update: update,log: log });
	 	var today =moment().format("DD-MMM-YYYY");
	 	this.state.item.order_date= today;
	 	
	 	/*if( item.order_status != value ) {*/
	 		confirmAlert({
	 			// title: 'Delete Order Confirm',
	 			message: 'Are You Sure, You want to Duplicate the same Order ?', 
	 			confirmLabel: 'Confirm', 
	 			cancelLabel: 'Cancel', 
	 			onConfirm: () => {
				this.state.item.log_book=update;
		 		this.setState({ item: item,update: update,log: log });
		 		this.props.save(this.state.item);
		 		this.props.create(this.state.item);}
		 		 
			})
	/* 	}
	 	else
	 		{
	 			confirmAlert({
				
				message: 'Splitted Order cannot be Duplicate', 
				confirmLabel: 'Ok', 
			});
	 		}*/
		
	}
	
		
	handleAutoSplit(e) {
		e.preventDefault();
		var item = this.state.item;
		var lines = item.order_items;
		const name = "order_status";
	 	const value = "SPLITTED";
	 	var uDate = new Date();
	 	
		var user =this.props.user;
		var Inotes = item.internal_note;
		var norder = item.order_status;
		var ordern = item.order_number;
		var log = item.log_book;
		console.log(log);
		console.log(norder);
	    var update = log +  "\n" + "Order Number:" + ordern + "-has been updated as:" + norder + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes + "\n" 
		    + "-----------------------------------------------------------------------------------------------------------------------------------------";
	   	console.log(update);  ;
	   	console.log(update);
	   	this.state.item.log_book=update;
	   	this.setState({ item: item,update: update,log: log });
		var newlines = JSON.parse(JSON.stringify(lines));
		var line = {}; 
		 
		if( item.order_status != value )
			{
				
				var grouped = Object.create(null);
		
				lines.forEach(function (a) {
				grouped[a.split_number] = grouped[a.split_number] || [];
				grouped[a.split_number].push(a);
				});
		
		/*		console.log("Grouped"+JSON.stringify((Object.values(grouped))));
				console.log("Grouped"+(Object.values(grouped)).length);*/
				var isValidOrder=(Object.values(grouped)).length;
				
				if ( isValidOrder > 1 ) {
					var result = [];
					var lines = [];
		
					for (var index in grouped) {
						result.push(grouped[index]);
					}
	
					item.order_items.splice(0);
					for ( var index in result) {
						item.order_items.push.apply(item.order_items,result[index]);
						item[name] = value;
						this.setState({ item: item })
						
						{this.shipDateChange()}
						{this.totalAmountChange()}
						
						this.props.create(this.state.item);
						item.order_items.splice(0);
					}
		  
					//For maintaining the original order lines ( remains unchanged after splitted )
					for ( var index in result) {
						item.order_items.push.apply(item.order_items,result[index]);
					}
					{this.shipDateChange()}
					{this.totalAmountChange()}
					/*console.log("Lines Length::::"+item.order_items.length);*/
					item[name] = value;
					this.setState({ item: item })
					this.state.item.log_book=update;
				   	this.setState({ item: item,update: update,log: log });
				   	this.props.save(this.state.item);
				}
				else
					{
						confirmAlert({
						
						message: 'Its not a valid Order to Split. Since all the Split Numbers are same. ', 
						confirmLabel: 'Ok', 
					});
					}
			}
		else
			{
			confirmAlert({
				
				message: 'You have choosen Splitted Order. Please select some other Order', 
				confirmLabel: 'Ok', 
			});
			}
	
	}	
	
	
	handlePublish(e){
		e.preventDefault();
		var email = this.state.item.buyer_email;
		var orders = this.state.item.order_status;
		var ordern = this.state.item.order_number;
		var user = this.state.item.order_assignee;
		var item = this.state.item;
		var uDate = new Date();
		var user =this.props.user;
		var Status = item.order_status;
		var ordern = item.order_number;
		var Inotes = item.internal_note;
		var log = item.log_book ;
		
		if(typeof log === undefined && typeof log === "" ){
		console.log(log);
		console.log(Status);
		
		 var update = "Order Number:" + ordern + "-has been updated as:" + Status + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes + "\n" 
		    + "-----------------------------------------------------------------------------------------------------------------------------------------";
	   	console.log(update);
		}
		else{
			
			var update = log + "\n" + "Order Number:" + ordern + "-has been updated as:" + Status + "\n" + "Modified By:" + user + ": on--" + uDate + "\n" + "Note:-" + Inotes 
			+ "\n" 
		    + "-----------------------------------------------------------------------------------------------------------------------------------------";;
		   	console.log(update);
		}
	   	//this.state.item.log_book=update;
	   	//this.setState({ item: item,update: update,log: log });
		console.log(orders);
		
		var message =  "Your Order Number:" + ordern  + ","  + "has been updated as:";
		console.log(message);
		var newLine = escape("\n");
		var body = message + orders + "." + "\n" + newLine + newLine + "Thank you for order in VBDesk!!!!";
		console.log(body);
		 
		var link = "mailto:" + email
            
             + "&subject=" + escape("Status update")
             + "&body=" + "Dear Customer," + newLine + newLine + body + newLine + "Thanks," + newLine + "VBDesk Admin";
		confirmAlert({
 			// title: 'Delete Order Confirm',
 			message: 'Are You Sure, You want to Email the status to Customer ?', 
 			confirmLabel: 'Confirm', 
 			cancelLabel: 'Cancel', 
 			onConfirm: () => {
 				window.location.href = link;
 				this.state.item.log_book=update;
 		 		this.setState({ item: item,update: update,log: log });
 		 		this.props.save(this.state.item);}
		})
		
	
	}
	
	/*handleLogBook(e)
    {
		e.preventDefault();   
		var uDate = new Date();
           var datetime = uDate.toLocaleDateString();
           var user = this.props.user;
           var item = this.state.item;
           var OrderStatus = item.order_status;
           var OrderNumber = item.order_number;
           var log = item.log_book;
        var update = log +  "\n" + "Order Number:" + OrderNumber + "-has been updated by:" +  user + ": on--" + datetime + "field update:"+ OrderStatus ;
        this.state.item.log_book= update;
        this.setState({ item: item,update: update,log: log });
    }
	*/
	
	
	
	
	onfocus(e){
	    e.currentTarget.type = "date";
	}
	
	
	onDrop(acceptedFiles) {
		/*console.log('Accepted files: ', acceptedFiles.name);
		console.log("Accepted files length::::"+acceptedFiles.length);*/
		
		var filesToBeSent=this.state.filesToBeSent;
		
		if(filesToBeSent.length < this.state.printcount){
			filesToBeSent.push.apply(filesToBeSent,acceptedFiles);
			var file_name=acceptedFiles[0].name;
			var filesPreview=[];
			
			for( var i in filesToBeSent ) 
				{
					filesPreview.push.apply(filesPreview,filesToBeSent);
				}
				
			
				
		/*	for(var i in filesToBeSent){
				var id=uuidv4();
				filesPreview.push(<div >
				{filesToBeSent[i][0].name}<button   value={ uuidv4() } type="submit" className="btn btn-danger btn-round-xs btn-xs" style={{"border-radius" : "15px"}}  onClick={ this.remove.bind(this, id ) } >clear</button>
				</div>
				)
			}*/
        
			this.setState({	filesToBeSent, filesPreview, file_name });
			{this.handleUpload()}
       
      }
      else{
        alert("You have reached the limit of uploading files at a time")
      }
		
   }
	
	
	handleLogs(){
		
	if(this.state.action == "Edit Order")
		alert('hi');
	}

	
	handleUpload(e){
		
		var ObjectID = require("bson-objectid");
		
		//e.preventDefault();
		var item = this.state.item;
		var files = item.order_files;
		var filesPreview = this.state.filesPreview;
		var filesToBeSent=this.state.filesToBeSent;
		var file_name = { file_name: this.state.file_name };
		var file;
		//e.preventDefault();
		
		
		var request = require('superagent');        	
		
		var apiBaseUrl = "api/UploadDocServlet";
		
		var self = this;
		
			if(this.state.filesToBeSent.length>0){
				var filesArray = this.state.filesToBeSent;
				var count=0;
	  
	   
				for(var i in filesArray){
				   	 var req = request.post(apiBaseUrl);
	    	    	 req.attach(filesArray[i].name,filesArray[i])
	    	    	 file = { file_id: ObjectID(), file_name: filesArray[i].name};
			         item.order_files.push(file);
			         req.field({ id: JSON.stringify(file) })

			       this.state.filesPreview.splice(0);
			       
			       this.setState({ item: item, filesPreview });
	       
			         req.end(function(err,res){
			        	 if(err){
			        		 
			        		 confirmAlert({
			 					
			 					message: 'File not uploaded properly...Please check the logs....', 
			 					confirmLabel: 'Ok', 
			 				});
			        		 
			        	 }
			         });
				}
	   
	  		}
			else{
				
				confirmAlert({
					
					message: 'Please select some file to upload', 
					confirmLabel: 'Ok', 
				});
				
				
			}	
			 this.state.filesToBeSent.splice(0);
			 this.setState({  filesPreview, filesToBeSent  });
		}

	
	 handleAction(e) {
			this.setState({action:e.target.value});
			}
	 
		 
		 downloadDocument(fileIdMongo){
			 var request = require('superagent');
			 var apiBaseUrl = "api/downloadDoc";
			 var req = request.get(apiBaseUrl);
			 
			 req.query({ id: fileIdMongo })
			 req.end(function(err,res){
			     
				 if(err){
					 confirmAlert({
		 					
		 					message: 'File not downloaded properly...Please check the logs....', 
		 					confirmLabel: 'Ok', 
		 				});
			      }
			     else{
			    	 	var blob = new Blob([res.text], {
			    	 		type: 'text/csv/jpeg/jpg/png/pdf/docx/doc;charset=utf8;'
			    	 	});
			    
			    	 	var element = document.createElement('a');
			    	 	document.body.appendChild(element);
			    	 	window.location= 'api/downloadDoc?id=' + fileIdMongo,'';
			    	 	element.click();
			      	} 
			      
			 	});
			 }
	 
	handleTrackingNumber()
			{
				if(this.state.action == "Edit Order")
				{ return ( 	<input name="tracking_number" type="text" maxLength="50" onKeyDown={this.handleBlankSpace} value={ this.state.item.tracking_number }  disabled={ this.state.mode } className="form-control" onChange={ this.handleInputChange } />  );}
				else
					{
					 return ( <a href="www.google.com" target="www.google.com" disabled={ this.state.mode } > { this.state.item.tracking_number } </a> );
					}
			}
				
	handleActionButtons()
	{
			
			if(this.state.action == "Edit Order")
			{ return ( 	<button type="submit" className="btn btn-primary" onClick={ this.handleSave } >Save</button> );}
			if(this.state.action == "PrintOrder")
			{ return ( <button type="submit" className="btn btn-primary" onClick={ this.handlePrint } >Print Order</button> );}
			if(this.state.action == "DeleteOrder")
			{ return ( <button type="submit"  className="btn btn-primary" onClick={ this.handleInputChange } >Delete Order</button> );}
			if(this.state.action == "AutoSplit")
			{ return ( <button type="submit" className="btn btn-primary" onClick={ this.handleAutoSplit } >AutoSplit Order</button> );}
			if(this.state.action == "DuplicateOrder")
			{ return ( <button type="submit" className="btn btn-primary" onClick={ this.handleDuplicate } >Duplicate Order</button> );}
			if(this.state.action == "SendEmail")
			{ return ( <button type="submit" className="btn btn-primary" onClick={ this.handlePublish } >Send Email</button> );}
		
	}

	
	
	fileUploadComponent() {
		if ( this.state.action == "Edit Order"){
			return (
					<Dropzone accept="image/jpeg, image/png, txt/plain, .txt, .xlsx, .xls, .docx, .doc, .pdf"  class="col-sm-5" disabled={ this.state.mode }  style={{"border-style" : "dashed"}} maxFilesize= "2"  onDrop={(files) => this.onDrop(files)}>
	                <div disabled={ this.state.mode }>Browse file</div>
	                </Dropzone>
		);}
	}
	
	handleBlankSpace(e) {
		var charCode = (e.which) ? e.which : e.keyCode;
		if ( (charCode == 32) )
			{ e.preventDefault(); }
		}
	
	handleBlankSpaceFirstChar(e) {
		const reg = /[a-zA-Z @#$%^&*_-]+/g;
		if (!reg.test(e.key) || e.which === 32 &&  e.target.selectionStart === 0) {
			 e.preventDefault();
		       }  
	}
/*	handleInputNumber(e) {
		 var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 var shiftPressed = (window.Event) ? e.modifiers & Event.SHIFT_MASK : e.shiftKey;
		 if ((!shiftPressed && charCode == 187 ) || (charCode == 107) || (charCode == 189) || (charCode == 69) || (charCode == 190) || (charLength >= 10 && e.keyCode != 46   && e.keyCode != 8))
			  {
			  e.preventDefault();
			  }
	}*/
	/*handleInputNumber(e) {
		
		const re = /[0-9]+/g;
	    if (!re.test(e.key)) {
	      e.preventDefault();
	    }
		
		
		
	}*/
	
	handleInputNumber(e) {
		 var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 const reg = /[0-9]+/g;
		 if (!reg.test(e.key) && charCode != 8 && charCode != 46 && charCode != 37 && charCode != 39 && !(e.keyCode >= 96 && e.keyCode <= 105)){
			 e.preventDefault();
		 }
		
	}
		
	handleAlphanumeric(e) {
		 var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 const reg = /(?!.^[^])[a-zA-Z0-9]+/g;
		 if (!reg.test(e.key) && charCode != 8 && charCode != 46 && charCode != 37 && charCode != 39 && !(e.keyCode >= 96 && e.keyCode <= 105) && !(e.keyCode >= 65 && e.keyCode <= 90)){
			 e.preventDefault();
		 }
	}
	
	
	handleAlphaSpecialChar(e) {
		 var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 //const reg = /\s[a-zA-Z_\s-]+$;
		 const reg = /^[a-zA-Z @#%&*_-]*$/;
		 if (!reg.test(e.key) && charCode != 32 && charCode != 8 && charCode != 46  && charCode != 37){
		 //if (!reg.test(e.key) && e.which === 32 &&  e.target.selectionStart === 0 && charCode != 8 && charCode != 46  && charCode != 37  && charCode != 31 && charCode != 39 && !(e.keyCode >= 65 && e.keyCode <= 90) ){
			 e.preventDefault();
		 }
	}
	
	handleAlpha(e) {
		 var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 const reg = /[a-zA-Z]+/g;
		 if (!reg.test(e.key) && charCode != 8 && charCode != 46 && charCode != 37 && charCode != 39 && !(e.keyCode >= 96 && e.keyCode <= 105) && !(e.keyCode >= 65 && e.keyCode <= 90)){
			 e.preventDefault();
		 }
	}
	
	/* var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 var shiftPressed = (window.Event) ? e.modifiers & Event.SHIFT_MASK : e.shiftKey;
		 if(charCode > 46 && charCode < 58 ) {
			
		 }
		 else {
			e.preventDefault();
		 }
		 
		 
	}*/
	
	handleInputDiscount(e) {
		
		 this.value = parseFloat(this.value).toFixed(2);
		/* var charLength=e.target.value.length;
		 var charCode = (e.which) ? e.which : e.keyCode;
		 var shiftPressed = (window.Event) ? e.modifiers & Event.SHIFT_MASK : e.shiftKey;
		 if ((!shiftPressed && charCode == 187 ) || (charCode == 107) || (charCode == 189) || (charCode == 69) || (charCode == 190) || (charLength >= 2 && e.keyCode != 46   && e.keyCode != 8))
			  {
			  e.preventDefault();
			  }
		 */
		 
	}
	  //floating point
     validateFloatKeyPress(e) { 
    	
    	var charCode = (e.which) ? e.which : e.keyCode;
    	 const reg = /^(?=.*\d)\d(?:\.{3}\d\d)?$/;
    	 var number = e.target.value.split('.');
		 if (!reg.test(e.key) && charCode != 8 && charCode != 46 && charCode != 190 && charCode != 37 && charCode != 39 && !(e.keyCode >= 96 && e.keyCode <= 105)){
    	
			 e.preventDefault();
		 }
		 if(number.length>1 && charCode == 46){
			 e.preventDefault();
	    }
		 
		 //var caratPos = {this.getSelectionStart(e)};
		    var dotPos = e.target.value.indexOf(".");
		    if( dotPos>-1 && (number[1].length > 1)){
		    	 e.preventDefault();
		    }
		   
     }
	   

	//thanks: http://javascript.nwbox.com/cursor_position/
	  getSelectionStart(o) {
		 
		if (o.createTextRange) {
			var r = document.selection.createRange().duplicate()
			r.moveEnd('character', o.value.length)
			if (r.text == '') return o.value.length
			return o.value.lastIndexOf(r.text)
		} else return o.selectionStart
	}
	
	
	
	
	onfocus(e){
	    e.currentTarget.type = "date";
	}
	
     
     
	 render() {
		 
		 var item = this.state.item;
		 const name = "order_status";
		 const value = "DELETED";
		 	
		 const style = { margin: 12 };
		
		 if(this.state.action != "Edit Order"){
			 this.state.mode="disabled";
			 this.state.AccessMode="disabled";
		
		 }
		 else if(this.props.group == "Individual")
		 {
			 this.state.AccessMode="disabled";
		     this.state.mode="";
		 }
		 else {
			 this.state.mode="";
			 this.state.AccessMode="";
		 }
		 
		 if( item.order_status == value ) {
				this.state.deleteMode = "";
			}
		 
	
		return (
				
				
		
				<div>
				User : {this.props.user} Group: {this.props.group}
				<form className="form-horizontal">
					<div className="row">
						<div className="col-sm-12">
							<div className="form-group" >
								<label for="action" className="col-sm-2 control-label" >Action :</label>
									<div className="col-sm-3" >
										<select name="action" value={this.state.item.action}  disabled={ this.state.deleteMode } onChange={this.handleAction}  className="form-control" >
											<option value="">Select Action</option>
											<option value="Edit Order">Edit Order</option>
											{this.props.group!="Individual" ? <option value="DeleteOrder">Delete Order</option>:  null }
											{this.props.group!="Individual" ? <option value="DuplicateOrder">Duplicate Order</option>:  null }
											{this.props.group!="Individual" ? <option value="AutoSplit">AutoSplit</option>:  null }
											{this.props.group!="Individual" ? <option value="SendEmail">Send Email</option> :  null }
										</select>
									</div>
								{ this.handleActionButtons() }
								{ '   ' }
								<button type="submit" className="btn btn-default" onClick={ this.handleClose }>Back to List</button>
							</div>
						</div>
					</div>
				</form>
					<br/>
					<br/>
					
							      
					
					<form className="form-horizontal" >
					<div className="row">
					<div className="col-sm-12">
						
						<div className="form-group">
							<label for="invoice_number" className="col-sm-2 control-label">Invoice Number<span style={{color:'red'}}>*</span></label>
							<div className="col-sm-3">
								<input name="invoice_number"  type="text" maxLength="20" onKeyDown={ this.handleAlphanumeric }  value={ this.state.item.invoice_number }  disabled={ this.state.mode } className="form-control" onChange={ this.handleInputChange } />  
							</div>
								<div className="col-sm-3">
								<input name="order_id" type="hidden" disabled={ this.state.mode }  value={ this.state.item.id }  className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
					
						<div className="form-group">
							<label for="customer_number" className="col-sm-2 control-label">Customer Number<span style={{color:'red',height:'40'}}>*</span></label>
							<div className="col-sm-3">
								<input name="customer_number" type="text" maxLength="10" onKeyDown={ this.handleAlphanumeric }  value={ this.state.item.customer_number }  disabled={ this.state.mode } className="form-control" onChange={ this.handleInputChange } />  
							</div>
							<label for="tracking_number" className="col-sm-2 control-label">Tracking Number</label>
								<div className="col-sm-3">
									{this.handleTrackingNumber()}
								</div>
						</div>
					
						<div className="form-group">
							<label for="customer_name" className="col-sm-2 control-label">Customer Name<span style={{color:'red'}}>*</span></label>
							<div className="col-sm-3">
								<input name="customer_name" type="text"  value={ this.state.item.customer_name } maxLength="50" onKeyDown={ this.handleBlankSpaceFirstChar }  disabled={ this.state.mode } className="form-control" onChange={ this.handleInputChange } autocomplete="off" />  
							</div>
							<label for="order_number" className="col-sm-2 control-label">Order Number<span style={{color:'red'}}>*</span></label>
							<div className="col-sm-3">
								<input name="order_number" type="text" disabled={ this.state.mode } maxLength="10" onKeyDown={ this.handleInputNumber }  value={ this.state.item.order_number }  className="form-control" onChange={ this.handleInputChange }  />
							</div>
						</div>
						
						<div className="form-group">
							<label for="order_assignee" className="col-sm-2 control-label">Orders Assigned To</label>
							<div className="col-sm-3">
							<select name="order_assignee" value={ this.state.item.order_assignee } disabled={ this.state.mode } onChange={this.handleInputChange} className="form-control" >
							<option value="">---Select Assignee---</option>
							<option value="Jim">Jim</option>
							<option value="Norman">Norman</option>
							<option value="Susan">Susan</option>
							<option value="Mary">Mary</option>
							<option value="Ann">Ann</option>
							<option value="BE-VB-Orders@jci.com">BE-VB-Orders@jci.com</option>
							</select>
							</div>
							<label for="po_number" className="col-sm-2 control-label">Customer PO<span style={{color:'red',width:'8px'}}>*</span></label>
							<div className="col-sm-3">
							<input name="po_number" type="text" id="po" disabled={ this.state.mode } maxLength="20" onKeyDown={this.handleBlankSpace} value={ this.state.item.po_number }  className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="total_net_amount" className="col-sm-2 control-label">Total Net Price</label>
							<div className="col-sm-3">
							<input name="total_net_amount" type="text" maxLength="20" onKeyDown={ this.handleInputNumber }  disabled={ this.state.mode } onKeyDown={this.handleInputNumber}  value={ this.state.item.total_net_amount } className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="discount_amount" className="col-sm-2 control-label">Total Discount</label>
							<div className="col-sm-3">
							<input name="discount_amount" type="text" step=".01"  maxLength="5" placeholder="0.00"  onKeyPress={ this.validateFloatKeyPress } disabled={ this.state.mode }   value={ this.state.item.discount_amount } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="requested_ship_date" className="col-sm-2 control-label">Requested Ship Date</label>
							<div className="col-sm-3">
							<input  name="requested_order_ship_date"  type="date" disabled={ this.state.mode }  value={this.state.item.requested_order_ship_date } className="form-control"  onChange={ this.handleInputChange } />
							</div>
							<label for="order_status" className="col-sm-2 control-label">Order Status</label>
							<div className="col-sm-3">
							<select name="order_status" value={ this.state.item.order_status } disabled={ this.state.mode } onChange={this.handleInputChange} className="form-control" >
							<option value=""></option>
							<option value="OPEN">OPEN</option>
							<option value="CONFIRMED">CONFIRMED</option>
							<option value="WAITING FOR CUST. CONF">WAITING FOR CUST. CONF</option>
							<option value="NOT ACCEPTABLE">NOT ACCEPTABLE</option>
							<option value="CANCELLED">CANCELLED</option>
							<option value="INVOICED">INVOICED</option>
							<option value="SHIP DATE CHANGED">SHIP DATE CHANGED</option>
							<option value="SHIP DATE CONFIRMED">SHIP DATE CONFIRMED</option>
							<option value="SHIPPED">SHIPPED</option>
							<option value="SPLITTED">SPLITTED</option>
							<option value="DELETED">DELETED</option>
							</select>
							</div>
						</div>
						<div className="form-group">
							<label for="internal_note" className="col-sm-2 control-label">Internal Notes</label>
							<div className="col-sm-3">
								<textarea name="internal_note" style={{resize: 'none'}} rows="5" disabled={ this.state.mode }  maxLength="256" onKeyDown={this.handleBlankSpaceFirstChar}  type="text" value={ this.state.item.internal_note } className="form-control" onChange={ this.handleInputChange } />
								   <span class="pull-right label label-default" id="count_message"></span>
							</div>
							<label for="customer_note" className="col-sm-2 control-label">Customer Notes</label>
							<div className="col-sm-3">
								<textarea name="customer_note" style={{resize: 'none'}} rows="5" disabled={ this.state.mode }  maxLength="256" onKeyDown={this.handleBlankSpaceFirstChar} type="text" value={ this.state.item.customer_note } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						
						<div className="form-group">
							<label for="BilltoAddress" className="col-sm-2 control-label">Bill-To Address </label>
							<div className="col-sm-3">
							<input name="bill_to_address_name" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_name } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ShiptoAddress" className="col-sm-2 control-label">Ship-To Address</label>
							<div className="col-sm-3">
							<input name="ship_to_address_name" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_name }maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>	
						<div className="form-group">
							<label for="bill_to_address_company" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="bill_to_address_company" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_company } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ship_to_address_company" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="ship_to_address_company" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_company } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>	
						<div className="form-group">
							<label for="bill_to_address_address" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="bill_to_address_address" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_address } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ship_to_address_address" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="ship_to_address_address" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_address } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>	
						<div className="form-group">
							<label for="bill_to_address_city" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="bill_to_address_city" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_city } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ship_to_address_city" className="col-sm-2 control-label"></label>
							<div className="col-sm-3">
							<input name="ship_to_address_city" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_city } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="bill_to_address_zip" className="col-sm-2 control-label"></label>	
							<div className="col-sm-3">
							<input name="bill_to_address_zip" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_zip } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ship_to_address_zip" className="col-sm-2 control-label"></label>	
							<div className="col-sm-3">
							<input name="ship_to_address_zip" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_zip } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						<div className="form-group">
							<label for="bill_to_address_country" className="col-sm-2 control-label"></label>	
							<div className="col-sm-3">
							<input name="bill_to_address_country" disabled={ this.state.mode }  type="text" value={ this.state.item.bill_to_address_country } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
							<label for="ship_to_address_country" className="col-sm-2 control-label"></label>	
							<div className="col-sm-3">
							<input name="ship_to_address_country" disabled={ this.state.mode }  type="text" value={ this.state.item.ship_to_address_country } maxLength="50" onKeyDown={this.handleBlankSpaceFirstChar} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>	
						<div className="form-group">
							<label for="PaymentTerms" className="col-sm-2 control-label">Payment Terms</label>
							<div className="col-sm-3">
							<input type="text" name="payment_terms" value={ this.state.item.payment_terms } disabled={ this.state.mode } onChange={this.handleInputChange} className="form-control" />
							</div>
							<label for="order_date" className="col-sm-2 control-label">Creation Date</label>
							<div className="col-sm-3">
							<input name="order_date" disabled={ this.state.mode }   onFocus={ this.onfocus } Moment format="DD-MMM-YYYY" value={ this.state.item.order_date } className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
						
						<div className="form-group">
						<label for="note_to_customer"  className="col-sm-2 control-label">Notes To Customer</label>
						<div className="col-sm-3">
							<textarea name="note_to_customer" style={{resize: 'none'}} rows="5"  disabled={ this.state.mode } type="text" value={ this.state.item.note_to_customer } className="form-control" onChange={ this.handleInputChange } />
						</div>
						<label for="actual_ship_date"  className="col-sm-2 control-label">Actual Delivery Date </label>
						<div className="col-sm-3">
							<input name="actual_ship_date"  disabled={ this.state.mode }  onFocus={ this.onfocus } Moment format="DD-MMM-YYYY"  value={ this.state.item.actual_ship_date } className="form-control" onChange={ this.handleInputChange } />
						</div>
						</div>
						
						<div className="form-group">
						<label for="delivery_date"  className="col-sm-2 control-label"></label>
						<div className="col-sm-3">
							<input  name="delivery_date" type="hidden" disabled={ this.state.mode }  onFocus={ this.onfocus } format="DD-MMM-YYYY" value={ this.state.item.delivery_date } className="form-control" onChange={ this.handleInputChange } />
						</div>
							<label for="order_confirmation_date" className="col-sm-2 control-label" ></label>
							<div className="col-sm-3">
								<input name="order_confirmation_date" type="hidden"  disabled={ this.state.mode } value={ this.state.item.order_confirmation_date} className="form-control" onChange={ this.handleInputChange } />
							</div>
						</div>
					</div>
				</div>
					
				
					
					{ '  '}
				<table className="table table-bordered" style={{fontsize: '8'}}>
					<thead>
						<tr>
							<th>Split Number</th>
							<th>Factory Pin</th>
							<th>Location Code</th>
							<th>Requested Ship Date</th>
							<th>Line Number</th>
							<th>Product Code</th>
							<th>Description</th>
							<th>Quantity</th>
							<th>Ship Date</th>
							<th>Unit Price</th>
							<th>Total Net Price</th>
							<th>Actions</th>
						</tr>
					</thead>
					<DetailsList items={ this.state.item.order_items } removeLine={ this.removeLine } shipDateChange={ this.shipDateChange } totalAmountChange={ this.totalAmountChange } mode={ this.state.mode } />
					<tfoot>
					<tr>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><input type="text" className="form-control" disabled="disabled" /></th>
						<th><button type="submit" disabled={ this.state.mode } className="btn btn-default" style={{size: '10'}} onClick={ this.handleAddLine }><span	style={{size: '10'}} className="glyphicon glyphicon-plus"></span></button></th>
					</tr>
				</tfoot>
				</table>
			
				<table className="table table-bordered" style={{fontsize: '10'}}>
				<thead>
				<tr>
					
					<th>File Name</th>
					<th>File Type</th>
					<th>Actions</th>
				</tr>
				</thead>
				<FilesList items={this.state.item.order_files} removeFile={ this.removeFile } downloadDocument={ this.downloadDocument } mode={ this.state.mode }  />
				<tfoot>
				<tr>
					
	               
	                <th><input type="text" className="form-control" disabled="disabled" /></th>
					<th><input type="text" className="form-control" disabled="disabled" /></th>
					<th>
					{this.fileUploadComponent()}		
					</th>
					
				</tr>
				</tfoot>
				</table>
					

				<div className="form-group">
				<label for="log_book" className="col-sm-1 control-label" >Log Book</label>
				<div className="col-sm-8">
					<textarea name="log_book" style={{resize: 'none'}} rows="10" readonly  value={ this.state.item.log_book } className="form-control" onChange={ this.handleLogBook } readonly disabled="disabled" />
				</div>
				</div>
				
				
			</form>
			
				</div>
				
			);	 
		
		
	 }
}


class FilesList extends React.Component {
	
	constructor(props) {
		super(props);
		this.state = { };
	}
	

	render() {
		return (<tbody>{ this.props.items.map((item) => <FilesItem key={ item.file_id } item={ item } removeFile={ this.props.removeFile } downloadDocument={ this.props.downloadDocument } mode={ this.props.mode } />) }

</tbody>);
	}

}
	
	class FilesItem extends React.Component {
	
	constructor(props) {
		super(props);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleDownloadFile = this.handleDownloadFile.bind(this);
		this.handleRemoveFile = this.handleRemoveFile.bind(this);
		this.state = { item: props.item };
	}
	
	handleRemoveFile(e) {
		e.preventDefault();
		this.props.removeFile(this.props.item.file_id);
	}
	
	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const item = this.state.item;
		item[name] = value;
		this.setState({ item: item });
	}
	
	handleDownloadFile(e) {
		e.preventDefault();
		// this.props.removeLine(this.props.item.line_id);
		this.props.downloadDocument(this.props.item.file_id);
	}
	
	
	render() {

		
		return (
			<tr>
			<td><input name="file_name" type="text" value={ this.state.item.file_name } disabled={ this.props.mode } onChange={ this.handleInputChange } className="form-control" onChange={ this.handleInputChange }/> </td>
			<td><select name="file_type" type="text" value={ this.state.item.file_type } disabled={ this.props.mode } onChange={ this.handleInputChange } className="form-control" onChange={ this.handleInputChange }> 
			<option value="">----Select File Type---</option>
			<option value="Invoice">Invoice</option>
			<option value="Packaging List">Packaging List</option>
			</select> </td>
			
			<td>
			<button type="submit" className="btn btn-primary" onClick={ this.handleDownloadFile }  ><span className="glyphicon glyphicon-arrow-down"></span>Download</button>
						{'   '}<button type="submit" className="btn btn-default" style={{size: '5'}} disabled={ this.props.mode } onClick={ this.handleRemoveFile }><span className="glyphicon glyphicon-minus style={{size: '5'}}"></span></button></td>
			
					
						</tr>
	    	
		);
	}
	

}

class DetailsList extends React.Component {
	constructor(props) {
		super(props);
		this.state = { };
	}
	

	render() {
		return (<tbody>{ this.props.items.map((item) => <DetailsItem key={ item.line_id } item={ item } removeLine={ this.props.removeLine } shipDateChange={ this.props.shipDateChange } totalAmountChange={this.props.totalAmountChange} mode={ this.props.mode } />) }

</tbody>);
	}
}

class DetailsItem extends React.Component {
	constructor(props) {
		super(props);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.handleRemoveLine = this.handleRemoveLine.bind(this);
		
		this.handleShipDate = this.handleShipDate.bind(this);
		this.handleTotalPrice = this.handleTotalPrice.bind(this);
		
	
		this.sort =this.sort.bind(this);
		this.state = { item: props.item };
	}
	
	sort(expected_ship_date){
		this.state.item.sort(expected_ship_date);
	  }
	
	handleInputChange(e) {
		const target = e.target;
		const name = target.name;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const item = this.state.item;
	    const quantity = item.product_quantity; 
	    const price = item.unit_netprice;
		item[name] = value;
		this.setState({ item: item });
	}
	
	
	handleRemoveLine(e) {
		e.preventDefault();
		this.props.removeLine(this.props.item.line_id);
	}
	
	handleShipDate()
	{
	  	this.props.shipDateChange();
	}
	
	
	
	handleTotalPrice(e)
	{	
		e.preventDefault();
		const item = this.state.item;
		const quantity = parseInt(item.product_quantity); 
		const price = parseInt(item.unit_net_price);
		var netAmount=0;
		netAmount=parseInt(quantity*price);
		this.state.item.net_amount=netAmount;
		this.setState({ item: item });
		{this.handleTotalAmount()}
	}
	
	handleTotalAmount()
	{
		this.props.totalAmountChange();
	}
	
	onFocus(e){
	    e.currentTarget.type = "date";
	}
	
	
	render() {

		
		return (
			<tr>
			<td><input name="split_number" type="text"  maxLength="2" onKeyDown={ this.handleInputNumber } value={ this.state.item.split_number } disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }/> </td>
			<td><input name="factory_pin_code" type="text" value={ this.state.item.factory_pin_code } disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }/> </td>
			<td><input name="location_code" type="text" value={ this.state.item.location_code } disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }/> </td>
			<td><input name="requested_ship_date"  onFocus={ this.onFocus } value={ this.state.item.requested_ship_date } disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }/> </td>
				<td><input name="line_number" type="text" maxLength="3" onKeyDown={ this.handleInputNumber } value={ this.state.item.line_number } disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }/> </td>
				<td><input name="product_code" type="text" value={ this.state.item.product_code }  disabled={ this.props.mode } className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="product_description" type="text" value={ this.state.item.product_description } disabled={ this.props.mode } className="form-control" onChange={ this.handleInputChange } /> </td>
				<td><input name="product_quantity" type="text" maxLength="6" onKeyDown={ this.handleInputNumber } value={ this.state.item.product_quantity }   disabled={ this.props.mode } className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="expected_ship_date"  onFocus={ this.onFocus } value={ this.state.item.expected_ship_date } onBlur={this.handleShipDate} disabled={ this.props.mode }  className="form-control" onChange={ this.handleInputChange }  /></td>
				<td><input name="unit_net_price" type="text" maxLength="20" onKeyDown={ this.handleInputNumber } value={ this.state.item.unit_net_price } onBlur={this.handleTotalPrice}  disabled={ this.props.mode } className="form-control" onChange={ this.handleInputChange } /></td>
				<td><input name="net_amount" type="text" maxLength="40" onKeyDown={ this.handleInputNumber } value={ this.state.item.net_amount } disabled={ this.props.mode } className="form-control" onChange={ this.handleInputChange } /></td>
				<td><button type="submit" className="btn btn-default" style={{size: '5'}} disabled={ this.props.mode } onClick={ this.handleRemoveLine }><span className="glyphicon glyphicon-minus style={{size: '5'}}"></span></button></td>
				 
			</tr>
	    	
			
		);
	}
}



export default Orders;

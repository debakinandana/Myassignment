angular.module('sdmApp')
    .service('UserService', function ($http, URLS) {
        return $http.get(URLS.profileUrl)
            .success(function (res) {
                appInsights.setAuthenticatedUserContext(res.alias);
            });
	   
	})
    .service('LogoutService', function ($http, URLS, alerting) {
        this.logout = function () {
            return $http.post(URLS.signout)
	            .success(function (res) {
	                alerting('success', 'You have successfully logged out!');
	            });
        };
    }).service('profileService', function ($http, URLS) {
        return $http.get(URLS.profileUrl);
    }).service('sdmSiteRefresh', function ($http, URLS) {
        return $http.get(URLS.siteRefresh);
    })
.service('SDMRefreshService', function ($http, URLS) {
    this.refresh = function () {
        return $http.get(URLS.sdmrefresh)
            .success(function (res) {
            });
    };

});
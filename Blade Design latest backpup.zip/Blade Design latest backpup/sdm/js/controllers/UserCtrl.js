(function () {
    angular.module("sdmApp")
        .controller('UserCtrl', function ($rootScope, $state, $window, UserService, alerting, LogoutService, SDMRefreshService, TOAST_MESSAGE, DomainService,SharedService) {
            var uservm = this;
            if (!$rootScope.loadDefaultView) {
                DomainService.getUserDetail().success(function (response) {
                    uservm.userInfo = response;
                    $rootScope.$broadcast('ProfileData', response);
                    if (uservm.userInfo.isAdmin === false && $window.location.href.indexOf("administration") > -1) {
                        $state.go('home');
                    }
                })
            }
            else {
                UserService.success(function (res) {
                    uservm.userInfo = res;
                    $rootScope.$broadcast('ProfileData', res);
                    if (uservm.userInfo.isAdmin === false && $window.location.href.indexOf("administration") > -1) {
                        $state.go('home');
                    }

                });
            }
            $rootScope.$on('updateUserView', function () {
                if (!$rootScope.loadDefaultView) {
                    DomainService.getUserDetail().success(function (res) {
                        uservm.userInfo = res;
                        $rootScope.$broadcast('ProfileData', res);
                        if (uservm.userInfo.isAdmin === false && $window.location.href.indexOf("administration") > -1) {
                            $state.go('home');
                        }
                    })
                }
                else {
                    UserService.success(function (res) {
                        uservm.userInfo = res;
                        $rootScope.$broadcast('ProfileData', res);
                        if (uservm.userInfo.isAdmin === false && $window.location.href.indexOf("administration") > -1) {
                            $state.go('home');
                        }

                    });
                }
            })
            uservm.logout = function () {
                LogoutService.logout();
            };
            uservm.refresh = function () {
                SharedService.logEvent('Site Refresh', { itemTypeId: null, title: null, version: null, rating: null, comment: null, url: null, ComplexityType:null})
                SDMRefreshService.refresh().success(function () {
                    alerting.addAlert('success', TOAST_MESSAGE.SITE_REFRESH_SUBMITTED);
                    $window.location.reload();
                });

            };
            $rootScope.$on('updateVisioDetails', function (e, visioDetail) {
                uservm.userInfo = visioDetail;
                if (!uservm.userInfo.jobTitle) {
                    UserService.success(function (res) {
                        uservm.userInfo.jobTitle = res.jobTitle;
                        uservm.userInfo.isAdmin = res.isAdmin;
                        uservm.userInfo.displayName = res.displayName;
                        uservm.userInfo.profileImageUrl = res.profileImageUrl;
                        $rootScope.$broadcast('ProfileData', res);
                        if (uservm.userInfo.isAdmin === false && $window.location.href.indexOf("administration") > -1) {
                            $state.go('home');
                        }

                    });
                }
               
            });
        })
        .controller('WhatsnewCtrl', function ($rootScope, WhatsnewService) {
            var whatsnewvm = this;
            whatsnewvm.togglePin = function () {
                whatsnewvm.userInfo.showWhatsNew = !whatsnewvm.userInfo.showWhatsNew
                WhatsnewService.updatePinStatus({ showWhatsNew: whatsnewvm.userInfo.showWhatsNew }).success(function (data) {
                });
            };
            var ProfileData = $rootScope.$on('ProfileData', function (e, res) {
                whatsnewvm.userInfo = res;

            });
            WhatsnewService.getContent().success(function (res) {
                whatsnewvm.whatsnew = res;
                whatsnewvm.description = whatsnewvm.whatsnew.description;
                $rootScope.$broadcast('pinStatus', whatsnewvm.whatsnew.showWhatsNew);

            });


        });

})();

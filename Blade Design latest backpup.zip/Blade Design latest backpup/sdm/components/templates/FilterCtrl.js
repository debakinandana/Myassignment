(function () {
    angular.module("sdmApp")
        .controller('FilterCtrl', function ($state, $rootScope, FilterService, $scope, $http) {
            var filtervm = this;

            filtervm.selectedPhase = [];
            filtervm.selectedRoles = [];
            $rootScope.roleIds = filtervm.selectedRoles;
            filtervm.selectedParentPhases = [];
            if ($rootScope.userMethodologyId === undefined) {
                FilterService.getUserDetail().success(function (response) {
                    FilterService.getPhases(response.selectedMethodologyId).success(function (res) {
                        filtervm.phases = res;
                    });
                })

            }
            else {
                FilterService.getPhases($rootScope.userMethodologyId).success(function (res) {
                    filtervm.phases = res;
                })
            }

            FilterService.getRoles().success(function (res) {
                filtervm.roles = res;
            });



            var filterIds = [], count = 0, childChecked = 0;

            filtervm.checkAll = function (checkAll, isChecked, searchText) {
                filterIds = [];
                filtervm.selectedParentPhases = [];
                if (isChecked) {
                    filtervm.phases.forEach(function (itemObj) {
                        filtervm.selectedParentPhases.push({ items: itemObj.subPhases, itemName: itemObj.phaseName })
                    })
                    for (var i = 0; i < filtervm.phases.length; i++) {
                        for (var j = 0; j < filtervm.phases[i].subPhases.length; j++) {
                            filterIds.push(filtervm.phases[i].subPhases[j].phaseId);
                        }
                    }
                    multipleSelectedPhase
                }
                else {
                    filterIds = [];
                }
                for (var i = 0; i < filtervm.phases.length; i++) {
                    filtervm.phases[i].checked = isChecked;
                    for (var j = 0; j < filtervm.phases[i].subPhases.length; j++) {
                        filtervm.phases[i].subPhases[j].checked = isChecked;
                    }
                }
                $rootScope.$emit("phaseFilterChanged", filterIds, searchText);
            }
            filtervm.multipleSelectedPhase = function (phases, isChecked, index, e, searchText) {
                count += 1;
                var selectedListfilterIds = [];
                filtervm.phases[index].checked = !filtervm.phases[index].checked;

                //if (filtervm.phases[index].checked) {
                //    filtervm.selectedParentPhases.push({ items: filtervm.phases[index].subPhases, itemName: e.currentTarget.getAttribute('data-label-name') });


                //}
                //else if (!filtervm.phases[index].checked) {
                //    var counter = 0;
                //    for (var i = 0; i < filtervm.selectedParentPhases.length; i++) {
                //        if (filtervm.selectedParentPhases[i].itemName === e.currentTarget.getAttribute('data-label-name'))
                //            filtervm.selectedParentPhases.splice(i, 1);
                //    }

                //}
                for (var i = 0; i < filtervm.phases[index].subPhases.length; i++) {
                    filtervm.phases[index].subPhases[i].checked = filtervm.phases[index].checked;
                }
                //if (filtervm.selectedParentPhases.length > 0) {
                //    for (var i = 0; i < filtervm.selectedParentPhases.length; i++) {
                //        for (var j = selectedListfilterIds.length; j < filtervm.selectedParentPhases[i].items.length; j++) {
                //            selectedListfilterIds.push(filtervm.selectedParentPhases[i].items[j].phaseId)
                //        }
                //    }
                //}
                //filterIds = filterIds.length ? filterIds : selectedListfilterIds;
                //filterIds.forEach(function (filterId) {
                //    filtervm.phases[index].subPhases.map(function (subPhasesObj) {
                //        if (subPhasesObj.checked) {
                //            var result = filterIds.find(function (elem) {
                //                return elem === filterId;
                //            });
                //            console.log(result);
                //        }
                //    })
                //})
                filterIds = [];
                filtervm.phases.forEach(function (phaseObj) {
                    phaseObj.subPhases.forEach(function (subPhaseObj) {
                        if (subPhaseObj.checked) {
                            filterIds.push(subPhaseObj.phaseId)
                        }
                    })
                })
                //if (count === filtervm.phases.length) {
                //    filtervm.checkAllFilter = filtervm.phases[index].checked;
                //    if (!filtervm.phases[index].checked) {
                //        selectedListfilterIds = [];
                //    }
                //    count = 0;
                //}

                $rootScope.$emit("phaseFilterChanged", filterIds, searchText);
            };
            filtervm.singleSelectedPhase = function (phaseId, parentIndex, isChecked, searchText) {
                filterIds = [];
                for (var j = 0; j < filtervm.phases[parentIndex].subPhases.length; j++) {
                    if (filtervm.phases[parentIndex].subPhases[j].phaseId === phaseId) {
                        filtervm.phases[parentIndex].subPhases[j].checked = isChecked;
                        childChecked += 1;
                    }
                }
                if (childChecked === filtervm.phases[parentIndex].subPhases.length) {
                    filtervm.phases[parentIndex].checked = isChecked;
                    childChecked = 0;
                }
                for (var i = 0; i < filtervm.phases.length; i++) {
                    for (var j = 0; j < filtervm.phases[i].subPhases.length; j++) {
                        if (filtervm.phases[i].subPhases[j].checked) {
                            filterIds.push(filtervm.phases[i].subPhases[j].phaseId)
                        }
                    }
                }
                $rootScope.$emit("phaseFilterChanged", filterIds, searchText);

            };

            filtervm.multiSelectedRoles = function (roleHeader, searchText) {
                angular.forEach(filtervm.roles, function (role) {
                    role.Selected = roleHeader;
                    if (roleHeader) {
                        filtervm.selectedRoles.push(role.roleId);

                    } else {
                        filtervm.selectedRoles = [];
                        return;
                    }

                });
                console.log(filtervm.selectedRoles);
                $rootScope.$emit("roleFilterChanged", filtervm.selectedRoles, $rootScope.complexityId, searchText);
            };
            filtervm.singleSelectedRole = function (roleId, searchText) {
                var filterIndex = filtervm.selectedRoles.indexOf(roleId)
                if (filterIndex > -1) {
                    filtervm.selectedRoles.splice(filterIndex, 1);
                } else {
                    filtervm.selectedRoles.push(roleId);
                }
                $rootScope.$emit("roleFilterChanged", filtervm.selectedRoles, $rootScope.complexityId, searchText);

            };
        });
})();

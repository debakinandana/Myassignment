angular.module('sdmApp').directive("focusSubitem", ['$timeout', function ($timeout) {
    return {
        link: function ($scope, element, attrs) {
            element.on('focus', function () {
                alert('hello')
            })
        }
    }
}]);
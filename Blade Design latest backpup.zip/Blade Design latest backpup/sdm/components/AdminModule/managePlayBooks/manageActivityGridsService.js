(function () {
    angular.module('sdmApp')
        .service('managePlayBooksService', function ($http, URLS) {
            
            this.getPlayBooks = function () {
                return $http.get(URLS.adminPlayBookList);
            };
            this.addPlayBook = function (data) {
               return $http.patch(URLS.adminPlayBookList , data);
            };
            
        });
})();
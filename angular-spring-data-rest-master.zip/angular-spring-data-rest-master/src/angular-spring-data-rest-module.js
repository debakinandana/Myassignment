/**
 * @module spring-data-rest
 * @version <%= pkg.version %>
 *
 * An AngularJS module to ease the work with a Spring Data REST backend.
 */
angular.module("spring-data-rest", ["ngResource"]);

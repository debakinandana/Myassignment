(function () {

    function sidebarController() {
        var exportvm = this;
        $(function () {
            $('.toggle-sidebar').click(function () {
                toggleSideBar();
            });
        });

        $(".menu-toggle").click(function (e) {
            e.preventDefault();
            $("#wrapper").toggleClass("active");
        });
        function toggleSideBar() {

            if ($('#sidebar-wrapper').hasClass('show-sidebar')) {
                // Do things on Nav Close
                $('#sidebar-wrapper').removeClass('show-sidebar');
            } else {
                // Do things on Nav Open
                $('#sidebar-wrapper').addClass('show-sidebar');
            }
            //$('#site-wrapper').toggleClass('show-nav');
        }
    }
    angular.module('sdmApp').controller('sidebarController', sidebarController);
})();
(function () {
    function adminMethodCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminMethodService, alerting, TOAST_MESSAGE, $scope) {
        var adminMethodvm = this;
        adminMethodvm.$state = $state;
        adminMethodvm.solutionMethod = [];
        adminMethodvm.totalItems = 0;
        adminMethodvm.isRequired = false;
        adminMethodvm.pageSize = 10;
        adminMethodvm.pagination = {
            current: $state.params.page
        };
        adminMethodvm.searchFilter = {
            title: ''
        };
        adminMethodvm.tinymceOptions = {
            selector: "textarea",
            menubar: false,
            statusbar: false,
            content_css: 'components/common/commoncss/tinymce.css',
            plugins: ['advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools', 'codesample'],
            toolbar: 'undo redo | insert | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image | code | codesample | forecolor | backcolor',
            custom_undo_redo_levels: 10,
            textcolor_rows: "4",
            browser_spellcheck: true,
            table_default_attributes: {
                'border': 1, 'width': 300, 'height': 100, 'cellspacing': 0
            },
            contextmenu: 'inserttable | cell row column deletetable',
            extended_valid_elements: ['script[src|type|language]', 'img[class|src|alt|title|height|width|style]', 'div[rel|class|id]'],
            codesample_languages: [
                { text: 'HTML/XML', value: 'markup' },
                { text: 'JavaScript', value: 'javascript' }
            ]
        };
        function getResultsPage() {
            adminMethodService.getMethods({ pageNumber: adminMethodvm.pagination.current, searchValue: encodeURIComponent(adminMethodvm.searchFilter.title) }).success(function (res) {
                adminMethodvm.solutionMethod = res.solutionMethod;
                adminMethodvm.solMethodParentsList = res.solMethodParentsList;
                adminMethodvm.projectComplexity = res.projectComplexity;
                adminMethodvm.totalItems = res.count;
                adminMethodvm.domains = res.domains;
                adminMethodvm.methodObj = {};
                adminMethodvm.methodObj.isComplexity = true;
                adminMethodvm.methodObj.governanceMergeInputs = new Array(res.projectComplexity.length);
            });
        }
        if ($state.current.name === "AdminMain.administration.manageMethods" || $state.current.name === "AdminMain.administration.manageMethods.addMethod") {
            getResultsPage();
        }


        $rootScope.$on('updatedResults', function (e, data) {
            adminMethodvm.solutionMethod = data;
        });

        adminMethodvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminMethodvm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminMethodvm.searchMethod = function (title) {
            adminMethodvm.searchFilter.title = title;
            getResultsPage();
        };
        adminMethodvm.selectGoverenceChange = function (complexityId, governenceId) {
            var count = 0;
            adminMethodvm.methodObj.governanceMergeInputs[complexityId - 1] = parseInt(governenceId, 10);
            for (var i = 0; i < adminMethodvm.methodObj.governanceMergeInputs.length; i++) {
                if (adminMethodvm.methodObj.governanceMergeInputs[i] === undefined || isNaN(adminMethodvm.methodObj.governanceMergeInputs[i])) {
                    adminMethodvm.methodObj.governanceMergeInputs[i] = -1;
                }
            }
            for (var i = 0; i < adminMethodvm.methodObj.governanceMergeInputs.length; i++) {
                if (adminMethodvm.methodObj.governanceMergeInputs[i] === undefined || adminMethodvm.methodObj.governanceMergeInputs[i] === -1 || isNaN(adminMethodvm.methodObj.governanceMergeInputs[i])) {
                    count += 1;
                }
            }
            adminMethodvm.isRequired = count === adminMethodvm.methodObj.governanceMergeInputs.length && adminMethodvm.methodObj.includeInProcessStep;
        }

        adminMethodvm.DeleteConfirm = function (method) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteMethodCtrl',
                resolve: {
                    selectedItem: function () {
                        return method;
                    }
                }
            });
        };
        adminMethodvm.updateMethods = function (response) {
            if (response.status) {
                if ($state.current.name === "AdminMain.administration.manageMethods.editMethod") {
                    alerting.addAlert('success', TOAST_MESSAGE.METHOD_UPDATED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.METHOD_ADDED);
                }
                $state.go('AdminMain.administration.manageMethods', {}, { reload: true });
            }
            else {
                if (response.errorMsg) {
                    alerting.addAlert('danger', response.errorMsg);
                }
            }
        }
        adminMethodvm.submitForm = function () {
            adminMethodvm.formSubmitted = true;
            var count = 0;
            if (adminMethodvm.methodObj.includeInProcessStep) {
                for (var i = 0; i < adminMethodvm.methodObj.governanceMergeInputs.length; i++) {
                    if (adminMethodvm.methodObj.governanceMergeInputs[i] === undefined || adminMethodvm.methodObj.governanceMergeInputs[i] === -1) {
                        count += 1;
                    }

                }
                adminMethodvm.isRequired = count === adminMethodvm.methodObj.governanceMergeInputs.length && adminMethodvm.methodObj.includeInProcessStep;
                $scope.methodForm.$valid = count === adminMethodvm.methodObj.governanceMergeInputs.length && adminMethodvm.methodObj.includeInProcessStep ? false : $scope.methodForm.$valid;
            }
            else {
                adminMethodvm.isRequired = false;
                for (var i = 0; i < adminMethodvm.methodObj.governanceMergeInputs.length; i++) {
                    adminMethodvm.methodObj.governanceMergeInputs[i] = -1;

                }
            }
            if ($scope.methodForm.$valid) {
                if ($state.current.name === "AdminMain.administration.manageMethods.addMethod") {

                    adminMethodService.addMethod(adminMethodvm.methodObj).success(function (response) {
                        adminMethodvm.updateMethods(response);
                    })
                }
                else {
                    adminMethodService.editMethod(adminMethodvm.methodObj).success(function (response) {
                        adminMethodvm.updateMethods(response);
                    })
                }

            }
        }
        function getMethodDetails(methodId) {
            adminMethodService.getMethod(methodId).success(function (res) {
                if (res) {
                    if (res.solutionMethod.length) {
                        adminMethodvm.methodObj = res.solutionMethod[0];
                        adminMethodvm.solMethodParentsList = res.solMethodParentsList;
                        adminMethodvm.domains = res.domains;
                        adminMethodvm.methodObj.governanceMergeInputs = new Array(adminMethodvm.methodObj.projectComplexity.length);
                        adminMethodvm.projectComplexity = adminMethodvm.methodObj.projectComplexity;
                        adminMethodvm.methodObj.governanceMergeInputs
                        var selected = null;
                        for (var i = 0; i < adminMethodvm.projectComplexity.length; i++) {
                            //adminMethodvm['complexity' + adminMethodvm.projectComplexity[i].id] = 'complexity' + adminMethodvm.projectComplexity[i].id
                            for (var j = 0; j < adminMethodvm.projectComplexity[i].complexityGovernanceList.length; j++) {
                                if (adminMethodvm.projectComplexity[i].complexityGovernanceList[j].isSelected) {
                                    adminMethodvm['complexity' + adminMethodvm.projectComplexity[i].id] = adminMethodvm.projectComplexity[i].complexityGovernanceList[j].id;
                                    adminMethodvm.methodObj.governanceMergeInputs[i] = adminMethodvm.projectComplexity[i].complexityGovernanceList[j].id;
                                }
                                else {
                                    if (adminMethodvm['complexity' + adminMethodvm.projectComplexity[i].id] === undefined) {
                                        adminMethodvm['complexity' + adminMethodvm.projectComplexity[i].id] = "";
                                        adminMethodvm.methodObj.governanceMergeInputs[i] = -1;
                                    }
                                }
                                //adminMethodvm['complexity' + adminMethodvm.projectComplexity[i].id] = 'complexity' + adminMethodvm.projectComplexity[i].id;
                                //adminMethodvm.projectComplexity[i]['complexity' + adminMethodvm.projectComplexity[i].id] = adminMethodvm.projectComplexity[i].complexityGovernanceList[j].isSelected ? adminMethodvm.projectComplexity[i].complexityGovernanceList[j].id:"";
                            }
                            console.log(selected)
                            // adminMethodvm.projectComplexity[i]['complexity' + adminMethodvm.projectComplexity[i].id] = selected;

                        }
                        console.log(adminMethodvm.projectComplexity)
                    }
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.manageMethods.editMethod") {

            getMethodDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
        .controller('adminMethodCtrl', adminMethodCtrl)
        .controller('deleteMethodCtrl', function ($rootScope, $scope, $uibModalInstance, adminMethodService, alerting, TOAST_MESSAGE, selectedItem, $state) {
            $scope.getResultsPage = function () {
                adminMethodService.getMethods().success(function (res) {
                    $scope.solutionMethod = res.solutionMethod;
                });
            }

            $scope.selectedMethod = selectedItem;
            $scope.title = selectedItem.title;
            $scope.deleteItem = function (selectedItem) {

                adminMethodService.deleteMethod($scope.selectedMethod.id).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.METHOD_DELETED);
                        $rootScope.$emit("updatedResults", res.solutionMethod);
                        $state.go('AdminMain.administration.manageMethods', {}, { reload: true });
                    }
                    else {
                        alerting.addAlert('danger', res.errorMsg);
                    }
                });
                $scope.cancel();
            }
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
})();
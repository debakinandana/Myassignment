(function () {
    angular.module('sdmApp').directive('addCustomFields', [function () {
        self = this, keys = null, keyName = null;
        return {
            restrict: "EA",
            templateUrl: "components/AdminModule/addActivity/addCustomFields.html",
            scope: {
                listModel: '=',
                labelName: '@',
                isTextAreaEnabled: '@',
                isTextAreaRequired: '@',
                isTextBoxEnabled: '@',
                isTextBoxRequired: '@',
                isDropDownEnabled: '@',
                isDropDownRequired: '@',
                dropDownModel:'@'
            },
            link: {
                pre: function (scope, elem, attrs) {
                    scope['directiveObj'] = {};
                    console.log(attrs.$attr)
                    keys = Object.keys(attrs.$attr);
                    console.log(keys);
                    //console.log(attrs[keys[0]])
                    for (var i in keys) {
                        scope["directiveObj"]["keyNames" + i.toString()] = keys[i] + i.toString();
                        scope['directiveObj']["keys"+i.toString()] = JSON.parse(attrs[keys[i]]);


                    }
                    console.log(scope);
                },
                selectAll: function (targetObj) {

                },
                selectItemFromList: function ($event, targetElem, targetContainer) {
                    console.log($event)
                }
            }
        };
    }])
})();
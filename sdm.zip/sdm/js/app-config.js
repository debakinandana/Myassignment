angular.module('sdmApp')
    .config(function ($stateProvider, $urlRouterProvider, $ocLazyLoadProvider) {

        $stateProvider
            .state('home', {
                url: '/',
                title: 'Home',
                templateUrl: 'home.html',
                data: {
                    displayName: 'Home'
                },
                resolve: {
                    VisioDetail: ['$rootScope', '$stateParams', 'UserService', 'VisioDetailService', 'profileService', 'alerting', 'sdmSiteRefresh', '$q', '$http', function ($rootScope, $stateParams, UserService, VisioDetailService, profileService, alerting, sdmSiteRefresh, $q, $http) {
                        return UserService.success(function (userInfo) {
                            if (userInfo.status) {
                                return VisioDetailService.getVisioDetail(userInfo.visioFilePath)
                                    .success(function (res) {
                                        if (res) {
                                            $rootScope.$broadcast('gotVisioDetail', res);
                                            $rootScope.$emit('resetDomainAndMetholody')
                                            window.localStorage.setItem('userMethodologyId', res.methodId);
                                            window.localStorage.setItem('userMethodologyName', res.methodName);
                                            window.localStorage.setItem('userPhasName', res.phaseName);
                                            window.localStorage.setItem('userPhasId', res.phaseId);
                                            return res;
                                        }
                                    });
                            }
                            else {
                                alerting.addAlert('danger', userInfo.errorMsg);
                                window.location.href = '/sdm/Error?message=' + userInfo.errorMsg + '';
                            }

                        });

                    }],
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/rating.css'
                                ]
                            }
                        ]);
                    }
                }

            })
            //.state('newsletter', {
            //    url: '/newsletter',
            //    title: 'Newsletter',
            //    templateUrl: 'components/newsletter/newsletter.html',
            //    data: {
            //        displayName: 'Newsletter'
            //    },
            //    onEnter: function ($location, $anchorScroll) {
            //        $location.hash('top');
            //        $anchorScroll();
            //    }
            //})
            .state('favorites', {
                url: '/favorites?page&sort',
                params: {
                    page: {
                        value: '1'
                    },
                    sort: {
                        value: 'title'
                    }
                },
                abstract: true,
                controller: 'FavoritesCtrl',
                controllerAs: 'favvm',
                templateUrl: 'components/favorites/favorites.html',
                title: 'Favorites',
                data: {
                    displayName: 'Favorites'
                },
                resolve: {

                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/common/commoncss/forms.css',
                                    'components/common/commoncss/notification.css',
                                    'components/templates/popover.css',
                                    'components/common/commoncss/rating.css'
                                    //'components/templates/templates.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/favorites/FavoritesCtrl.js',
                                    'components/favorites/FavoriteService.js',
                                    'components/activities/ActivitiesService.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/common/filters/truncate.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                    'components/common/filters/trustAsResourceUrl.js'

                                ]
                            }
                        ]);
                    }
                }
            })
            .state('favorites.list', {
                url: '/list',
                title: 'Favorites List View',
                templateUrl: 'components/favorites/favorites-list.html',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/templates/elemFocusDirective.js'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('favorites.grid', {
                url: '/grid',
                title: 'Favorites Grid View',
                templateUrl: 'components/favorites/favorites-grid.html',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/activities/ActivitiesService.js',
                                    'components/templates/elemFocusDirective.js'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('methodology', {
                url: '/methodology/:selectedMethodologyVisio',
                params: { selectedMethodologyId: null, solutionMethodName: null, phaseDescription: null },
                templateUrl: 'components/methodology/methodology.html',
                controller: 'MethodologyCtrl',
                controllerAs: 'mthodvm',
                title: 'Methodology',
                data: {
                    displayName: '{{ VisioDetail.data.title }}'
                },
                resolve: {
                    VisioDetail: ['$rootScope', '$stateParams', 'VisioDetailService', 'sdmSiteRefresh', 'alerting', '$q', '$http', function ($rootScope, $stateParams, VisioDetailService, sdmSiteRefresh, alerting, $q, $http) {

                        var visioPath = $stateParams.selectedMethodologyVisio;
                        if (/svg_2.svg$/.test(visioPath)) {
                            visioPath = visioPath.replace('svg_2.svg', 'svg_1.svg');
                        }
                        return VisioDetailService.getVisioDetail(visioPath).success(function (res) {
                            $rootScope.$broadcast('gotVisioDetail', res);
                            $rootScope.$broadcast('methodologyVisio', res);
                            return res;
                        });
                    }],
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/methodology/methodology.css',
                                    'components/common/commoncss/icon-list.css',
                                    'components/common/pagination/pagination.css',
                                    'components/common/commoncss/rating.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/templates/popover.css',
                                    'components/templates/focusParentDirective.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/methodology/MethodologyCtrl.js',
                                    'components/templates/TemplateService.js',
                                    'components/templates/FilterCtrl.js',
                                    'components/templates/FilterService.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('templates', {
                url: '/templates?page&sort',
                params: {
                    page: {
                        value: '1'
                    },
                    sort: {
                        value: 'title'
                    }
                },
                abstract: true,
                title: 'Templates',
                controller: 'TemplatesCtrl',
                controllerAs: 'templatevm',
                templateUrl: 'components/templates/templates.html',
                data: {
                    displayName: 'Templates'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/templates/popover.css',
                                    'components/common/commoncss/notification.css',
                                    'components/common/commoncss/forms.css',
                                    'components/common/commoncss/rating.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/templates/elemFocusDirective.js',
                                    'components/templates/TemplatesCtrl.js',
                                    'components/templates/TemplateService.js',
                                    'components/templates/FilterCtrl.js',
                                    'components/templates/FilterService.js',
                                    'components/common/filters/trustAsResourceUrl.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                    'components/common/filters/truncate.js',
                                    'components/templates/focusParentDirective.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('templates.list', {
                url: '/list',
                title: 'Templates List View',
                templateUrl: 'components/templates/templates-list.html'
            })
            .state('templates.grid', {
                url: '/grid',
                title: 'Templates Grid View',
                templateUrl: 'components/templates/templates-grid.html'
            })
            .state('templateDetail', {
                url: '/templates/:id/detail',
                title: 'Template Detail',
                controller: 'TemplateDetailCtrl',
                controllerAs: 'templateDetailvm',
                templateUrl: 'components/TemplateDetail/template-detail.html',
                data: {
                    displayName: 'Template Detail'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/templates/popover.css',
                                    'components/common/commoncss/notification.css',
                                    'components/TemplateDetail/template-detail.css',
                                    'components/common/commoncss/rating.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/TemplateDetail/TemplateDetailCtrl.js',
                                    'components/TemplateDetail/TemplateDetailService.js',
                                    'components/templates/TemplateService.js',
                                    'components/common/filters/trustAsResourceUrl.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('activities', {
                url: '/activities?page&sort',
                params: {
                    page: {
                        value: '1'
                    },
                    sort: {
                        value: 'title'
                    }
                },
                abstract: true,
                title: 'Activities',
                controller: 'ActivitiesCtrl',
                controllerAs: 'activitiesvm',
                templateUrl: 'components/activities/activities.html',
                data: {
                    displayName: 'Activities'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/activities/activities.css',
                                    'components/common/commoncss/forms.css',
                                    'components/common/commoncss/rating.css',
                                    'components/common/commoncss/notification.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/activities/ActivitiesCtrl.js',
                                    'components/activities/ActivitiesService.js',
                                    'components/templates/FilterCtrl.js',
                                    'components/templates/FilterService.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                    'components/common/filters/truncate.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/templates/focusParentDirective.js',
                                    'components/templates/elemFocusDirective.js'
                                ]
                            }
                        ]);
                    }
                }
            }).state('activities.activityContent', {
                url: '/activities/:id/activityContent',
                params: {

                },
                abstract: true,
                title: 'Activity Content',
                controller: 'ActivityContentCtrl',
                controllerAs: 'activityContentCtrl',
                templateUrl: 'components/activityContent/activityContent.html',
                data: {
                    displayName: 'Activity Content'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/activities/activities.css',
                                    'components/common/commoncss/forms.css',
                                    'components/common/commoncss/rating.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/activities/activityContentCtrl.js',
                                    'components/activities/ActivitiesService.js',
                                    'components/templates/focusParentDirective.js',
                                    'components/templates/elemFocusDirective.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('activities.list', {
                url: '/list',
                title: 'Activities List View',
                templateUrl: 'components/activities/activities-list.html'
            })
            .state('activities.grid', {
                url: '/grid',
                title: 'Activities Grid View',
                templateUrl: 'components/activities/activities-grid.html'
            })
            .state('activityDetail', {
                url: '/activities/:id/detail',
                title: 'Activity Detail',
                controller: 'ActivityDetailCtrl',
                controllerAs: 'activityDetailvm',
                templateUrl: 'components/ActivityDetail/activity-detail.html',
                data: {
                    displayName: 'Activity Detail'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    'components/common/commoncss/rating.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/common/commoncss/notification.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/ActivityDetail/ActivityDetailCtrl.js',
                                    'components/ActivityDetail/ActivityDetailService.js',
                                    'components/favorites/FavoriteService.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/common/filters/truncate.js',
                                    'components/common/filters/htmlToPlaintext.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('topics', {
                url: '/topics',
                title: 'Topics',
                controller: 'TopicsCtrl',
                controllerAs: 'topicvm',
                templateUrl: 'components/topics/topicCategory.html',
                data: {
                    displayName: 'Topics'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/topics/topics.css',
                                    'components/common/commoncss/rating.css'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'vendor/masonry.pkgd.min.js',
                                    'components/topics/setHeightDirective.js',
                                    'components/favorites/FavoriteService.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/common/filters/truncate.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                    'components/topics/TopicsCtrl.js',
                                    'components/topics/TopicService.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('topics.detail', {
                url: '/:topicName?id',
                title: 'Topic Detail',
                data: {
                    displayName: '{{topicName}}'
                },
                params: {
                    id: {
                        value: '{{topicId}}'
                    },
                    ref: {
                        value: '{{referrerCode}}'
                    }

                },
                templateUrl: 'components/topics/topicDetail.html',
                resolve: {
                    topicName: ['$rootScope', '$stateParams', function ($rootScope, $stateParams, $state) {
                        console.log($state);
                        window.localStorage.setItem('currentUrl', window.location.hash);
                        $rootScope.$emit('getSelectedTopicDetails', $stateParams.topicName, $stateParams.id, window.location.hash.search('#/topics') >= 0 ? true : false);
                        return $stateParams.topicName;
                    }],
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/topics/topics.css',
                                    'components/common/commoncss/rating.css'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/favorites/FavoriteService.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/common/filters/truncate.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                ]
                            }
                        ]);
                    }
                }
            })

            .state('search', {
                url: '/search?page&sort',
                params: {
                    page: {
                        value: '1'
                    },
                    sort: {
                        value: '0'
                    }
                },
                title: 'Search',
                abstract: true,
                controller: 'SearchCtrl',
                controllerAs: 'searchvm',
                templateUrl: 'components/search/search.html',
                data: {
                    displayName: 'Search Results'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/commoncss/card.css',
                                    //'components/common/commoncss/tooltip.css',
                                    'components/common/commoncss/notification.css',
                                    'components/templates/popover.css',
                                    'components/common/commoncss/rating.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/clipboard/angular-clipboard.js'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/search/SearchCtrl.js',
                                    'components/activities/ActivitiesService.js',
                                    'components/search/SearchService.js',
                                    'components/common/filters/arrayjoin.js',
                                    'components/favorites/FavoriteService.js',
                                    'components/common/filters/trustAsResourceUrl.js',
                                    'components/common/filters/htmlToPlaintext.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('search.list', {
                url: '/list/:searchText',
                title: 'Search List View',
                templateUrl: 'components/search/search-list.html',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/templates/elemFocusDirective.js',
                                    'components/activities/ActivitiesService.js'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('search.grid', {
                url: '/grid/:searchText',
                title: 'Search Grid View',
                templateUrl: 'components/search/search-grid.html',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/templates/elemFocusDirective.js',
                                    'components/activities/ActivitiesService.js'
                                ]
                            }
                        ])
                    }
                }
            }).state('ExtractMethodology', {
                url: '/ExtractMethodology',
                title: 'Export Methodologies',
                controller: 'ExportMethodCtrl',
                controllerAs: 'exportvm',
                templateUrl: 'components/ExtractMethodology/extractMethodology.html',
                data: {
                    displayName: 'Export Methodologies'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [

                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/ExtractMethodology/extractMethodologyCtrl.js',
                                    'components/ExtractMethodology/extractMethodologyService.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('BladeDesign', {
                url: '/BladeDesign',
                title: 'BladeDesign',
                controller: 'sidebarController',
                controllerAs: 'exportvm',
                templateUrl: 'components/BladeDesign/sidebar.html',
                data: {
                    displayName: 'BladeDesign'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css',

                                    'components/BladeDesign/simple-sidebar.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [

                                    'components/BladeDesign/sidebarCtrl.js',
                                    'components/BladeDesign/homeController.js',
                                    'components/ExtractMethodology/extractMethodologyService.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            }).state('solutionmethod', {
                url: '/solutionmethodPage',
                title: 'solutionmethods',
                controller: 'HomeController',
                controllerAs: 'exportvm',
                templateUrl: 'components/BladeDesign/home.html',
                data: {
                    displayName: 'solutionmethods'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css',

                                    'components/BladeDesign/simple-sidebar.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [

                                    'components/BladeDesign/sidebarCtrl.js',
                                    'components/BladeDesign/homeController.js',

                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            }).state('solutionMethods', {
                url: '/solutionMethods',

                controller: 'HomeController',
                controllerAs: 'exportvm',
                templateUrl: 'components/BladeDesign/childPage.html',
                data: {
                    displayName: 'solutionMethods'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [


                                    'components/BladeDesign/simple-sidebar.css'
                                ]
                            },

                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [

                                    'components/BladeDesign/sidebarCtrl.js',
                                    'components/BladeDesign/homeController.js',

                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);
                    }
                }
            })
            .state('AdminMain', {
                abstract: true,
                templateUrl: 'components/AdminModule/AdminMain.html',
                controller: 'AdminCtrl',
                controllerAs: 'adminvm',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/AdminService.js',
                                    'components/AdminModule/AdminCtrl.js'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('AdminMain.administration', {
                url: '/administration',
                title: 'Administration',
                templateUrl: 'components/AdminModule/Administration.html',
                data: {
                    displayName: 'Administration'
                },
                controller: 'AdminCtrl',
                controllerAs: 'adminvm',
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css'
                                ]
                            }
                        ])
                    }
                }
            })

            .state('AdminMain.administration.manageActivities', {
                url: '/manageActivities',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Activities',
                templateUrl: 'components/AdminModule/addActivity/manageActivity.html',
                controller: 'activityController',
                controllerAs: 'activityCtrl',
                data: {
                    displayName: 'Manage Activities'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addActivity/adminActivityService.js',
                                    'components/AdminModule/addActivity/adminActivityCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageActivities.addActivity', {
                url: '/addNewActivity',
                title: 'Add New Activity',
                templateUrl: 'components/AdminModule/addActivity/addActivity.html',
                controller: 'addActivityController',
                controllerAs: 'addActivityCtrl',
                data: {
                    displayName: 'Add new activity'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css'

                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addActivity/adminActivityService.js',
                                    'components/AdminModule/addActivity/adminActivityCtrl.js',
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addActivity/addCustomFieldDirective.js',
                                    'components/AdminModule/addActivity/addCustomFields.html',
                                    'components/AdminModule/addActivity/activityForm.html'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('AdminMain.administration.manageActivities.editActivity', {
                url: '/:id/edit',
                title: 'Edit Activity',
                templateUrl: 'components/AdminModule/addActivity/addActivity.html',
                controller: 'addActivityController',
                controllerAs: 'addActivityCtrl',
                data: {
                    displayName: 'Edit activity'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css'

                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addActivity/adminActivityService.js',
                                    'components/AdminModule/addActivity/adminActivityCtrl.js',
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addActivity/addCustomFieldDirective.js',
                                    'components/AdminModule/addActivity/addCustomFields.html'
                                ]
                            }
                        ])
                    }
                }
            })

            .state('AdminMain.administration.manageTemplates', {
                url: '/manageTemplates',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage templates',
                templateUrl: 'components/AdminModule/addTemplates/manageTemplates.html',
                controller: 'AdminTemplateCtrl',
                controllerAs: 'admintemplatevm',
                data: {
                    displayName: 'Manage Templates'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTemplates/AdminTemplateService.js',
                                    'components/AdminModule/addTemplates/AdminTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageTemplates.addTemplate', {
                url: '/addTemplate',
                title: 'Add New Template',
                templateUrl: 'components/AdminModule/addTemplates/addTemplate.html',
                controller: 'AdminTemplateCtrl',
                controllerAs: 'admintemplatevm',
                data: {
                    displayName: 'Add new template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTemplates/AdminTemplateService.js',
                                    'components/AdminModule/addTemplates/AdminTemplateCtrl.js',
                                    'components/common/multiSelect/multipleSelectDirective.js'
                                ]
                            }
                        ])
                    }
                }
            }).state('AdminMain.administration.manageTemplates.editTemplate', {
                url: '/:id/edit',
                title: 'Edit Template',
                templateUrl: 'components/AdminModule/addTemplates/addTemplate.html',
                controller: 'AdminTemplateCtrl',
                controllerAs: 'admintemplatevm',
                data: {
                    displayName: 'Edit template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css'
                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTemplates/AdminTemplateService.js',
                                    'components/AdminModule/addTemplates/AdminTemplateCtrl.js',
                                    'components/common/multiSelect/multipleSelectDirective.js'
                                ]
                            }
                        ])
                    }
                }
            })
            .state('AdminMain.administration.manageTopics', {
                url: '/manageTopics',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Topics',
                templateUrl: 'components/AdminModule/addTopics/manageTopics.html',
                controller: 'adminTopicCtrl',
                controllerAs: 'adminTopicvm',
                data: {
                    displayName: 'Manage Topics'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTopics/adminTopicService.js',
                                    'components/AdminModule/addTopics/adminTopicCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageTopics.addTopic', {
                url: '/addTopics',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new topic',
                templateUrl: 'components/AdminModule/addTopics/addTopic.html',
                controller: 'adminTopicCtrl',
                controllerAs: 'adminTopicvm',
                data: {
                    displayName: 'Add new topic'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTopics/adminTopicService.js',
                                    'components/AdminModule/addTopics/adminTopicCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageTopics.editTopic', {
                url: '/:id/edit',
                title: 'Edit topic',
                templateUrl: 'components/AdminModule/addTopics/addTopic.html',
                controller: 'adminTopicCtrl',
                controllerAs: 'adminTopicvm',
                data: {
                    displayName: 'Edit topic'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addTopics/adminTopicService.js',
                                    'components/AdminModule/addTopics/adminTopicCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageRoles', {
                url: '/manageRoles',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Roles',
                templateUrl: 'components/AdminModule/addRoles/manageRoles.html',
                controller: 'adminRoleCtrl',
                controllerAs: 'adminRolevm',
                data: {
                    displayName: 'Manage Roles'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addRoles/adminRoleService.js',
                                    'components/AdminModule/addRoles/adminRoleCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageRoles.addRole', {
                url: '/addRole',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new role',
                templateUrl: 'components/AdminModule/addRoles/addRole.html',
                controller: 'adminRoleCtrl',
                controllerAs: 'adminRolevm',
                data: {
                    displayName: 'Add new role'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addRoles/adminRoleService.js',
                                    'components/AdminModule/addRoles/adminRoleCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageRoles.editRole', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit Role',
                templateUrl: 'components/AdminModule/addRoles/addRole.html',
                controller: 'adminRoleCtrl',
                controllerAs: 'adminRolevm',
                data: {
                    displayName: 'Edit Role'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addRoles/adminRoleService.js',
                                    'components/AdminModule/addRoles/adminRoleCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }

            }).state('AdminMain.administration.manageProcessGroups', {
                url: '/manageProcessGroups',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Process Groups',
                templateUrl: 'components/AdminModule/addProcessGroups/manageProcess.html',
                controller: 'processCtrl',
                controllerAs: 'adminProcessvm',
                data: {
                    displayName: 'Manage Process Groups'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addProcessGroups/processService.js',
                                    'components/AdminModule/addProcessGroups/processCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }


            }).state('AdminMain.administration.manageProcessGroups.addProcess', {
                url: '/addProcess',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add Process Group',
                templateUrl: 'components/AdminModule/addProcessGroups/addProcess.html',
                controller: 'processCtrl',
                controllerAs: 'adminProcessvm',
                data: {
                    displayName: 'Add Process Group'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addProcessGroups/processService.js',
                                    'components/AdminModule/addProcessGroups/processCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageProcessGroups.editProcess', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit Process Group',
                templateUrl: 'components/AdminModule/addProcessGroups/addProcess.html',
                controller: 'processCtrl',
                controllerAs: 'adminProcessvm',
                data: {
                    displayName: 'Edit Process Group'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addProcessGroups/processService.js',
                                    'components/AdminModule/addProcessGroups/processCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageMethods', {
                url: '/manageMethods',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Solution Methods',
                templateUrl: 'components/AdminModule/addMethods/manageMethods.html',
                controller: 'adminMethodCtrl',
                controllerAs: 'adminMethodvm',
                data: {
                    displayName: 'Manage Solution Methods'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addMethods/adminMethodService.js',
                                    'components/AdminModule/addMethods/adminMethodCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageMethods.addMethod', {
                url: '/addMethod',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new solution method',
                templateUrl: 'components/AdminModule/addMethods/addMethod.html',
                controller: 'adminMethodCtrl',
                controllerAs: 'adminMethodvm',
                data: {
                    displayName: 'Add new solution method'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addMethods/adminMethodService.js',
                                    'components/AdminModule/addMethods/adminMethodCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageMethods.editMethod', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit Solution Method',
                templateUrl: 'components/AdminModule/addMethods/addMethod.html',
                controller: 'adminMethodCtrl',
                controllerAs: 'adminMethodvm',
                data: {
                    displayName: 'Edit Solution Method'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addMethods/adminMethodService.js',
                                    'components/AdminModule/addMethods/adminMethodCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageLocalisedTemplates', {
                url: '/manageLocalTemplates',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Localized Templates',
                templateUrl: 'components/AdminModule/addLocalTemplates/manageLocalTemplate.html',
                controller: 'adminLocalTemplateCtrl',
                controllerAs: 'adminLocalTemplatevm',
                data: {
                    displayName: 'Manage Localized Templates'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateService.js',
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageLocalisedTemplates.addLocalTemplate', {
                url: '/addLocalTemplate',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new localized template',
                templateUrl: 'components/AdminModule/addLocalTemplates/addLocalTemplate.html',
                controller: 'adminLocalTemplateCtrl',
                controllerAs: 'adminLocalTemplatevm',
                data: {
                    displayName: 'Add new localized template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateService.js',
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageLocalisedTemplates.editLocalTemplate', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit localized template',
                templateUrl: 'components/AdminModule/addLocalTemplates/addLocalTemplate.html',
                controller: 'adminLocalTemplateCtrl',
                controllerAs: 'adminLocalTemplatevm',
                data: {
                    displayName: 'Edit localized template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateService.js',
                                    'components/AdminModule/addLocalTemplates/adminLocalTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.managePhases', {
                url: '/managePhases',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Phases',
                templateUrl: 'components/AdminModule/addPhases/managePhases.html',
                controller: 'adminPhasesCtrl',
                controllerAs: 'adminPhasesvm',
                data: {
                    displayName: 'Manage Phases'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addPhases/adminPhasesService.js',
                                    'components/AdminModule/addPhases/adminPhasesCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.managePhases.addPhase', {
                url: '/addPhase',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new  phase',
                templateUrl: 'components/AdminModule/addPhases/addPhases.html',
                controller: 'adminPhasesCtrl',
                controllerAs: 'adminPhasevm',
                data: {
                    displayName: 'Add new phase'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addPhases/adminPhasesService.js',
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addPhases/adminPhasesCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                        ]);

                    }
                }
            }).state('AdminMain.administration.managePhases.editPhase', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit Phase',
                templateUrl: 'components/AdminModule/addPhases/addPhases.html',
                controller: 'adminPhasesCtrl',
                controllerAs: 'adminPhasevm',
                data: {
                    displayName: 'Edit Phase'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addPhases/adminPhasesService.js',
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/addPhases/adminPhasesCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageSampleTemplates', {
                url: '/manageSampleTemplates',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Manage Sample Templates',
                templateUrl: 'components/AdminModule/addSampleTemplates/manageSampleTemplates.html',
                controller: 'adminSampleTemplateCtrl',
                controllerAs: 'adminSampleTemplatevm',
                data: {
                    displayName: 'Manage Sample Templates'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateService.js',
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageSampleTemplates.addSampleTemplate', {
                url: '/addSampleTemplate',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Add new sample template',
                templateUrl: 'components/AdminModule/addSampleTemplates/addSampleTemplate.html',
                controller: 'adminSampleTemplateCtrl',
                controllerAs: 'adminSampleTemplatevm',
                data: {
                    displayName: 'Add new sample template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateService.js',
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageSampleTemplates.editSampleTemplate', {
                url: '/:id/edit',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: 'Edit sample template',
                templateUrl: 'components/AdminModule/addSampleTemplates/addSampleTemplate.html',
                controller: 'adminSampleTemplateCtrl',
                controllerAs: 'adminSampleTemplatevm',
                data: {
                    displayName: 'Edit sample template'
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateService.js',
                                    'components/AdminModule/addSampleTemplates/adminSampleTemplateCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.whatsNew', {
                url: '/whatsNew',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage What's New",
                templateUrl: 'components/AdminModule/whatsNew/manageWhatsNew.html',
                controller: 'adminWhatsNewCtrl',
                controllerAs: 'adminWhatsNewvm',
                data: {
                    displayName: "Manage What's New"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/whatsNew/adminWhatsNewService.js',
                                    'components/AdminModule/whatsNew/adminWhatsNewCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.managedeliveryPlayBooks', {
                url: '/managePlayBooks',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage Delivery Playbooks",
                templateUrl: 'components/AdminModule/managePlayBooks/managePlayBooks.html',
                controller: 'managePlayBooksCtrl',
                controllerAs: 'managePlayBooksvm',
                data: {
                    displayName: "Manage Delivery Playbooks"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/AdminModule/managePlayBooks/managePlayBooksService.js',
                                    'components/AdminModule/managePlayBooks/managePlayBooksCtrl.js',
                                    'components/AdminModule/addActivity/addCustomFieldDirective.js',
                                    'components/AdminModule/addActivity/addCustomFields.html'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageActivityGrids', {
                url: '/manageActivityGrids',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage Activity Grid",
                templateUrl: 'components/AdminModule/manageActivityGrids/manageActivityGrids.html',
                controller: 'manageActivityGridsCtrl',
                controllerAs: 'manageActivityGridsvm',
                data: {
                    displayName: "Manage Activity Grid"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/manageActivityGrids/manageActivityGridsService.js',
                                    'components/AdminModule/manageActivityGrids/manageActivityGridsServiceCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            })
            .state('AdminMain.administration.manageRACIGrids', {
                url: '/manageRACIGrids',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage RACI Grid",
                templateUrl: 'components/AdminModule/manageRACIGrids/manageRACIGrids.html',
                controller: 'manageRACIGridsCtrl',
                controllerAs: 'manageRACIGridsvm',
                data: {
                    displayName: "Manage RACI Grid"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/manageRACIGrids/manageRACIGridsService.js',
                                    'components/AdminModule/manageRACIGrids/manageRACIGridsServiceCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageFileUpload', {
                url: '/manageFileUpload',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage File Upload",
                templateUrl: 'components/AdminModule/manageFileUpload/manageFileUpload.html',
                controller: 'manageFileUploadCtrl',
                controllerAs: 'manageFileUploadsvm',
                data: {
                    displayName: "Manage File Upload"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/manageFileUpload/manageFileUploadCtrl.js',
                                    'components/AdminModule/manageFileUpload/manageFileUploadService.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            }).state('AdminMain.administration.manageTopicCategory', {
                url: '/manageTopicCategory',
                params: {
                    page: {
                        value: '1'
                    }
                },
                title: "Manage Topic Category",
                templateUrl: 'components/AdminModule/manageTopicCategory/manageTopicCategory.html',
                controller: 'manageTopicCategoryCtrl',
                controllerAs: 'manageTopicCategoryvm',
                data: {
                    displayName: "Manage Topic Category"
                },
                resolve: {
                    loadPlugin: function ($ocLazyLoad) {
                        return $ocLazyLoad.load([
                            {
                                serie: true,
                                insertBefore: 'appStyles',
                                files: [
                                    'components/AdminModule/admin.css',
                                    'components/common/commoncss/card.css'
                                ]
                            },
                            {
                                name: 'appCss',
                                insertBefore: 'appStyles',
                                files: [
                                    'components/common/pagination/pagination.css'
                                ]
                            },
                            {
                                name: 'vendors',
                                insertBefore: '#vendors',
                                files: [
                                    'components/common/pagination/paginate.js',
                                    'components/common/tinymce/tinymce.js',
                                    'components/common/tinymce/tinymce-angular.js'

                                ]
                            },
                            {
                                name: 'appFiles',
                                insertBefore: '#appScripts',
                                files: [
                                    'components/common/multiSelect/multipleSelectDirective.js',
                                    'components/AdminModule/manageTopicCategory/manageTopicCategoryService.js',
                                    'components/AdminModule/manageTopicCategory/manageTopicCategoryCtrl.js',
                                    'components/common/filters/truncate.js'
                                ]
                            }
                        ]);

                    }
                }
            });



        $urlRouterProvider
            .otherwise('/');
    });

(function () {
    angular.module('sdmApp')
        .service('SharedService', function (insights, UserService, $rootScope, $http, URLS, sdmSiteRefresh) {

            this.trackView = function (pageType, title, url, complexityId, version) {
                console.log(pageType)
                UserService.success(function (userInfo) {
                    insights.logEvent(pageType, { ItemTitle: title, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, Url: url, ComplexityType: complexityId });
                });
            };
            this.trackTemplateView = function (pageType, title, url, complexityId, version, PhaseName, PhaseId, itemId, isVisio, sourceUrl, referrer) {
                console.log(pageType)
                UserService.success(function (userInfo) {
                    insights.logEvent(pageType, { ItemTitle: title, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, Url: url, ComplexityType: complexityId, version: version, PhaseName: PhaseName, PhaseId: PhaseId, ItemId: itemId, ItemType: 1, IsVisioTemplate: isVisio, SourceUrl: sourceUrl, Referrer: referrer });
                });
            };
            this.trackServiceError = function (pageType, data) {
                console.log(pageType)
                UserService.success(function (userInfo) {
                    insights.logEvent(pageType, { ServiceUrl: data.serviceUrl, ResponseStatus: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, StatusCode: data.status, Data: data.data, PageTitle: data.PageTitle, PageUrl: data.PageUrl, MethodType: data.type, ErrorMessage: data.errorMessage });
                });
            };
            this.trackRatingView = function (pageType, data) {
                UserService.success(function (userInfo) {
                    if (data.complexityType) {
                        insights.logEvent(pageType, { ItemTypeId: data.itemTypeId, ItemTitle: data.title, ItemVersion: data.version, ItemRating: data.rating, ItemComment: data.comment, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, Url: data.url });
                    }
                    else {
                        insights.logEvent(pageType, { ItemTypeId: data.itemTypeId, ItemTitle: data.title, ItemVersion: data.version, ItemRating: data.rating, ItemComment: data.comment, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, Url: data.url, PhaseId: data.phaseId, ComplexityType: data.complexityType, PhaseName: data.phaseName });
                    }

                });
            };
            //globalSearc EventCall
            this.globalSearch = function (pageType, title, url, itemId, sourceUrl, referrer, searchKey, searchText) {
                UserService.success(function (userInfo) {

                    insights.logEvent(pageType, { ItemTitle: userInfo.title, Alias: userInfo.alias, SearchKey: userInfo.searchKey, SearchText: userInfo.searchText, Role: userInfo.jobTitle, Location: userInfo.location, Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, Url: url, ComplexityType: complexityId, version: version, PhaseName: PhaseName, PhaseId: PhaseId, ItemId: itemId, ItemType: 22, SourceUrl: sourceUrl, Referrer: referrer });


                });
            };



            this.openModal = function (pageType, title, url) {

                var w = 1200, h = 700, left = screen.width / 2 - w / 2, top = screen.height / 2 - h / 2;
                var activityWindow = window.open(url, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ", left=" + left + "", true);
                //activityWindow.focus();
                this.trackView(pageType, title, url);
            };
            this.sendUserFeedback = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.userActivityFeedBack, data, config);
            }
            this.sendCorelationId = function (pageType, data) {
                UserService.success(function (userInfo) {
                    insights.logEvent(pageType, { CorrelationId: data.correlationId, PageTitle: data.title, RequestUrl: data.requestUrl, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location })
                })
            }
            this.logEvent = function (pageType, data) {
                UserService.success(function (userInfo) {
                    if (data.complexityType) {
                        insights.logEvent(pageType, { ClickEvent: data.ClickEvent, SearchText: data.title, SearchKey: data.searchKey, ItemTypeId: data.itemTypeId, ItemTitle: data.title ? data.title : null, ItemVersion: data.version ? data.version : null, ItemRating: data.rating, ItemComment: data.comment ? data.comment : null, Alias: userInfo.alias ? userInfo.alias : null, Role: userInfo.jobTitle ? userInfo.jobTitle : null, Location: userInfo.location ? userInfo.location : null, Domain: userInfo.selectedDomainName ? userInfo.selectedDomainName : null, Methodology: userInfo.selectedMethodologyName ? userInfo.selectedMethodologyName : null, SolutionMethodName: data.MethodName ? data.MethodName : null, PhaseName: data.PhaseName ? data.PhaseName : null, Url: data.url, ComplexityType: data.complexityType, ItemId: data.itemId, PhaseId: data.phaseId, DomainId: userInfo.selectedDomainId, MethodologyId: userInfo.selectedMethodologyId, PhaseName1: data.phaseName, SolutionMethodId: data.solutionMethodId });
                    }
                        //insights.logEvent(pageType, { SolutionMethodName: data.methodName, phaseName: data.phaseName, ItemRating: data.emailType, RatingGiven: data.feedback, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Url: data.url,Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, ActivityName: data.activityName });
                    else {
                        insights.logEvent(pageType, { ClickEvent: data.ClickEvent, SearchText: data.title, SearchKey: data.searchKey, ItemTypeId: data.itemTypeId, ItemTitle: data.title ? data.title : null, ItemVersion: data.version ? data.version : null, ItemRating: data.rating, ItemComment: data.comment ? data.comment : null, Alias: userInfo.alias ? userInfo.alias : null, Role: userInfo.jobTitle ? userInfo.jobTitle : null, Location: userInfo.location ? userInfo.location : null, Domain: userInfo.selectedDomainName ? userInfo.selectedDomainName : null, Methodology: userInfo.selectedMethodologyName ? userInfo.selectedMethodologyName : null, SolutionMethodName: data.MethodName ? data.MethodName : null, PhaseName: data.PhaseName ? data.PhaseName : null, Url: data.url, ComplexityType: data.ComplexityType });
                    }
                });
            }
            this.saveLogEvent = function (data) {
                UserService.success(function (userInfo) {
                    //insights.logEvent(pageType, { SolutionMethodName: data.methodName, phaseName: data.phaseName, ItemRating: data.emailType, RatingGiven: data.feedback, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Url: data.url,Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, ActivityName: data.activityName });
                    insights.logEvent('DefaultProfile', { Alias: userInfo.alias ? userInfo.alias : null, Role: userInfo.jobTitle ? userInfo.jobTitle : null, Location: userInfo.location ? userInfo.location : null, Domain: userInfo.selectedDomainName ? userInfo.selectedDomainName : null, Methodology: userInfo.selectedMethodologyName ? userInfo.selectedMethodologyName : null, SolutionMethodName: data.MethodName ? data.MethodName : null, Url: data.url });
                });
            }
            this.logLinkEvent = function (pageType, data) {
                UserService.success(function (userInfo) {
                    //insights.logEvent(pageType, { SolutionMethodName: data.methodName, phaseName: data.phaseName, ItemRating: data.emailType, RatingGiven: data.feedback, Alias: userInfo.alias, Role: userInfo.jobTitle, Location: userInfo.location, Url: data.url,Domain: userInfo.selectedDomainName, Methodology: userInfo.selectedMethodologyName, ActivityName: data.activityName });
                    insights.logEvent(pageType, { Alias: userInfo.alias ? userInfo.alias : null, Role: userInfo.jobTitle ? userInfo.jobTitle : null, Location: userInfo.location ? userInfo.location : null, Domain: userInfo.selectedDomainName ? userInfo.selectedDomainName : null, Methodology: userInfo.selectedMethodologyName ? userInfo.selectedMethodologyName : null, Url: data.url, ItemTitle: data.name, ComplexityType: data.ComplexityType, Referrer: data.referrer ? data.referrer : null });
                });
            }
            this.getComplexities = function () {
                return $http.get(URLS.complexity)
            }

        });
})();
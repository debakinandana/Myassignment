(function () {
    angular.module('sdmApp')
	.service('WhatsnewService', function ($http, URLS) {
	    this.getContent = function () {
	        return $http.get(URLS.whatsnew);
	    };
	    this.updatePinStatus = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.post(URLS.updateWhatsnew, data, config);
	    };
	});
})();
[{
    "title": "Business Productivity",
    "fileLocation": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-1473820157-5"
}, {
    "title": "Data Insights",
    "fileLocation": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/WopiFrame.aspx?sourcedoc=%7B64471b95-3108-4688-9b85-e3d3aa6bc219%7D&action=default"
}, {
    "title": "Business Applications",
    "fileLocation": "https://aka.ms/dynamicsplaybook"
}, {
    "title": "Modern Apps",
    "fileLocation": "http://aka.ms/madeliveryplaybook"
}, {
    "title": "Secure InfraStrucutre",
    "fileLocation": "https://microsoft.sharepoint.com/teams/ESDSI/SAO/_layouts/15/WopiFrame.aspx?sourcedoc=%7B66542460-E62C-453E-B990-02191D9DEBAB%7D&file=SI%20Domain%20Delivery%20Playbook.pptx&action=default"
}]

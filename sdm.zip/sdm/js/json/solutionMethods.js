[{
    "levelName": "Agile Level-5",
    "link": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-2019779950-1"
},
{
    "levelName": "Core IO",
    "link": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-2019779950-2"
}, {
    "levelName": "Core IO Small",
    "link": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-2019779950-3"
} ,{
    "levelName": "ENMO",
    "link": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-2019779950-4"
}, {
    "levelName": "MSF Level-5",
    "link": "https://microsoft.sharepoint.com/teams/CampusIPLibraries/SDMPlus/_layouts/15/DocIdRedir.aspx?ID=CAMPUSIP-2019779950-5"
}]
package com.epam.jdi.uitests.testing.career.page_objects.enums;

/**
 * Created by Roman_Iovlev on 10/22/2015.
 */
public enum Locations {
    SAINT_PETERSBURG("Saint-Petersburg");

    public String value;

    Locations(String value) {
        this.value = value;
    }
}

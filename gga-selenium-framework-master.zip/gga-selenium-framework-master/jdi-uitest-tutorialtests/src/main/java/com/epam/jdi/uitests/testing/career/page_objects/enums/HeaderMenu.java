package com.epam.jdi.uitests.testing.career.page_objects.enums;

/**
 * Created by Roman_Iovlev on 10/22/2015.
 */
public enum HeaderMenu {
    SOLUTIONS, INDUSTRIES, ABOUT, IDEAS, CAREERS, CONTACT


}

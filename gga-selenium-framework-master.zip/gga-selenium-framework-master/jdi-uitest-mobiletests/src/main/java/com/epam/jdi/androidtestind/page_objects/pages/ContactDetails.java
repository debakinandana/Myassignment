package com.epam.jdi.androidtestind.page_objects.pages;

/**
 * Created by Natalia_Grebenshchik on 12/28/2015.
 */
public class ContactDetails {
    private String contactName;
    private String phone;

    public ContactDetails(String contactName, String phone){
        this.contactName = contactName;
        this.phone = phone;
    }
}

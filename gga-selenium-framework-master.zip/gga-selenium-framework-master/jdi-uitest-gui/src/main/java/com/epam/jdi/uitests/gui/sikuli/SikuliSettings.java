package com.epam.jdi.uitests.gui.sikuli;

import org.sikuli.basics.Settings;
/**
 * Created by Natalia_Grebenshchikova on 1/14/2016.
 */
public class SikuliSettings extends Settings {
}

package com.epam.jdi.uitests.gui.sikuli.elements.enums;

/**
 * Created by Natalia_Grebenshchik on 1/20/2016.
 */
public enum OffsetUnits {
    PIXELS, PERCENTAGE;
}

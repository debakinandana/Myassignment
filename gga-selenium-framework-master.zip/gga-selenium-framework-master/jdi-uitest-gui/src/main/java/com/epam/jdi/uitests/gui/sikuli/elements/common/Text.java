package com.epam.jdi.uitests.gui.sikuli.elements.common;

import com.epam.jdi.uitests.gui.sikuli.elements.base.Element;
import com.epam.jdi.uitests.core.interfaces.common.IText;

/**
 * Created by Natalia_Grebenshchikova on 1/19/2016.
 */
public class Text extends Element implements IText {
    public String getText() {
        return null;
    }

    public String waitText(String text) {
        return null;
    }

    public String waitMatchText(String regEx) {
        return null;
    }

    public String getValue() {
        return null;
    }
}

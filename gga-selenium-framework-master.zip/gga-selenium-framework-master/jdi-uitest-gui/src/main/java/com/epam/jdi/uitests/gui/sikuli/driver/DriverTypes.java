package com.epam.jdi.uitests.gui.sikuli.driver;

public enum DriverTypes {
    SIKULI("sikuli");

    public String name;

    DriverTypes(String name) {
        this.name = name;
    }

}
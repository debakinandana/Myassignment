package com.ggasoftware.uitest.control.base.annotations;

/**
 * Created by Roman_Iovlev on 6/10/2015.
 */
public @interface JDIAction {
}

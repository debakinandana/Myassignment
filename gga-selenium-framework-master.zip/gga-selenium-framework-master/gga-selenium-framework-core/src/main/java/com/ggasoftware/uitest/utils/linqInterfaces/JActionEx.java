package com.ggasoftware.uitest.utils.linqInterfaces;

/**
 * Created by roman.i on 01.10.2014.
 */
public interface JActionEx {
    void invoke() throws Exception;
}

package com.ggasoftware.uitest.control.interfaces.common;

/**
 * Created by Roman_Iovlev on 7/10/2015.
 */
public interface IFileInput<P> extends IInput<P> {
}

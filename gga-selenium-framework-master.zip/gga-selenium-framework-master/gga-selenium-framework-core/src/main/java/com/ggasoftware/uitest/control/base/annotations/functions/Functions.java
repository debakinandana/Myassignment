package com.ggasoftware.uitest.control.base.annotations.functions;

/**
 * Created by Roman_Iovlev on 7/21/2015.
 */
public enum Functions {
    NONE,
    OK_BUTTON,
    SUBMIT_BUTTON,
    CLOSE_BUTTON,
    CANCEL_BUTTON,
    POPUP_TEXT;
}

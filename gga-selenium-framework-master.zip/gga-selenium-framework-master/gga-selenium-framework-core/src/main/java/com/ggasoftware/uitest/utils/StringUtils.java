package com.ggasoftware.uitest.utils;

/**
 * Created by roman.i on 19.11.2014.
 */
public class StringUtils {
    public static String LineBreak = System.getProperty("line.separator");
}

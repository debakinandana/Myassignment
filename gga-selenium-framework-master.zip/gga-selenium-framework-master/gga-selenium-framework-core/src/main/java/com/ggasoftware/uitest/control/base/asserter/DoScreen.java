package com.ggasoftware.uitest.control.base.asserter;

/**
 * Created by Roman_Iovlev on 8/28/2015.
 */
public enum DoScreen {
    NO_SCREEN,
    SCREEN_ON_FAIL,
    DO_SCREEN_ALWAYS
}

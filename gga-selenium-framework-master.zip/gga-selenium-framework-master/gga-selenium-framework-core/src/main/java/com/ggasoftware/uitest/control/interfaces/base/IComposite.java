package com.ggasoftware.uitest.control.interfaces.base;

/**
 * Created by Roman_Iovlev on 7/10/2015.
 */
public interface IComposite {
}

package com.ggasoftware.uitest.utils.linqInterfaces;

/**
 * Created by roman.i on 01.10.2014.
 */
public interface JAction {
    void invoke() throws RuntimeException;
}

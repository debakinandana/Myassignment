package com.ggasoftware.uitest.control.new_controls.complex.table;

/**
 * Created by 12345 on 25.10.2014.
 */
public enum ElementIndexType {
    Nums,
    Names
}

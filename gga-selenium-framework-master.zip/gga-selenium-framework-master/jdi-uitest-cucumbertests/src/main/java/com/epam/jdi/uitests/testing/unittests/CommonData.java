package com.epam.jdi.uitests.testing.unittests;

/**
 * Created by Roman_Iovlev on 10/9/2015.
 */
public class CommonData {
    public static String TEST_DATE = "09/09/1945";
}

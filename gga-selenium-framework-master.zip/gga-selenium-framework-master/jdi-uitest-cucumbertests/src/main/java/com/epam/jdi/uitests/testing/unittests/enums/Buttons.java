package com.epam.jdi.uitests.testing.unittests.enums;

/**
 * Created by Dmitry_Lebedev1 on 10/16/2015.
 */
public enum Buttons {
    SUBMIT,
    CALCULATE
}

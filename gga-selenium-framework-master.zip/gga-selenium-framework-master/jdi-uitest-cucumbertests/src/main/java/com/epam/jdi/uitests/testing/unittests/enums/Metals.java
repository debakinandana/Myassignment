package com.epam.jdi.uitests.testing.unittests.enums;

/**
 * Created by Maksim_Palchevskii on 10/6/2015.
 */
public enum Metals {
    Col, Gold, Silver, Bronze, Selen;
}

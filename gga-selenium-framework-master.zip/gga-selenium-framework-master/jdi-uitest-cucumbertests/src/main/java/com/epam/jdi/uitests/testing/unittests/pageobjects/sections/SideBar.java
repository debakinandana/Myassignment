package com.epam.jdi.uitests.testing.unittests.pageobjects.sections;

import com.epam.jdi.uitests.web.selenium.elements.composite.Section;

/**
 * Created by Maksim_Palchevskii on 9/11/2015.
 */
public class SideBar extends Section {

}

package com.epam.jdi.uitests.testing.unittests.enums;

/**
 * Created by Roman_Iovlev on 9/21/2015.
 */
public enum Colors {
    Colors, Red, Green, Blue, Yellow;
}

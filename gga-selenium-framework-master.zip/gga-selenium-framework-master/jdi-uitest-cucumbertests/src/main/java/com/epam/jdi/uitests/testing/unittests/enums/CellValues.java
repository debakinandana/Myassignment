package com.epam.jdi.uitests.testing.unittests.enums;

/**
 * Created by Natalia_Grebenshchik on 10/16/2015.
 */
public enum CellValues {
    value1("1"),
    value2("2");

    public String value;

    CellValues(String value) {
        this.value = value;
    }
}

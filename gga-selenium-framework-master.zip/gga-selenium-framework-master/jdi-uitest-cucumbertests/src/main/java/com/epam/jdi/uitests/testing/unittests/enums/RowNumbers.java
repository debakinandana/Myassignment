package com.epam.jdi.uitests.testing.unittests.enums;

/**
 * Created by Natalia_Grebenshchik on 12/18/2015.
 */
public enum  RowNumbers {
    Five("5"),
    Ten("10"),
    Fifteen("15"),
    Twenty("20");

    public String value;

    RowNumbers(String value){
        this.value = value;
    }

}

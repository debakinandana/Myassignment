﻿# Activity Pages

1231 ->  1381
monday -2,

<ul> <li>
            <span>1381</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetUpEngagementorProject.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetUpEngagementorProject.aspx</a>
        </li>
        <li>
            <span>1380</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetupDocumentQualityChecks.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetupDocumentQualityChecks.aspx</a>
        </li>
        <li>
            <span>1379</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewTeamMemberPerformance.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewTeamMemberPerformance.aspx</a>
        </li>
        <li>
            <span>1378</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetUpDeliveryPlan.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_SetUpDeliveryPlan.aspx</a>
        </li>
        <li>
            <span>1377</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewProjectDocuments.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewProjectDocuments.aspx</a>
        </li>
        <li>
            <span>1376</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewPost-ProgramOperation.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewPost-ProgramOperation.aspx</a>
        </li>
        <li>
            <span>1375</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewOperationalImpact.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewOperationalImpact.aspx</a>
        </li>
        <li>
            <span>1374</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDesignandPlans.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDesignandPlans.aspx</a>
        </li>
        <li>
            <span>1373</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDeliverablesAgainstSOWandAgreedChanges.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDeliverablesAgainstSOWandAgreedChanges.aspx</a>
        </li>
        <li>
            <span>1372</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDeal.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewDeal.aspx</a>
        </li>
        <li>
            <span>1371</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewCodeandTestScripts.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewCodeandTestScripts.aspx</a>
        </li>
        <li>
            <span>1370</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewApplicationSecurity.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewApplicationSecurity.aspx</a>
        </li>
        <li>
            <span>1369</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewandFinalizeProjectDocuments.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewandFinalizeProjectDocuments.aspx</a>
        </li>
        <li>
            <span>1368</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewandAgreetoNonStandardTermsintheContractStructure.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewandAgreetoNonStandardTermsintheContractStructure.aspx</a>
        </li>
        <li>
            <span>1367</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewAllFinalDocuments.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReviewAllFinalDocuments.aspx</a>
        </li>
        <li>
            <span>1366</span>
            <a href=""></a>
        </li>
        <li>
            <span>1365</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ResolveSolutionIssuesandBugs.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ResolveSolutionIssuesandBugs.aspx</a>
        </li>
        <li>
            <span>1364</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ResearchIntellectualProperty.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ResearchIntellectualProperty.aspx</a>
        </li>
        <li>
            <span>1363</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RequestStaffingandResources.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RequestStaffingandResources.aspx</a>
        </li>
        <li>
            <span>1362</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReportStatus.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ReportStatus.aspx</a>
        </li>
        <li>
            <span>1361</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RegularlyReviewCOSStatements.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RegularlyReviewCOSStatements.aspx</a>
        </li>
        <li>
            <span>1360</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineInitialWBS.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineInitialWBS.aspx</a>
        </li>
        <li>
            <span>1359</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineInitialTopDownEstimates.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineInitialTopDownEstimates.aspx</a>
        </li>
        <li>
            <span>1358</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineBusinessFactors.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RefineBusinessFactors.aspx</a>
        </li>
        <li>
            <span>1357</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RecordTimeandExpenses.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_RecordTimeandExpenses.aspx</a>
        </li>
        <li>
            <span>1356</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QualifyOpportunity.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QualifyOpportunity.aspx</a>
        </li>
        <li>
            <span>1355</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_05_SupportDevelopmentOfTrainingMaterials.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_05_SupportDevelopmentOfTrainingMaterials.aspx</a>
        </li>
        <li>
            <span>1354</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_04_ReprioritzeFeatureSetRequirements.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_04_ReprioritzeFeatureSetRequirements.aspx</a>
        </li>
        <li>
            <span>1353</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_03_VerifyUserInterfaceDesigns.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_03_VerifyUserInterfaceDesigns.aspx</a>
        </li>
        <li>
            <span>1352</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_02_SupportDevelopers.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_02_SupportDevelopers.aspx</a>
        </li>
        <li>
            <span>1351</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_01_CreateWireframes.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_03_Verify_01_CreateWireframes.aspx</a>
        </li>
        <li>
            <span>1350</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_08_ReviseRequirementsBasedOnFeedback.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_08_ReviseRequirementsBasedOnFeedback.aspx</a>
        </li>
        <li>
            <span>1349</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_07_ConductUsabilityTestingBasedOnCapabilities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_07_ConductUsabilityTestingBasedOnCapabilities.aspx</a>
        </li>
        <li>
            <span>1348</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_06_CreateUserExperienceFocusedProofOfConcept.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_06_CreateUserExperienceFocusedProofOfConcept.aspx</a>
        </li>
        <li>
            <span>1347</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_05_ApplyVisualDesignToPrimaryScreens.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_05_ApplyVisualDesignToPrimaryScreens.aspx</a>
        </li>
        <li>
            <span>1346</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_04_CreateWireframesBasedOnFeatureSets.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_04_CreateWireframesBasedOnFeatureSets.aspx</a>
        </li>
        <li>
            <span>1345</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_01_HighlightTechnicalFeasibilityConstraints.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_01_HighlightTechnicalFeasibilityConstraints.aspx</a>
        </li>
        <li>
            <span>1344</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_03_CreateScreenFlowsAndSiteMap.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_03_CreateScreenFlowsAndSiteMap.aspx</a>
        </li>
        <li>
            <span>1343</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_01_ProvideUserPerspectiveInPrioritization.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_01_ProvideUserPerspectiveInPrioritization.aspx</a>
        </li>
        <li>
            <span>1342</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_02_CreateMentalModel.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_02_Confirm_02_CreateMentalModel.aspx</a>
        </li>
        <li>
            <span>1341</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_09_CreateUsabilityTestingPlan.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_09_CreateUsabilityTestingPlan.aspx</a>
        </li>
        <li>
            <span>1340</span>
            <a href=""></a>
        </li>
        <li>
            <span>1339</span>
            <a href=""></a>
        </li>
        <li>
            <span>1338</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_06_CreateUserPersonas.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_06_CreateUserPersonas.aspx</a>
        </li>
        <li>
            <span>1337</span>
            <a href=""></a>
        </li>
        <li>
            <span>1336</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_04_AssistInDevelopingPrioritizationFramework.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_04_AssistInDevelopingPrioritizationFramework.aspx</a>
        </li>
        <li>
            <span>1335</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_03_ParticipateInFeatureSetRequirementsGathering.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_03_ParticipateInFeatureSetRequirementsGathering.aspx</a>
        </li>
        <li>
            <span>1334</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_02_AssistsInDeterminingElicitationTechniques.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_02_AssistsInDeterminingElicitationTechniques.aspx</a>
        </li>
        <li>
            <span>1333</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_01_ParticipateInPlanningActivities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_UserExperienceFocus_01_Elicit_01_ParticipateInPlanningActivities.aspx</a>
        </li>
        <li>
            <span>1332</span>
            <a href=""></a>
        </li>
        <li>
            <span>1331</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_05_DefineTestPlanAndPerformTesting.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_05_DefineTestPlanAndPerformTesting.aspx</a>
        </li>
        <li>
            <span>1330</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_04_ProvideProcessImprovementFeedback.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_04_ProvideProcessImprovementFeedback.aspx</a>
        </li>
        <li>
            <span>1329</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_03_CommunicateRequirementsToDevelopers.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_03_CommunicateRequirementsToDevelopers.aspx</a>
        </li>
        <li>
            <span>1328</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_02_ReviewFinalFeatureSets.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_03_Verify_02_ReviewFinalFeatureSets.aspx</a>
        </li>
        <li>
            <span>1327</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_07_CreatePrototypes.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_07_CreatePrototypes.aspx</a>
        </li>
        <li>
            <span>1326</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_06_ValidateCapabilitiesThroughUseCasesOrPrototyping.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_06_ValidateCapabilitiesThroughUseCasesOrPrototyping.aspx</a>
        </li>
        <li>
            <span>1325</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_05_PerformFeasibilityAnalysisWithTechnicalTeam.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_05_PerformFeasibilityAnalysisWithTechnicalTeam.aspx</a>
        </li>
        <li>
            <span>1324</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_04_EnsureCustomerTechnicalTeamBuyIn.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_04_EnsureCustomerTechnicalTeamBuyIn.aspx</a>
        </li>
        <li>
            <span>1323</span>
            <a href=""></a>
        </li>
        <li>
            <span>1322</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_02_ProvideFeedbackWhenRequirementsChangesWillImpactScope.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_02_ProvideFeedbackWhenRequirementsChangesWillImpactScope.aspx</a>
        </li>
        <li>
            <span>1321</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_01_ReviewCapabilitiesRelativeToSolution.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_02_Confirm_01_ReviewCapabilitiesRelativeToSolution.aspx</a>
        </li>
        <li>
            <span>1320</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_06_AlignOnDocumentationApproach.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_06_AlignOnDocumentationApproach.aspx</a>
        </li>
        <li>
            <span>1319</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_04_ParticipateInFeatureSetRequirementsGathering.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_04_ParticipateInFeatureSetRequirementsGathering.aspx</a>
        </li>
        <li>
            <span>1318</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_03_AlignOnTargetAudiences.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_03_AlignOnTargetAudiences.aspx</a>
        </li>
        <li>
            <span>1317</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_02_ProvideContextForElicitationTechniques.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_02_ProvideContextForElicitationTechniques.aspx</a>
        </li>
        <li>
            <span>1316</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_01_ParticipateInPlanningActivities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_TechnologyFocus_01_Elicit_01_ParticipateInPlanningActivities.aspx</a>
        </li>
        <li>
            <span>1315</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_SupportUserAcceptanceTesting_Verify.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_SupportUserAcceptanceTesting_Verify.aspx</a>
        </li>
        <li>
            <span>1314</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_Elicit_DocumentFeaturesandCapabilities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_Elicit_DocumentFeaturesandCapabilities.aspx</a>
        </li>
 <li>
            <span>1313</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_RefinePersonasandUserScenarios_Confirm.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_RefinePersonasandUserScenarios_Confirm.aspx</a>
        </li>
        <li>
            <span>1312</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_06_AddressFeatureGaps.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_06_AddressFeatureGaps.aspx</a>
        </li>
        <li>
            <span>1311</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_DocumentFeaturesandCapabilities_Elicit.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_DocumentFeaturesandCapabilities_Elicit.aspx</a>
        </li>
        <li>
            <span>1310</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_CommunicateFeaturestoDevelopers_Confirm.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_CommunicateFeaturestoDevelopers_Confirm.aspx</a>
        </li>
        <li>
            <span>1309</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_05_ResolveClarifyQuestions.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_05_ResolveClarifyQuestions.aspx</a>
        </li>
        <li>
            <span>1308</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_04_ParticipateInFeatureSetReprioritization.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_04_ParticipateInFeatureSetReprioritization.aspx</a>
        </li>
        <li>
            <span>1307</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_03_VerifyFeatureSetsDelivered.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_03_VerifyFeatureSetsDelivered.aspx</a>
        </li>
        <li>
            <span>1306</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_03_Verify_02_ConductUserAcceptanceTesting.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_03_Verify_02_ConductUserAcceptanceTesting.aspx</a>
        </li>
        <li>
            <span>1305</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_01_SupportTestPlanPreparationAsSME.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_03_Verify_01_SupportTestPlanPreparationAsSME.aspx</a>
        </li>
        <li>
            <span>1304</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_10_FinalizeBRDForSignOff.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_10_FinalizeBRDForSignOff.aspx</a>
        </li>
        <li>
            <span>1303</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_09_ObtainProjectSponsorIntermediateApprovalOnAllCapabilities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_09_ObtainProjectSponsorIntermediateApprovalOnAllCapabilities.aspx</a>
        </li>
        <li>
            <span>1302</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_02_Confirm_08_ReviewCapabilityLifecycleWithBusinessStakeholders.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_02_Confirm_08_ReviewCapabilityLifecycleWithBusinessStakeholders.aspx</a>
        </li>
        <li>
            <span>1301</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_07_ValidateInitialCapabilitiesWithKeyStakeholders.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_07_ValidateInitialCapabilitiesWithKeyStakeholders.aspx</a>
        </li>
        <li>
            <span>1300</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_06_ValidateCapabilitiesThroughUseCases.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_06_ValidateCapabilitiesThroughUseCases.aspx</a>
        </li>
        <li>
            <span>1299</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_05_PrioritizeFeaturesAndFeatureSets.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_05_PrioritizeFeaturesAndFeatureSets.aspx</a>
        </li>
        <li>
            <span>1298</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_04_Map_FeaturesToFeatureSets.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_04_Map_FeaturesToFeatureSets.aspx</a>
        </li>
        <li>
            <span>1297</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_03_CommunicateFeatureSetsToDevelopers.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_03_CommunicateFeatureSetsToDevelopers.aspx</a>
        </li>
        <li>
            <span>1296</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_02_MapFeatureSetsToActorsRoles.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_02_MapFeatureSetsToActorsRoles.aspx</a>
        </li>
        <li>
            <span>1295</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_01_GroupRequirementsIntoFeatureSets.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_02_Confirm_01_GroupRequirementsIntoFeatureSets.aspx</a>
        </li>
        <li>
            <span>1294</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_01_Elicit_08_ResolveProceduralImpasses.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_BusinsessFocus_01_Elicit_08_ResolveProceduralImpasses.aspx</a>
        </li>
        <li>
            <span>1293</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_07_AssessBusinessImpact.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_07_AssessBusinessImpact.aspx</a>
        </li>
        <li>
            <span>1292</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_06_DevelopPrioritizationCriteria.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_06_DevelopPrioritizationCriteria.aspx</a>
        </li>
        <li>
            <span>1291</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_05_DefineScenariosAndGatherFeatureSetRequirements.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_BusinsessFocus_01_Elicit_05_DefineScenariosAndGatherFeatureSetRequirements.aspx</a>
        </li>
        <li>
            <span>1290</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_04_SegmentAudienceIntoActorsRoles.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_04_SegmentAudienceIntoActorsRoles.aspx</a>
        </li>
        <li>
            <span>1289</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_03_Determine%20Elicitation%20Techniques.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_03_Determine%20Elicitation%20Techniques.aspx</a>
        </li>
        <li>
            <span>1288</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_01_Elicit_02_DraftInitialBusinessRequirementsDocument.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_01_Elicit_02_DraftInitialBusinessRequirementsDocument.aspx</a>
        </li>
        <li>
            <span>1287</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_01_PlanRequirementsGathering.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_QRM_01_Elicit_01_PlanRequirementsGathering.aspx</a>
        </li>
        <li>
            <span>1286</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ProgramClose-outHandoff.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ProgramClose-outHandoff.aspx</a>
        </li>
        <li>
            <span>1285</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ProcessContract.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ProcessContract.aspx</a>
        </li>
        <li>
            <span>1284</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_process_PPR.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_process_PPR.aspx</a>
        </li>
 <li>
            <span>1283</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PricetheDeal.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PricetheDeal.aspx</a>
        </li>
        <li>
            <span>1282</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PrepareDealPackage.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PrepareDealPackage.aspx</a>
        </li>
        <li>
            <span>1281</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PrepareandSubmitDealforApproval.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PrepareandSubmitDealforApproval.aspx</a>
        </li>
        <li>
            <span>1280</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Prepare%20Writer%20Package(s).aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Prepare%20Writer%20Package(s).aspx</a>
        </li>
        <li>
            <span>1279</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Prepare%20Proposal%20Management%20Plan%20(PMP)%20and%20Infrastructure.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Prepare%20Proposal%20Management%20Plan%20(PMP)%20and%20Infrastructure.aspx</a>
        </li>
        <li>
            <span>1278</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20for%20Oral%20Presentation%20(Orals).aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20for%20Oral%20Presentation%20(Orals).aspx</a>
        </li>
        <li>
            <span>1277</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20for%20Oral%20Presentation%20(Orals).aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20for%20Oral%20Presentation%20(Orals).aspx</a>
        </li>
        <li>
            <span>1276</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20Final%20Executive%20Summary.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20Final%20Executive%20Summary.aspx</a>
        </li>
        <li>
            <span>1275</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20Best%20and%20Final%20Offer%20(BAFO).aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Prepare%20Best%20and%20Final%20Offer%20(BAFO).aspx</a>
        </li>
        <li>
            <span>1274</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PlanProgramReleases.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PlanProgramReleases.aspx</a>
        </li>
        <li>
            <span>1273</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformUserAcceptanceTesting.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformUserAcceptanceTesting.aspx</a>
        </li>
        <li>
            <span>1272</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformTechnologyValidation.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformTechnologyValidation.aspx</a>
        </li>
        <li>
            <span>1271</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformSupplierClose-outReviews.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformSupplierClose-outReviews.aspx</a>
        </li>
        <li>
            <span>1270</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformPilot.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformPilot.aspx</a>
        </li>
        <li>
            <span>1269</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformPeriodicBuildProcess.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PerformPeriodicBuildProcess.aspx</a>
        </li>
        <li>
            <span>1268</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%203.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%203.aspx</a>
        </li>
        <li>
            <span>1267</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%202.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%202.aspx</a>
        </li>
        <li>
            <span>1266</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%201.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Perform%20Quality%20Gate%201.aspx</a>
        </li>
        <li>
            <span>1265</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Perform%20Oral%20Presentation-Q%20and%20A.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_Perform%20Oral%20Presentation-Q%20and%20A.aspx</a>
        </li>
        <li>
            <span>1264</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PDMGatewayOverview.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_PDMGatewayOverview.aspx</a>
        </li>
        <li>
            <span>1263</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ParticipateinORBAwareness.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_ParticipateinORBAwareness.aspx</a>
        </li>
        <li>
            <span>1262</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_OwnRiskActions.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL/act_OwnRiskActions.aspx</a>
        </li>
<li>
         <span>1261</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ObtainCustomerAcceptanceofContractDeliverables.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ObtainCustomerAcceptanceofContractDeliverables.aspx</a>
         </li>         
         <li>
         <span>1258</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_NegotiateAcquireCustomerAcceptanceofContract.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_NegotiateAcquireCustomerAcceptanceofContract.aspx</a>
         </li> 
         <li>
         <span>1257</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_MonitorBusinessCase.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_MonitorBusinessCase.aspx</a>
         </li> 
         <li>
         <span>1256</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageWorkOrderandContractChanges.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageWorkOrderandContractChanges.aspx</a>
         </li> 
         <li>
         <span>1255</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSubteamSchedule.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSubteamSchedule.aspx</a>
         </li> 
         <li>
         <span>1254</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSubcon.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSubcon.aspx</a>
         </li> 
         <li>
         <span>1253</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSolutionIssues.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSolutionIssues.aspx</a>
         </li> 
         <li>
         <span>1252</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSchedule.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageSchedule.aspx</a>
         </li> 
         <li>
         <span>1251</span>
         <a href=" https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageRisks.aspx">  https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageRisks.aspx</a>
         </li> 
         <li>
         <li>
         <span>1248</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageProjectResources.aspx"> https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageProjectResources.aspx</a>
         </li> 
         <li>
         <span>1250</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageProjectIssues.aspx"> https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageProjectIssues.aspx</a>
         </li>
                  <li>
         <span>1249</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageApprovalsRequiredPolicywithESAP.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageApprovalsRequiredPolicywithESAP.aspx</a>
         </li>
 <li>
         <span>1247(visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageBudget.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageBudget.aspx</a>
         </li>
         <li>
         <span>1246</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageApprovalsRequiredPolicywithESAP.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ManageApprovalsRequiredPolicywithESAP.aspx</a>
         </li>
         <li>
         <span>1245</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_LaunchPlanningValidation.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_LaunchPlanningValidation.aspx</a>
         </li>
         <li>
         <span>1244</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_IssueReleaseCandidates.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_IssueReleaseCandidates.aspx</a>
         </li>
         <li>
         <span>1243</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InternalReviews.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InternalReviews.aspx</a>
         </li>
         <li>
         <span>1242 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProjects-WorkStreams.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProjects-WorkStreams.aspx</a>
         </li>
         <li>
         <span>1241</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProjectClosure.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProjectClosure.aspx</a>
         </li>
         <li>
         <span>1240 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProgramResourceManagementProcess.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProgramResourceManagementProcess.aspx</a>
         </li>
         
 <li>
         <span>1239 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProgramReporting.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateProgramReporting.aspx</a>
         </li>
<li>
         <span>1238 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateFinancialControlProcess.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateFinancialControlProcess.aspx</a>
         </li> 
 <li>
         <span>1237</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateChangeRequests.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_InitiateChangeRequests.aspx</a>
         </li>
<li>
         <span>1236</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Incorporate%20Changes.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Incorporate%20Changes.aspx</a>
         </li>
<li>
         <span>1235</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementSecurityPlan.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementSecurityPlan.aspx</a>
         </li>
 <li>
         <span>1234</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementQualityManagementPlanActivities.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementQualityManagementPlanActivities.aspx</a>
         </li>
         <li>
<li>
         <span>1233 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramReportingCycles.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramReportingCycles.aspx</a>
         </li>
 <li>
              <span>1232 (visio-image)</span>
         <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramDeliveryProcesses.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramDeliveryProcesses.aspx</a>
         </li>
 <li>
            <span>1231 (visio-image)</span>
            <a href="https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramCommunicationPlan.aspx">https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementProgramCommunicationPlan.aspx</a>
        </li>
</ul>
﻿# Activity Pages

1080 -> 1220
---------------

1080 -> 1137
1. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AnalyzeSupplierPerformance.aspx
2. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ApproveDeal.aspx
3. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ApproveInvoices.aspx
4. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ApproveTimeandExpense.aspx
5. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AssembleContract.aspx
6. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AssembleDealTeam.aspx
7. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AssessandRefineTeamSkills.aspx
8. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AssessCurrentEnvironment.aspx
9. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AssessProjectManagementEffectiveness.aspx
10. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AuthorizeContract.aspx
11. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_BuildProjectEnvironments.aspx
12. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_BuildSolution.aspx
13. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_BuildTestSpecification.aspx
14. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CaptureCustomer'sBusinessDrivers.aspx
15. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CaptureKeyAssumptions.aspx
16. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CaptureLessonsLearned.aspx
17. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Close%20Out%20BidProposal.aspx
18. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CloseCampusWorkspace.aspx
19. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CloseOutProjects-WorkStreams.aspx
20. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CompleteFunctionalSpecification.aspx
21. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CompleteProposalorWorkOrderStatementofWorkServiceDescription.aspx
22. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CompletetheWorkOrder.aspx
23. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Conduct%20Internal%20Lessons%20Learned%20Review.aspx
24. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Conduct%20Proposal%20Strategy%20Workshop.aspx
25. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductConfigurationTesting.aspx
26. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductCoverageTesting.aspx
27. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductDocumentQualityChecks.aspx
28. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductEndtoEndSystemIntegrationTesting.aspx
29. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductEndUserTraining.aspx
30. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductInternalPostProjectAnalysis.aspx
31. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductPerformanceTesting.aspx
32. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductPilotSupportTraining.aspx
33. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductPilotTraining.aspx
34. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductPortfolioReviews.aspx
35. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductProjectReviews.aspx
36. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductSolutionDefinitionWorkshops.aspx
37. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductSupportabilityReviews.aspx
38. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductTechnicalReviews.aspx
39. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductUnitTest.aspx
40. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ConductUsageTesting.aspx
41. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ContractDueDiligence.aspx
42. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ContributeChangestoSDM.aspx
43. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CoordinateReleaseCommunication.aspx
44. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramBlueprint.aspx	
45. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramCommunicationsPlan.aspx
46. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramExecutionPlan.aspx
47. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramSchedule.aspx
48. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProjectFinanceWorkbook.aspx
49. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateSubteamSchedule.aspx
50. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateTheProgramBrief.aspx
51. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateTheProgramBusinessCase.aspx
52. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateThreatModel.aspx
53. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateTransitionPlans.aspx
54. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineandAssessHighLevelOrganizationalReadiness.aspx
55. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineandDocumentProjectStructure.aspx
56. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineBusinessChange.aspx
57. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineOn-goingBenefitsRealization.aspx
58. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineOn-goingCapabilityDevelopment.aspx
59. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProgramBenefits.aspx
60. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProgramDocumentControl.aspx
61. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProgramGovernanceStructure.aspx
62. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProgramOrganizationStructure.aspx
63. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProgramQualityManagementPlan.aspx
64. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineProjectProcesses.aspx
65. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineScopeActivity.aspx
66. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineSolutionStrategy.aspx
67. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineStatusReporting.aspx
68. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DefineTestStrategy.aspx
69. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Define-UpdateKeyAssumptions.aspx
70. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Define-UpdateProgramIssuesLog.aspx
71. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Define-UpdateProgramRiskLog.aspx
72. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverBusinessChangeElements.aspx
73. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverCapabilityDevelopment.aspx
74. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverProgramRelease.aspx
75. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverProjects-WorkStreams.aspx
76. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeployCoreSolutionComponents.aspx
77. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DetermineTechnicalDesignGoals.aspx
78. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Develop%20Solution.aspx
79. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopConceptualDesign.aspx
80. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopLogicalDesign.aspx
81. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopOperationsGuide.aspx
82. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopPhysicalDesign.aspx
83. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopProjectPlans.aspx
84. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopSolutionConcept.aspx
85. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DocumentUserandUseProfiles.aspx
86. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopUserReferenceMaterial.aspx
87. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DocumentVision.aspx
88. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Draft%20Executive%20Summary.aspx
89. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DraftFunctionalSpecification.aspx
90. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DraftMasterProjectPlanandSchedule.aspx
91. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DraftStatementofWorkProposal.aspx
92. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Escalate%20Risks%20and%20Issues.aspx
93. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EscalationProcess.aspx
94. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishChangeManagementProcess.aspx
95. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishDeliverableAcceptanceProcedure.aspx
96. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishProjectIssueManagementProcess.aspx
97. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishRelationshipswithSponsorandKeyStakeholders.aspx
98. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishRiskManagementProcess.aspx
99. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstablishSolutionIssueManagementProcess.aspx
100. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DevelopInitialPricing.aspx
101. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EstimateEffortandResources.aspx

with visio's
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_Elicit.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramCommunicationsPlan.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProgramSchedule.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateTransitionPlans.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverBusinessChangeElements.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverCapabilityDevelopment.aspx
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_DeliverProjects-WorkStreams.aspx




done
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_Verify.aspx 
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_QRM_Confirm.aspx 


check with aatish/bryan
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CreateProjectFinanceWorkbook-old.aspx


Topics Pages---
https://portal.sposites.com/sites/bizdesk/SDMPlusProd/Topics%20New/Commercial%20Management.aspx




var fs = require("fs"),
    gulp = require('gulp'),
    newer = require('gulp-newer'),
    concat = require('gulp-concat'),
    preprocess = require('gulp-preprocess'),
    htmlclean = require('gulp-htmlclean'),
    imagemin = require('gulp-imagemin'),
    sass = require('gulp-sass'),
    autoprefixer = require('gulp-autoprefixer'),
    jshint = require('gulp-jshint'),
    // jshint-stylish = require('gulp-jshint'),
    deporder = require('gulp-deporder'),
    stripdebug = require('gulp-strip-debug'),
    templateCache = require('gulp-angular-templatecache'),
    uglify = require('gulp-uglify'),    
    //size = require('gulp-size'),
    del = require('del'),
    ngAnnotate = require('gulp-ng-annotate'),
    sourcemaps = require('gulp-sourcemaps'),
    //compass = require('gulp-compass'),
    browsersync = require('browser-sync'),
    rename = require('gulp-rename'),
    notify = require("gulp-notify"),
    pkg = require('./package.json'),
    shell = require('gulp-shell'),
    uncss = require('gulp-uncss'),
    config = require('./build-config.json'),
    envArg = process.argv.indexOf('--env');


// file locations
var
    devBuild = envArg === -1 && process.argv[envArg + 1] !== 'production',
    unsafeBuild = envArg > -1 && process.argv[envArg + 1] === 'production-unsafe',
        

    source = 'public/',
    dest = '../sdm/',
    destCshtml = '../Views/sdm/',

    html = {
        in: source + '**/*.html',
        watch: [source + '**/*.html'],
        out: dest,
        context: {
            devBuild: devBuild,
            unsafeBuild: unsafeBuild,
            author: pkg.author,
            version: pkg.version
        }
    },

    images = {
        in: source + 'images/*.*',
        out: dest + 'images/'
    },

    //imguri = { in : source + 'images/inline/*',
    //    out: source + 'scss/images/',
    //    filename: '_datauri.scss',
    //    namespace: 'img'
    //},

    css = {
        in: source + 'scss/main.scss',
        watch: [source + 'scss/**/*', source + 'components/**/*.scss'],
        out: dest + 'css/',
        sassOpts: {
            outputStyle: 'expanded', // nested, expanded, compact, compressed, 
            imagePath: '../images',
            precision: 3,
            sourceComments: 'map',
            errLogToConsole: true
        },
        autoprefixerOpts: {
            browsers: ['last 2 versions']
        }
    },

    componentCss = {
        in: source + 'components/**/*.scss',
        watch: [source + 'components/**/*.scss'],
        out: dest + "components/",
        sassOpts: {
            outputStyle: 'expanded', // nested, expanded, compact, compressed, 
            imagePath: '../images',
            precision: 3,
            sourceComments: 'map',
            errLogToConsole: true
        }
        //pleeeaseOpts: {
        //    autoprefixer: { browsers: ['last 2 versions', '> 2%'] },
        //    rem: ['16px'],
        //    pseudoElements: true,
        //    mqpacker: true,
        //    minifier: !devBuild
        //}
    },

    fonts = {
        in: source + 'fonts/*.*',
        out: dest + 'fonts/'
    },

    components = { 
        in: source + 'components/**/*.js',
        out: dest + 'components/'
    },

    js = {
        in: source + 'js/**/*',
        out: dest + 'js/',
        filename: 'main.min.js',
        vendor: source + 'vendor/'
    },
    vendor = {
        in: source + 'vendor/**/*',
        out: dest + 'vendor/'
    },

    syncOpts = {
        server: {
            baseDir: dest,
            index: 'index.html'
        },
        open: true,
        notify: true
    };

function getFilesList() {
    var jsFiles = [],
        indexContents,
        scriptTagsPattern,
        match;

    // if (!grunt.file.exists(indexPath)) {
    //     grunt.log.warn('Index file "' + indexPath + '" not found.');
    //     return false;
    // }

    indexContents = fs.readFileSync(source + 'templates/_scripts.html');
    scriptTagsPattern = /<script.+?src="(.+?)".*?><\/script>/gm;
    match = scriptTagsPattern.exec(indexContents);
    while (match) {
        // if (!(/livereload-setup\.js/.test(match[1]))) {
        jsFiles.push(source + match[1]);
        // }
        match = scriptTagsPattern.exec(indexContents);
    }
    jsFiles.pop(); // remove production script `main.min.js` 
    return jsFiles;
}



// show build type
//console.log(pkg.name + ' ' + pkg.version + ', ' + (devBuild ? 'development' : 'production') + ' build');

// clean the build folder
gulp.task('clean', function () {
    del([
        dest + '*'
    ], { force: true });
});

// build HTML files
gulp.task('html', function () {
    var page = gulp.src(html.in).pipe(preprocess({ context: html.context }));
    if (!devBuild) {
        page = page
           // .pipe(size({ title: 'HTML in' }))
            .pipe(htmlclean())
           // .pipe(size({ title: 'HTML out' }));
    }
    return page.pipe(gulp.dest(html.out));
});

// manage images
gulp.task('images', function () {
    return gulp.src(images.in)
        .pipe(newer(images.out))
        .pipe(imagemin())
        .pipe(gulp.dest(images.out));
});

// convert inline images to dataURIs in SCSS source
//gulp.task('imguri', function() {
//    return gulp.src(imguri.in)
//        .pipe(imagemin())
//        .pipe(imacss(imguri.filename, imguri.namespace))
//        .pipe(gulp.dest(imguri.out));
//});

// copy fonts
gulp.task('fonts', function () {
    return gulp.src(fonts.in)
        .pipe(newer(fonts.out))
        .pipe(gulp.dest(fonts.out));
});


//gulp.task('compass', function() {
//    if (!devBuild) {
//        css.compassOpts.style = 'compressed';
//        css.compassOpts.sourcemap = false;
//    }

//    return gulp.src(css.in)
//        .pipe(sourcemaps.init())
//        .pipe(compass(css.compassOpts))
//        .on('error', notify.onError(function(error) {
//            return 'An error occurred while compiling sass.\nLook in the console for details.\n' + error;
//        }))
//        .pipe(sourcemaps.write())
//        // .pipe(size({ title: 'CSS in ' }))
//        // .pipe(pleeease(css.pleeeaseOpts))
//        // .pipe(size({ title: 'CSS out ' }))
//        .pipe(gulp.dest(css.out))
//        .pipe(notify({
//            message: "Compilation Successful"
//        }))
//        .pipe(browsersync.reload({ stream: true }));
//});

// compile Sass
gulp.task('sass', ['componentSass'], function () {
    /// <summary>
    /// s this instance.
    /// </summary>
    /// <returns></returns>
    if (!devBuild) {
        css.sassOpts.outputStyle = 'compressed';
        delete css.sassOpts.sourceComments;

        var prodBuildStream = gulp.src(css.in)
            .pipe(preprocess({ DEBUG: true }))
            .pipe(sass(css.sassOpts))
            .on('error', notify.onError(function (error) {
                return 'An error occurred while compiling sass.\nLook in the console for details.\n' + error;
            }))
            .pipe(autoprefixer(css.autoprefixerOpts))
            
            .pipe(gulp.dest(css.out))
            .pipe(notify({
                message: "Compilation Successful"
            }));

        if (unsafeBuild) {
           prodBuildStream =            
                prodBuildStream.pipe(uncss({
                html: [html.in],
                ignore: [
                    //new RegExp('^\.is.*'), // dynamic class use like this 'isActive'
                    ///\w\.in/,
                    //".fade",
                    //".collapse",
                    //".collapsing",
                    ///(#|\.)navbar(\-[a-zA-Z]+)?/,
                    ///(#|\.)dropdown(\-[a-zA-Z]+)?/,
                    /(#|\.)modal(\-[a-zA-Z]+)?/,
                    /(#|\.)spinning(\-[a-zA-Z]+)?/,
                    /\.open/,
                    /\.active/,
                    /(#|\.)global-search(\-[a-zA-Z]+)?/,
                    //".modal.fade.in",
                    //".modal-dialog",
                    //".modal-document",
                    //".modal-scrollbar-measure",
                    //".modal-backdrop.fade",
                    //".modal-backdrop.in",
                    //".modal.fade.modal-dialog",
                    //".modal.in.modal-dialog",
                    //".modal-open",
                    //".in",
                    //".modal-backdrop",
                    '.dropdown .ti-angle-down',
                    '.sidebar.left.toggled',
                    '.sidebar.left .whats-new-button',
                    '.sidebar.left.toggled .whats-new-button',
                    '.sidebar.left .whats-new-button:before',
                    '.sidebar.left.toggled .whats-new-button:before',
                    '.sidebar.right.toggled',
                    '.sidebar.right h3',
                    '.sidebar-header',
                    '.toggled.sdm-search-wrapper',
                    '.ti-star.active',
                    '.ti-arrow-left',
                    '.ti-check',
                    '.ti-arrows-corner',
                    '.dropdown-menu .divider',
                    '.mCustomScrollBox',
                    '.tooltip',
                    '.tooltip.in',
                    '.tooltip.top',
                    '.tooltip.left',
                    '.tooltip.bottom',
                    '.tooltip-inner',
                    '.tooltip-arrow',
                    '.tooltip.top .tooltip-arrow',
                    '.tooltip.left .tooltip-arrow',
                    '.tooltip.bottom .tooltip-arrow',
                    '.tooltip .tooltip-inner',
                    '.form-control.error',
                    '.form-group.error .dropdown-toggle',
                    /\.word-icon/,
                    /\.pdf-icon/,
                    /\.method-icon/,
                    /\.xls-icon/,
                    /\.ppt-icon/,
                    /\.zip-icon/,
                    /\.aspx-icon/,
                    /\.mpp-icon/,
                    /\.topic-icon/,
                    /\.vsd-icon/, 
                    /\.visio-icon/,
                    /\.sharepoint-icon/,
                    /\.html-icon/,
                    /\.default-icon/,
                    /\.mCSB_scrollTools/, // whoever use this or happen to use this
                    /\.mCustomScrollbar/,
                    /\.mCSB_container/,
                    /\.mCSB_scrollTools_vertical/,
                    /\.alert/, // whoever use this or happen to use this
                    '.circular-btn[disabled]',
                    '.collapse.in',
                    '.navbar-collapse.in',
                    '.ti-thumb-up.like',
                    '.rating-triangle.dislike',
                    '.rating-triangle.like',
                    '.ti-thumb-up.active',
                    '.ti-thumb-up.like',
                    '.ti-thumb-down.active',
                    '.ti-thumb-up.dislike',
                  '.rating-triangle.like a',
                    '.rating-triangle.dislike a',
                    '.ti-pin2',
                    '.ti-pin-alt',
                    '.main-wrap.toggled',
                    '.UserPreferenceHeader.toggled',
                    '.form-control.error option',
                    '.boldText',
                    'table a:not(.btn)', 
                    '.table a:not(.btn)',
                    '.page-heading',
                    '.table>thead>tr.primary>td',
                    '.table>tbody>tr.primary>td',
                    '.table>tbody>tr.primary>th',
                    '.table>tbody>tr>td.primary',
                    '.table>tbody>tr>th.primary',
                    '.table>tfoot>tr.primary>td',
                    '.table>tfoot>tr.primary>th',
                    '.table>tfoot>tr>td.primary',
                    '.table>tfoot>tr>th.primary',
                    '.table>thead>tr.primary>td',
                    '.table>thead>tr.primary>th',
                    '.table>thead>tr>td.primary',
                    '.table>thead>tr>th.primary',
                    '.margin-t30-b30',
                    '.table>thead>tr>td',
                    '.hide',
                    '.tinymce-textarea.error ~ .mce-panel',
                    '.glyphicon-triangle-top',
                    '.glyphicon-triangle-bottom',
                    '.glyphicon-triangle-right',
                    '.main-nav-bar-toggled',
                    'nav nav-tabs',
                    '.nav-tabs>li',
                    'nav-tabs',
                    '.nav-tabs>li',
                    '.nav-tabs',
                    '.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus',
                    '.nav-tabs > li > a',
                    '.tab-content',
                    '.tab-content>.tab-pane',
                    '.tab-content>.active',
                    '.complex-activity',
                    '.panel-group',
                    '.panel-group .panel',
                    '.panel-group>.panel-default',
                    '.panel-group .panel-open',
                    '.panel-heading .panel-title',
                    '.panel-default>.panel-heading',
                    '.panel-group .panel-heading',
                    '.panel-heading, .panel-footer',
                    '.panel-default',
                    '.panel-open',
                    '.panel-title',
                    '.panel-group .panel+.panel',
                    '.collapse',
                    '.row',
                    '.topic-nav-list',
                    '.collapse .in',
                    '.panel .panel-collapse',
                    '.collapsing',
                    '.glyphicon',
                    '.glyphicon-remove',
                    '.glyphicon-plus',
                    '.glyphicon-minus',
                    '.panel-heading',
                    '.panel-collapse',
                    '.in',
                    '.collapse',
                    '.panel-body',
                    '.topic-nav-list',
                    '.topic-accordian-list',
                    '.topic-nav-list>.selected-topic',
                    '.selected-topic',
                    '.panel-title > a, .panel-title > small, .panel-title > .small, .panel-title > small > a, .panel-title > .small > a',
                    '.accordion-toggle',
                    '.panel-group .panel-title .accordion-toggle',
                    '.selected-category-pane',
                    '.selected-category-pane>.panel-heading',
                    '.parent .short',
                    '.parent .tall',
                    '.parent .taller',
                    '.parent .tallest',
                    '.parent .a',
                    '.parent .b',
                    '.parent .c',
                    '.parent .d'
                    

                ]
            
                }))
            .pipe(rename('main.min.css'))
            .pipe(sass({
                outputStyle: 'compressed'
            }))
            .pipe(gulp.dest(css.out))
        }

        return prodBuildStream.pipe(browsersync.reload({ stream: true }));
    } else {
        return gulp.src(css.in)
            .pipe(sourcemaps.init())
            .pipe(sass(css.sassOpts))
            .on('error', notify.onError(function (error) {
                return 'An error occurred while compiling sass.\nLook in the console for details.\n' + error;
            }))
            .pipe(sourcemaps.write())
            // .pipe(size({ title: 'CSS in ' }))
            // .pipe(pleeease(css.pleeeaseOpts))
            // .pipe(size({ title: 'CSS out ' }))
            .pipe(gulp.dest(css.out))
            .pipe(notify({
                message: "Compilation Successful"
            }))
            .pipe(browsersync.reload({ stream: true }));

    }

});

gulp.task('componentSass', function () {
    if (!devBuild) {
        componentCss.sassOpts.outputStyle = 'compressed';
        delete componentCss.sassOpts.sourceComments;

        var prodBuildStream = gulp.src(componentCss.in)
            .pipe(sass(componentCss.sassOpts))
            .on('error', notify.onError(function (error) {
                return 'An error occurred while compiling sass.\nLook in the console for details.\n' + error;
            }))
            .pipe(autoprefixer(css.autoprefixerOpts))
            .pipe(gulp.dest(componentCss.out))
            .pipe(notify({
                message: "Compilation Successful"
            }));

        if (unsafeBuild) {
            prodBuildStream =
                 prodBuildStream.pipe(uncss({
                     html: [html.in],
                     ignore: [
                         //new RegExp('^\.is.*'), // dynamic class use like this 'isActive'
                         ///\w\.in/,
                         //".fade",
                         //".collapse",
                         //".collapsing",
                         ///(#|\.)navbar(\-[a-zA-Z]+)?/,
                         ///(#|\.)dropdown(\-[a-zA-Z]+)?/,
                         ///(#|\.)modal(\-[a-zA-Z]+)?/,
                         /(#|\.)popover(\-[a-zA-Z]+)?/,
                         /(#|\.)tooltip(\-[a-zA-Z]+)?/,
                         /(#|\.)spinning(\-[a-zA-Z]+)?/,
                        //'.tooltip',
                        //'.tooltip.in',
                        //'.tooltip.top',
                        //'.tooltip-inner',
                        //'.tooltip-arrow',
                        //'.tooltip.top .tooltip-arrow',
                        //'.tooltip .tooltip-inner',
                         /\.open/,
                         /\.active/,
                         /(#|\.)global-search(\-[a-zA-Z]+)?/,
                         '.noDocument',
                         '.disable-elm',
                         '.hasDocument i',
                         '.ti-check',
                         //".modal.fade.in",
                         //".modal-dialog",
                         //".modal-document",
                         //".modal-scrollbar-measure",
                         //".modal-backdrop.fade",
                         //".modal-backdrop.in",
                         //".modal.fade.modal-dialog",
                         //".modal.in.modal-dialog",
                         //".modal-open",
                         //".in",
                         //".modal-backdrop",
                         '.dropdown .ti-angle-down',
                         '.sidebar.left.toggled',
                         '.sidebar.left .whats-new-button',
                         '.sidebar.left.toggled .whats-new-button',
                         '.sidebar.left .whats-new-button:before',
                         '.sidebar.left.toggled .whats-new-button:before',
                         '.sidebar.right.toggled',
                         '.toggled.sdm-search-wrapper',
                         '.ti-star.active',
                         '.ti-arrow-left',
                         '.ti-arrows-corner',
                         /\.alert/, // whoever use this or happen to use this
                         '.collapse.in',
                     '.navbar-collapse.in',
                    '.ti-thumb-up.like',
                    '.rating-triangle.dislike',
                    '.rating-triangle.like',
                    '.ti-thumb-up.active',
                    '.ti-thumb-up.like',
                    '.ti-thumb-down.active',
                    '.ti-thumb-up.dislike',
                    '.rating-triangle.like a',
                    '.rating-triangle.dislike a',
                     '.ti-pin2',
                    '.ti-pin-alt',
                    '.form-control.error',
                    '.form-group.error .dropdown-toggle',
                     '.main-wrap.toggled',
                    '.UserPreferenceHeader.toggled',
                    '.form-control.error option',
                    '.boldText',
                    'table a:not(.btn)',
                    '.table a:not(.btn)',
                    '.page-heading',
                    '.table>thead>tr.primary>td',
                    '.table>tbody>tr.primary>td',
                    '.table>tbody>tr.primary>th',
                    '.table>tbody>tr>td.primary',
                    '.table>tbody>tr>th.primary',
                   '.table>tfoot>tr.primary>td',
                    '.table>tfoot>tr.primary>th',
                    '.table>tfoot>tr>td.primary',
                    '.table>tfoot>tr>th.primary',
                    '.table>thead>tr.primary>td',
                    '.table>thead>tr.primary>th',
                    '.table>thead>tr>td.primary',
                    '.table>thead>tr>th.primary',
                    '.margin-t30-b30',
                    '.table>thead>tr>td',
                    '.hide',
                    '.tinymce-textarea.error ~ .mce-panel',
                    '.method-icon',
                     '.glyphicon-triangle-top',
                    '.glyphicon-triangle-bottom',
                    '.main-nav-bar-toggled',
                     '.glyphicon-triangle-right',
                     '.nav .nav-tabs',
                    '.nav-tabs',
                    '.nav-tabs>li',
                    '.nav-tabs',
                    '.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus',
                    '.nav-tabs > li > a',
                    '.tab-content',
                    '.tab-content>.tab-pane',
                    '.tab-content>.active',
                    '.complex-activity',
                    '.panel-group',
                    '.panel-group .panel',
                    '.panel-group>.panel-default',
                    '.panel-group .panel-open',
                    '.panel-heading .panel-title',
                    '.panel-default>.panel-heading',
                    '.panel-group .panel-heading',
                    '.panel-heading, .panel-footer',
                    '.panel-default',
                    '.panel-open',
                    '.panel-title',
                    '.panel-group .panel+.panel',
                    '.collapse',
                    '.topic-nav-list',
                    '.row',
                    '.collapse .in',
                    '.panel .panel-collapse',
                    '.collapsing',
                    '.panel-title .glyphicon',
                    '.panel-title .glyphicon-remove',
                    '.panel-title .glyphicon-plus',
                    '.panel-title .glyphicon-minus',
                    '.panel-title .panel-heading',
                    '.panel-collapse',
                    '.in',
                    '.collapse',
                    '.panel-body',
                    '.topic-nav-list',
                    '.topic-accordian-list',
                    '.topic-nav-list>.selected-topic',
                    '.selected-topic',
                    '.panel-title > a, .panel-title > small, .panel-title > .small, .panel-title > small > a, .panel-title > .small > a',
                    '.panel-group .panel-title .accordion-toggle',
                    '.accordion-toggle',
                    '.panel-group .panel-title .accordion-toggle',
                    '.selected-category-pane',
                    '.selected-category-pane>.panel-heading',
                    '.parent .short',
                    '.parent .tall',
                    '.parent .taller',
                    '.parent .tallest',
                    '.parent .a',
                    '.parent .b',
                    '.parent .c',
                    '.parent .d'
                     ]

                 }))
             //.pipe(rename('main.min.css'))
             .pipe(sass({
                 outputStyle: 'compressed'
             }))
             .pipe(gulp.dest(componentCss.out))
        }

        return prodBuildStream.pipe(browsersync.reload({ stream: true }));
    } else {
        return gulp.src(componentCss.in)
            .pipe(sourcemaps.init())
            .pipe(sass(componentCss.sassOpts))
            .on('error', notify.onError(function (error) {
                return 'An error occurred while compiling sass.\nLook in the console for details.\n' + error;
            }))
            .pipe(sourcemaps.write())
        // .pipe(size({ title: 'CSS in ' }))
        // .pipe(pleeease(css.pleeeaseOpts))
        // .pipe(size({ title: 'CSS out ' }))
        .pipe(gulp.dest(componentCss.out))
        .pipe(notify({
            message: "Compilation Successful"
        }))
        .pipe(browsersync.reload({ stream: true }));

    }

});

gulp.task('js', ['templateCache'], function () {
            if (devBuild) {

                return gulp.src(js.in)
                    .pipe(newer(js.out))
            .pipe(jshint('.jshintrc', { fail: true }))
            .pipe(notify(function (file) {
                        if (file.jshint && file.jshint.success) {
                                // Don't show something if success
                                return "Success";
                            }

                        var errors = file.jshint && file.jshint.results.map(function (data) {
                                if (data.error) {
                                    return "(" + data.error.line + ':' + data.error.character + ') ' + data.error.reason;
                                }
                            }).join("\n");
                        return file.relative + " (" + (file.jshint && file.jshint.results.length) + " errors)\n" + errors;
                        }))
                    	.pipe(jshint.reporter('jshint-stylish'))

                        // .pipe(jshint.reporter('default'))
                        // .pipe(jshint.reporter('fail'))
                        .pipe(gulp.dest(js.out));
                    }
                else {
                    //del([
                    //    dest + 'js/*'
                    //], { force: true });
                    return gulp.src(getFilesList())
                        //.pipe(deporder())
                        .pipe(concat(js.filename))
                        .pipe(ngAnnotate({
                            add: true,
                            single_quotes: true
                        }))
                      //  .pipe(size({ title: 'JS in ' }))
                        .pipe(stripdebug())
                        .pipe(uglify())
                      //  .pipe(size({ title: 'JS out ' }))
                        .pipe(gulp.dest(js.out));
                }
            });

        gulp.task('lazyLoadJS', function () {
            if (devBuild) {

                return gulp.src(components.in)
                    .pipe(newer(components.out))
                    .pipe(jshint('.jshintrc', { fail: true }))
                    .pipe(notify(function (file) {
                        if (file.jshint && file.jshint.success) {
                            // Don't show something if success
                            return "Success";
                        }

                        var errors = file.jshint && file.jshint.results.map(function (data) {
                            if (data.error) {
                                return "(" + data.error.line + ':' + data.error.character + ') ' + data.error.reason;
                            }
                        }).join("\n");
                        return file.relative + " (" + (file.jshint && file.jshint.results.length) + " errors)\n" + errors;
                    }))
                    	.pipe(jshint.reporter('jshint-stylish'))

                        // .pipe(jshint.reporter('default'))
                        // .pipe(jshint.reporter('fail'))
                        .pipe(gulp.dest(components.out));
            } else {
                //del([
                //    dest + 'components/*'
                //], { force: true });
                return gulp.src(components.in)
                    //.pipe(deporder())
                    //.pipe(concat(js.filename))
                    .pipe(ngAnnotate({
                        add: true,
                        single_quotes: true
                    }))
                  //  .pipe(size({ title: 'JS in ' }))
                    .pipe(stripdebug())
                    .pipe(uglify())
                  //  .pipe(size({ title: 'JS out ' }))
                    .pipe(gulp.dest(components.out));

            }
        });

gulp.task('copy', ['html'], function () {
            // the base option sets the relative root for the set of files,
            // preserving the folder structure
            if (devBuild) {
                gulp.src(config.filesToCopy, { base: source })
                    .pipe(gulp.dest(dest));
            } else {
                // copy and rename index.html
        gulp.src(dest + 'index.html', { base: source })
                    .pipe(rename('index.cshtml'))
                    .pipe(gulp.dest(destCshtml));
                // copy fonts
                gulp.src(config.filesToCopy[1], { base: source })
                    .pipe(gulp.dest(dest));
                // copy views
                gulp.src(config.filesToCopy[3], { base: source })
                    .pipe(gulp.dest(dest));
            }
        });

        gulp.task('templateCache', function () {
            return gulp.src([source + 'views/home.html', source + 'components/alert/alert.html'])
                .pipe(templateCache({ module: "sdmApp" }))
        .pipe(gulp.dest(source + 'vendor/'))
        .pipe(gulp.dest(dest + 'vendor/'));
        });

        // browser sync
gulp.task('browsersync', function () {
            return browsersync(syncOpts);
        });

        gulp.task('apiServer', shell.task([
              //'echo hello',
              'json-server fakeapi/generate.js --port 3004'
        ]));

        // default task
        gulp.task('default', ['html', 'images', 'fonts', 'sass', 'js', 'lazyLoadJS', 'copy', 'browsersync'], function () {

            // html changes
            gulp.watch(html.watch, ['html', browsersync.reload]);
            gulp.watch([source + 'templates/*.html'], ['html', browsersync.reload]);

            // image changes
            gulp.watch(images.in, ['images']);

            // font changes
            gulp.watch(fonts.in, ['fonts']);

            // sass changes
            gulp.watch([css.watch], ['sass']);

            // javascript changes
            gulp.watch(js.in, ['js', browsersync.reload]);

            // javascript components changes
            gulp.watch(components.in, ['lazyLoadJS', browsersync.reload]);

        });

        gulp.task('daily-build', ['html', 'images', 'fonts', 'sass', 'js', 'copy']);

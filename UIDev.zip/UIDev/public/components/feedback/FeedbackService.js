﻿(function () {
    angular.module('sdmApp')
	.service('FeedbackService', function ($http, URLS) {
	    this.getSurvey = function () {
	        return $http.get(URLS.survey);
	    };
	    this.addSurvey = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.post(URLS.survey, data, config);
	    };
	});
})();
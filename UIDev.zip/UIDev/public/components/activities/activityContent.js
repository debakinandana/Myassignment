﻿$(document).ready(function () {
    function e(e) {
        for (var t in s)
            if (s[t].hostName === e)
                return s[t].instrumentationKey
    }
    var t, o, a, p, i = (location.search.substring(1).search("&") > 0 ? location.search.substring(1).split("&") : location.search.substring(1),
    null);
    o = window.location.toString().indexOf("?id") > 0 ? window.location.toString().substring(window.location.toString().indexOf("?id") + 4, window.location.toString().indexOf("&complexityType") > 0 ? window.location.toString().indexOf("&complexityType") : window.location.toString().indexOf("&ref") > 0 ? window.location.toString().indexOf("&ref") : window.location.toString().length) : 0,
    a = window.location.toString().indexOf("&complexityType") > 0 ? window.location.toString().indexOf("&ref") > 0 ? window.location.toString().substring(window.location.toString().indexOf("&complexityType") + 16, window.location.toString().indexOf("&ref")) : window.location.toString().substring(window.location.toString().indexOf("&complexityType") + 16, window.location.toString().length) : 0;
    p = window.location.toString().indexOf("&urlPathName") > 0 ? window.location.toString().indexOf("&ref") > 0 ? window.location.toString().substring(window.location.toString().indexOf("&urlPathName") + 13, window.location.toString().indexOf("&ref")) : window.location.toString().substring(window.location.toString().indexOf("&urlPathName") + 13, window.location.toString().length) : "";
    if (p == "")
        p = "activity";
    var n, j, k, c, s = [{
        hostName: "sdmplus-dev.azurewebsites.net",
        instrumentationKey: "cc03d068-3d54-4e9e-a637-4b2f872bd0ae"
    }, {
        hostName: "sdmplus-test.azurewebsites.net",
        instrumentationKey: "4757f7dd-ca68-4df8-8a9d-809f9e9c6146"
    }, {
        hostName: "sdmplus-uat.azurewebsites.net",
        instrumentationKey: "7de5309f-2195-46bd-a614-160d60f50204"
    }, {
        hostName: "sdmplus.azurewebsites.net",
        instrumentationKey: "872736d4-8dec-4b64-a447-9d63e370ccf0"
    }, {
        hostName: "sdmplusdigi-dev.azurewebsites.net",
        instrumentationKey: "b30b267f-045a-4961-ba9f-ae7e0a664877"
    }, {
        hostName: "sdmplusdigi-test.azurewebsites.net",
        instrumentationKey: "df48b277-4b80-417d-b67f-2167969d3bff"
    }, {
        hostName: "sdmplusdigi-uat.azurewebsites.net",
        instrumentationKey: "8ade9937-b2b7-47b4-8103-77134536a4c6"
    }, {
        hostName: "sdmplusdigi.azurewebsites.net",
        instrumentationKey: "757dd375-bb4b-4fc5-b457-584723cdd54f"
    }, {
        hostName: "localhost",
        instrumentationKey: "1f894d03-9e08-4db3-9ff8-41b1ab85a1ab"
    }, {
        hostName: "sdmplusdev.azurewebsites.net",
        instrumentationKey: "f561c415-c692-4c21-a71d-8558ce50401a"
    }, {
        hostName: "sdmplustest.azurewebsites.net",
        instrumentationKey: "4091743e-60c1-435f-9c56-b0807c4275b4"
    }, {
        hostName: "sdmplusuat.azurewebsites.net",
        instrumentationKey: "71d3be0f-b9de-49a5-aabb-f407251336da"
    }, {
        hostName: "sdmplusbackup.azurewebsites.net",
        instrumentationKey: "692ab400-493b-400d-8fc2-61289d59d289"
    }, {
        hostName: "devsdmplus.azurewebsites.net",
        instrumentationKey: "b51f7e05-2582-4cfc-aa21-9853a5b8021a",
    }, {
        hostName: "testsdmplus.azurewebsites.net",
        instrumentationKey: "192cfb0b-f90d-4ecf-a456-4a019e4c537e",
    }, {
        hostName: "uatsdmplus.azurewebsites.net",
        instrumentationKey: "564d17fc-dd64-43d1-88ff-9df3dd746ccf",
    }], l = e(window.location.hostname), d = numberNoHyphens = l.replace(/-/g, ""), r = !1;
    $.ajax({
        type: "GET",
        url: "/api/CheckSiteRefreshing",
        async: !1,
        beforeSend: function (e) {
            var t = window.crypto || window.msCrypto;
            e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 10))
        },
        success: function (e) {
            r = e.siteRefresh,
            e.siteRefresh && $("#mainWrapper").html('<h2 class="page-heading" style="color:#cc0000">we are making some content updates and the site is being refreshed. Please try again after 5 minutes</h2>')
        }
    }),
 $.ajax({
     type: "GET",
     url: "/api/activities/activityContent?activityIdentifier=" + o + "&complexityId=" + parseInt(a, 10) + "&urlPathName=" + p,
     beforeSend: function (e) {
         var t = window.crypto || window.msCrypto;
         e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 10))
     },
     success: function (e) {

         if (e && e.activityResponse && !r) {
             if (e.isComplexity === true) {
                 document.title = e.title + "- " + e.complexityName;
             }
             else {
                 document.title = e.title;
             }
             //document.title = e.title + "- " + e.complexityName,
             $("#activityContent").html(e.activityResponse),
             "" == e.modifiedDate && null == e.modifiedDate ? $("#activityVersion").removeClass("hide").find("span").text("Version: " + e.activityVersion) : $("#activityVersion").removeClass("hide").find("span").text("Version: " + e.activityVersion + "   Date: " + e.modifiedDate),
             $(".footer").removeClass("hide"),
             $("#activityContent").find("a").attr("target", "_blank"),
             $("#feedBackBtn").removeClass("hide")
             if (e.complexityName !== null && e.isComplexity !== true) {
                 $("#complexityType").html(e.complexityName).removeClass("show");
             }
             else {
                 $("#complexityType").html(e.complexityName).removeClass("hide");
             }
             // null !== e.complexityName && e.isComplexity !== false && $("#complexityType").html(e.complexityName).removeClass("hide"),
             t = e,
                 $.ajax({
                     url: location.protocol + "//" + location.host + "/api/user/profile",
                     type: "GET",
                     async: !1,
                     success: function (e) {
                         n = e
                     }
                 });
             var o = [{
                 time: new Date,
                 name: "Microsoft.ApplicationInsights." + d + ".Event",
                 iKey: l,
                 data: {
                     baseData: {
                         name: "Activity",
                         properties: {
                             Alias: n.alias ? n.alias : null,
                             Domain: n.selectedDomainName ? n.selectedDomainName : null,
                             Methodology: n.selectedMethodName ? n.selectedMethodName : null,
                             ItemComment: $("#ratinCommentSection").val(),
                             ItemRating: i,
                             ItemTitle: t.title ? t.title : null,
                             Methodology1: n.methodName ? n.methodName : null,
                             ItemTypeId: 2,
                             ItemVersion: t.version,
                             Location: n.location ? n.location : null,
                             PhaseName: t.phaseName ? t.phaseName : null,
                             Role: n.jobTitle ? n.jobTitle : null,
                             SolutionMethodName: t.methodName ? t.methodName : null,
                             url: window.location.href,
                             "Auth User Id": n.alias ? n.alias : null,
                             "Telemtry Type": "customEvent",
                             ComplexityType: t.complexityName,
                             PhaseId: t.phaseIds,
                             MethoId: t.methodId,
                             DomainId: n.selectedDomainId,
                             SolutionMethodId: t.solutionMethodId,
                             ActivityId: t.id,
                             Referrer: window.location.toString().indexOf("&ref") > 0 ? window.location.toString().substring(window.location.toString().indexOf("&ref") + 5, window.location.toString().length) : "sdmplus"
                         },
                         ver: 2
                     },
                     baseType: "EventData"
                 }
             }];
             $.ajax({
                 url: "https://dc.services.visualstudio.com/v2/track",
                 type: "POST",
                 contentType: "application/json; charset=utf-8",
                 dataType: "json",
                 jsonpCallback: function (e) { },
                 jsonp: !0,
                 data: JSON.stringify(o),
                 success: function (e) { }
             })
         } else
             r ? $("#mainWrapper").html('<h2 class="page-heading" style="color:#cc0000">we are making some content updates and the site is being refreshed. Please try again after 5 minutes</h2>') : (document.title = "No Activity Found",
             document.write("No Activity Found"))
     },
     error: function (e, t) {
         switch (e.status) {
             case 400:
                 break;
             case 404:
                 break;
             case 500:
         }
         null === window.opener || void 0 === window.opener ? window.location.href = window.location.origin : (window.close(),
         window.opener.location.reload())
     }
 }),
   



    

    //EventCalls

$.ajax({
    url: location.protocol + "//" + location.host + "/api/user/profile",
    type: "GET",
    async: !1,
    beforeSend: function (e) {
        var t = window.crypto || window.msCrypto;
        e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 10))
    },
    success: function (e) {
        c = e
    }
});
    var eventCall = [{
        time: new Date,
        name: "Microsoft.ApplicationInsights." + d + ".Event",
        ikey: l,
        data: {
            baseData: {
                name: "EventCalls",
                properties: {
                    Alias: c.alias ? c.alias : null,
                    Domain: c.selectedDomainName ? c.selectedDomainName : null,
                    Methodology: c.selectedMethodName ? c.selectedMethodName : null,

                    ItemTitle: c.title ? c.title : null,

                    
                    Location: c.location ? c.location : null,
                    PhaseName: c.phaseName ? c.phaseName : null,
                    Role: c.lobTitle ? c.lobTitle : null,
                    SolutionMethodName: c.methodName ? c.methodName : null,
                    url: window.location.href,
                    "Auth User Id": c.alias ? c.alias : null,
                    "Telemtry Type": "customEvent",
                    ComplexityType: c.complexityName,
                    PhaseId: c.phaseIds,
                    MethoId: c.methodId,
                    DomainId: c.selectedDomainId,
                    SolutionMethodId: c.solutionMethodId,
                    ActivityId: c.id,
                    Referrer: window.location.toString().indexOf("&ref") > 0 ? window.location.toString().substring(window.location.toString().indexOf("&ref") + 5, window.location.toString().length) : "sdmplus"
                },
                ver: 2
            },
            baseType: "EventData"
        }
    }];
    $.ajax({
        url: "https://dc.services.visualstudio.com/v2/track",
        type: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        jsonpCallback: function (e) { },
        jsonp: !0,
        data: JSON.stringify(eventCall),
        success: function (e) { }
    }),


    $("#feedBackBtn").on("click", function () {
        $("#dialog").removeClass("hide");
        var e;
        null !== window.opener && void 0 !== window.opener && (e = $(window.opener.document.body).find("#activityFeebackLink")),
        i = null,
        dialog = $("#dialog").dialog({
            draggable: !1,
            resizable: !1,
            width: 400,
            modal: !0,
            position: {
                my: "top",
                at: "top+250"
            },
            dialogClass: "custom-dialog",
            open: function () {
                $("#dialog").html($("#dialog").html())
            }
        }),
        $("#ratinCommentSection").val("").attr("placeholder", "Tell us why? (optional)?"),
        $("#activityTitle").html(document.title),
        $("#noBtn,#yesBtn").find("i").css("color", "#cdcdcd"),
        $("#errorSection,#errorMsg").addClass("hide"),
        $("#submitFeedBackBtn,#cancelBtn").removeAttr("disabled", "disabled"),
        $("#submitFeedBackBtn").addClass("btn-primary"),
        $("#cancelBtn").addClass("btn-grey"),
        $("#cancelBtn").on("click", function () {
            $("#dialog").dialog("close")
        }),
        $(".like-btn").on("click", function (e) {
            "yesBtn" === $(e.currentTarget).attr("id") ? ($(e.currentTarget).find("i").css("color", "green"),
            $("#noBtn").find("i").css("color", "#cdcdcd"),
            $("#ratinCommentSection").attr("placeholder", "Tell us why? (optional)"),
            i = !0) : ($(e.currentTarget).find("i").css("color", "red"),
            $("#yesBtn").find("i").css("color", "#cdcdcd"),
            $("#ratinCommentSection").attr("placeholder", "I'm changing my previous opinion. Document is no longer relevant as it doesn't reflect recent process changes."),
            i = !1)
        }),
        $("#submitFeedBackBtn").on("click", function () {
            if (null === i)
                $("#errorMsg").removeClass("hide").text("Please select your opinion").css("color", "#cc0000");
            else {
                $("#errorMsg").addClass("hide"),
                localStorage.setItem("comment", $("#ratinCommentSection").val()),
                localStorage.setItem("commentsStatus", i),
                localStorage.setItem("methodName", t.methodName),
                localStorage.setItem("methodId", t.methodId),
                localStorage.setItem("phaseId", t.phaseIds),
                localStorage.setItem("phaseName", t.phaseName),
                localStorage.setItem("activityName", t.title),
                localStorage.setItem("activityId", t.id),
                localStorage.setItem("activityUrl", window.location.href),
                null !== t.methodName && t.methodName.trim().length > 0 && t.methodId > 0 ? ($("#errorSection").addClass("hide"),
                $("#submitFeedBackBtn,#cancelBtn").attr("disabled", "disabled").removeClass("btn-primary").removeClass("btn-grey"),
                $("#ratinCommentSection").css("border", "none"),
                $.ajax({
                    type: "POST",
                    url: location.origin + "/api/activities/contentRatingFeedback",
                    beforeSend: function (e) {
                        var t = window.crypto || window.msCrypto;
                        e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 8) + "-" + Math.floor(1e3 + 9e3 * t.getRandomValues(new Uint32Array(1))[0]) + "-" + Math.floor(1e3 + 9e3 * t.getRandomValues(new Uint32Array(1))[0]) + "-" + Math.floor(1e3 + 9e3 * t.getRandomValues(new Uint32Array(1))[0]) + "-" + t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 19)),
                        e.setRequestHeader("__RequestVerificationToken", "undefined" !== window.localStorage.getItem("key") ? window.localStorage.getItem("key") : window.opener ? window.opener.angular.element("input[name='__RequestVerificationToken']").val() : "")
                    },
                    data: {
                        methodId: t.methodId,
                        phaseName: t.phaseName,
                        phaseId: t.phaseIds,
                        methodName: t.methodName,
                        emailType: 3,
                        contentRating: i,
                        feedback: $("#ratinCommentSection").val(),
                        activityId: t.id,
                        activityName: t.title,
                        url: window.location.href
                    },
                    success: function (e) {
                        e.status ? ($("#dialog").addClass("hide"),
                        $("#dialog").dialog("close"),
                        $("#statusDialog").removeClass("hide"),
                        $("#statusDialog").dialog({
                            draggable: !1,
                            resizable: !1,
                            width: 400,
                            modal: !0,
                            position: {
                                my: "top",
                                at: "top+250"
                            },
                            dialogClass: "custom-dialog",
                            open: function () {
                                $("#dialog").html($("#dialog").html())
                            }
                        }),
                        i = null,
                        setTimeout(function () {
                            $("#statusDialog").dialog("close")
                        }, 1500)) : $("#errorSection").removeClass("hide")
                    },
                    error: function () {
                        $("#errorSection").removeClass("hide"),
                        $("#submitFeedBackBtn,#cancelBtn").removeAttr("disabled", "disabled"),
                        $("#submitFeedBackBtn").addClass("btn-primary"),
                        $("#cancelBtn").addClass("btn-grey")
                    }
                })) : ($("#dialog").addClass("hide"),
                $("#dialog").dialog("close"),
                $("#statusDialog").removeClass("hide"),
                $("#statusDialog").dialog({
                    draggable: !1,
                    resizable: !1,
                    width: 400,
                    modal: !0,
                    position: {
                        my: "top",
                        at: "top+250"
                    },
                    dialogClass: "custom-dialog",
                    open: function () {
                        $("#dialog").html($("#dialog").html())
                    }
                }),
                setTimeout(function () {
                    $("#statusDialog").dialog("close")
                }, 1e3)),
                $.ajax({
                    url: location.protocol + "//" + location.host + "/api/user/profile",
                    type: "GET",
                    async: !1,
                    beforeSend: function (e) {
                        var t = window.crypto || window.msCrypto;
                        e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 10))
                    },
                    success: function (e) {
                        n = e
                    }
                });
                var e = [{
                    time: new Date,
                    name: "Microsoft.ApplicationInsights." + d + ".Event",
                    iKey: l,
                    data: {
                        baseData: {
                            name: "Rating",
                            properties: {
                                Alias: n.alias ? n.alias : null,
                                Domain: n.selectedDomainName ? n.selectedDomainName : null,
                                Methodology: n.selectedMethodName ? n.selectedMethodName : null,
                                ItemComment: $("#ratinCommentSection").val(),
                                ItemRating: i,
                                ItemTitle: t.title ? t.title : null,
                                Methodology: n.methodName ? n.methodName : null,
                                ItemTypeId: 2,
                                ItemVersion: t.version,
                                Location: n.location ? n.location : null,
                                PhaseName: t.phaseName ? t.phaseName : null,
                                Role: n.jobTitle ? n.jobTitle : null,
                                SolutionMethodName: t.methodName ? t.methodName : null,
                                url: window.location.href,
                                "Auth User Id": n.alias ? n.alias : null,
                                "Telemtry Type": "customEvent",
                                ComplexityType: t.complexityName,
                                PhaseId: t.phaseIds,
                                MethoId: t.methodId,
                                DomainId: n.selectedDomainId,
                                SolutionMethodId: t.solutionMethodId,
                                ActivityId: t.id
                            },
                            ver: 2
                        },
                        baseType: "EventData"
                    }
                }];
                $.ajax({
                    url: "https://dc.services.visualstudio.com/v2/track",
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    jsonpCallback: function (e) { },
                    jsonp: !0,
                    data: JSON.stringify(e),
                    success: function (e) { }
                })
            }
        })
    }),

    $(document).on("click", ".template-link", function (e) {
        $.ajax({
            url: location.protocol + "//" + location.host + "/api/user/profile",
            type: "GET",
            async: !1,
            beforeSend: function (e) {
                var t = window.crypto || window.msCrypto;
                e.setRequestHeader("correlationId", t.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 10))
            },
            success: function (e) {
                n = e
            }
        });
        var o = [{
            time: new Date,
            name: "Microsoft.ApplicationInsights." + d + ".Event",
            iKey: l,
            data: {
                baseData: {
                    name: "Template",
                    properties: {
                        Alias: n.alias ? n.alias : null,
                        Domain: n.selectedDomainName ? n.selectedDomainName : null,
                        Methodology: n.selectedMethodName ? n.selectedMethodName : null,
                        ItemTitle: $(".template-link").text(),
                        ItemTypeId: 1,
                        ItemVersion: $(".template-link").attr("data-version"),
                        Location: n.location ? n.location : null,
                        PhaseName: null,
                        Role: n.jobTitle ? n.jobTitle : null,
                        url: $(".template-link").attr("href"),
                        "Auth User Id": n.alias ? n.alias : null,
                        "Telemtry Type": "customEvent",
                        ComplexityType: t.complexityName,
                        MethodId: t.methodId,
                        DomainId: n.selectedDomainId,
                        ActivityId: t.id,
                        ActivityName: t.title,
                        ActivityUrl: window.location.href,
                        ItemId: $(".template-link").attr("item-id") ? $(".template-link").attr("item-id") : null
                    },
                    ver: 2
                },
                baseType: "EventData"
            }
        }];
        $.ajax({
            url: "https://dc.services.visualstudio.com/v2/track",
            type: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            jsonpCallback: function (e) { },
            jsonp: !0,
            data: JSON.stringify(o),
            success: function (e) { }
        })
    })
});

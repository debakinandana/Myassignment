/// <reference path="ActivitiesCtrl.js" />
angular.module('sdmApp')
    .service('ActivitiesService', function ($http, URLS) {
        this.getActivities = function (searchSortPaginateConfig) {
            var pageNumber = '?pageNumber=' + searchSortPaginateConfig.pageNumber,
                serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '',
                sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
                roles = searchSortPaginateConfig.roles.length ? '&roleIds=' + JSON.stringify(searchSortPaginateConfig.roles) : '',
                filterIds = searchSortPaginateConfig.filterIds.length ? '&phaseIds=' + JSON.stringify(searchSortPaginateConfig.filterIds) : '',
                domainId = '&domainId=' + searchSortPaginateConfig.domainId,
                methodId = '&methodId=' + searchSortPaginateConfig.methodId,
                complexityId = '&complexityId=' + searchSortPaginateConfig.complexityId;

            return $http.get(URLS.activities + pageNumber + '&pageSize=12' + serachQuery + sort + filterIds + roles + domainId + methodId + complexityId + '');
        };

        this.getSearchResult = function (searchSortPaginateConfig) {
            var pageNumber = '?pageNumber=' + searchSortPaginateConfig.pageNumber,
                sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
                searchQ = searchSortPaginateConfig.searchValue ? '&q=' + searchSortPaginateConfig.searchValue : '',
                roles = (searchSortPaginateConfig.roles && searchSortPaginateConfig.roles.length) ? '&roleIds=' + JSON.stringify(searchSortPaginateConfig.roles) : '',
                language = searchSortPaginateConfig.language ? '&language=' + searchSortPaginateConfig.language : '',
                filterIds = (searchSortPaginateConfig.filterIds && searchSortPaginateConfig.filterIds.length) ? '&phaseIds=' + JSON.stringify(searchSortPaginateConfig.filterIds) : '',
                domainId = '&domainId=' + searchSortPaginateConfig.domainId,
                methodId = '&methodId=' + searchSortPaginateConfig.methodId,
                complexityId = '&complexityId=' + searchSortPaginateConfig.complexityId;
            return $http.get(URLS.search + pageNumber + searchQ + sort + filterIds + roles + language + domainId + methodId + complexityId + '&pageSize=12&idrSearchArtifactType=Activity');
        };

        this.updateFavourite = function (data) {
            return $http.patch(URLS.activities, data);
        };
        this.updateRating = function (data) {
            return $http.patch(URLS.activities, data);
        };
        this.getActivityDescription = function (id) {
            return $http.get(URLS.GetDynamicActivityContent, { params: { activityIdentifier: id } });
        };
        this.getUserDetail = function () {
            return $http.get(URLS.profileUrl);
        };

    });
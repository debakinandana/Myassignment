(function () {
    var commonFunction, loggingData;
    function ActivitiesCtrl($state, $stateParams, $timeout, $rootScope, $ocLazyLoad, $uibModal, ActivitiesService, TOAST_MESSAGE, alerting, $scope, SharedService, $window, sdmSiteRefresh, $http) {
        var activitiesvm = this;
        activitiesvm.$state = $state;
        activitiesvm.isListMode = true;
        activitiesvm.selection = [];

        // pagination
        activitiesvm.templates = [];
        activitiesvm.totalItems = 0;
        activitiesvm.pageSize = 12;
        activitiesvm.pagination = {
            current: $state.params.page
        };
        activitiesvm.sortType = $state.params.sort;
        activitiesvm.searchFilter = {
            title: ''
        };
        activitiesvm.filterIds = [];
        activitiesvm.roles = [];
        $rootScope.$emit('updateUserView');
        activitiesvm.handleComplexityFilter = function (complexityType, searchText) {
            activitiesvm.complexityType = parseInt(complexityType ? complexityType : 0, 10);
            //ActivitiesService.getActivities({ pageNumber: activitiesvm.pagination.current, searchValue: encodeURIComponent(activitiesvm.searchFilter.title), sort: activitiesvm.sortType, filterIds: activitiesvm.filterIds, roles: activitiesvm.roles, domainId: $rootScope.userDomainId ? $rootScope.userDomainId : 0, methodId: $rootScope.userMethodologyId ? $rootScope.userMethodologyId : 0, complexityId: activitiesvm.complexityType? activitiesvm.complexityType:1 }).success(function (res) {
            //    activitiesvm.activities = res.activities;
            //    activitiesvm.totalItems = res.count;
            //    activitiesvm.selection = [];
            //    activitiesvm.selectedAll = false;
            //});
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
        }


        $rootScope.$on('maskHidden', function () {
            if (activitiesvm.selectedtemplateindex !== undefined && activitiesvm.selectedtemplateindex !== null) {
                activitiesvm.templateExpanded = false;
                activitiesvm.sampleActive = false;
                activitiesvm.localizedActive = false;
                clearSubSelection(activitiesvm.selectedtemplateindex);
                angular.element(activitiesvm.sourceElem).focus();
            }
        });
        function clearSubSelection(selectedIndex) {
            subSelection = [];
            activitiesvm.subSelectAll = false;
            var property;

            if (activitiesvm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else {
                property = 'sampleTemplates';
            }
            angular.forEach(activitiesvm.activities[selectedIndex]['projectComplexityDetails'],
                function (subTemplate) {
                    subTemplate.Selected = false;
                });
        }
        activitiesvm.toggleTemplates = function (template, tmplName, index, e, appvm) {
            e.preventDefault();
            if (template.isComplexity) {
                console.log(template.isComplexity);
                activitiesvm.templateExpanded = !activitiesvm.templateExpanded;
                activitiesvm.templatetype = tmplName;
                activitiesvm.selectedSubTemplate = template['projectComplexityDetails'];
                activitiesvm.selectedtemplateindex = index;
                clearSubSelection(activitiesvm.selectedtemplateindex);
                activitiesvm.sourceelem = e.currenttarget;
                //activitiesvm.hideComplexity = true;
                //if ($scope.addInviteesDisabled) { return false; }
                //getResultsPage();
            }

        }
        SharedService.getComplexities().success(function (res) {
            if (res) {
                activitiesvm.complexityList = res;
                //activitiesvm.complexityType = 1;
            }
        });

        function getSearchResults() {
            ActivitiesService.getUserDetail().success(function (res) {
                ActivitiesService.getSearchResult({ pageNumber: activitiesvm.pagination.current, searchValue: encodeURIComponent(activitiesvm.searchFilter.title), sort: activitiesvm.sortType, filterIds: activitiesvm.filterIds, roles: activitiesvm.roles, domainId: $rootScope.userDomainId !== undefined ? $rootScope.userDomainId : res.selectedDomainId, methodId: $rootScope.userMethodologyId !== undefined ? $rootScope.userMethodologyId : res.selectedMethodologyId, complexityId: activitiesvm.complexityType ? activitiesvm.complexityType : 0 }).success(function (res) {
                    activitiesvm.activities = res.records;
                    activitiesvm.totalItems = res.count;
                    activitiesvm.selection = [];
                    activitiesvm.selectedAll = false;
                    loggingData = res;

                    //$scope.template.isComplexity = [];
                    //for (var i = 0; i < res.records.length; i++) {
                    //    $scope.template.isComplexity.push(res.records[i].isComplexity)

                    //}
                });
            })
        }

        function getResultsPage() {
            //if ($rootScope.userDomainId === undefined && $rootScope.userMethodologyId === undefined) {
            //    ActivitiesService.getUserDetail().success(function (res) {
            //        ActivitiesService.getActivities({ pageNumber: activitiesvm.pagination.current, searchValue: encodeURIComponent(activitiesvm.searchFilter.title), sort: activitiesvm.sortType, filterIds: activitiesvm.filterIds, roles: activitiesvm.roles, domainId: res.selectedDomainId, methodId: res.selectedMethodologyId, complexityId: activitiesvm.complexityType ? activitiesvm.complexityType : 0 }).success(function (res) {
            //            activitiesvm.activities = res.activities;
            //            activitiesvm.totalItems = res.count;
            //            activitiesvm.selection = [];
            //            activitiesvm.selectedAll = false;
            //            loggingData = res.activities;
            //        });
            //    })
            //}
            //else {
            //    ActivitiesService.getActivities({ pageNumber: activitiesvm.pagination.current, searchValue: encodeURIComponent(activitiesvm.searchFilter.title), sort: activitiesvm.sortType, filterIds: activitiesvm.filterIds, roles: activitiesvm.roles, domainId: $rootScope.userDomainId, methodId: $rootScope.userMethodologyId, complexityId: activitiesvm.complexityType ? activitiesvm.complexityType : 0 }).success(function (res) {
            //        activitiesvm.activities = res.activities;
            //        activitiesvm.totalItems = res.count;
            //        activitiesvm.selection = [];
            //        activitiesvm.selectedAll = false;
            //        loggingData = res.activities;
            //    });
            //}
            ActivitiesService.getUserDetail().success(function (res) {
                ActivitiesService.getActivities({ pageNumber: activitiesvm.pagination.current, searchValue: encodeURIComponent(activitiesvm.searchFilter.title), sort: activitiesvm.sortType, filterIds: activitiesvm.filterIds, roles: activitiesvm.roles, domainId: $rootScope.userDomainId !== undefined ? $rootScope.userDomainId : res.selectedDomainId, methodId: $rootScope.userMethodologyId !== undefined ? $rootScope.userMethodologyId : res.selectedMethodologyId, complexityId: activitiesvm.complexityType ? activitiesvm.complexityType : 0 }).success(function (res) {
                    activitiesvm.activities = res.activities;
                    activitiesvm.totalItems = res.count;
                    activitiesvm.selection = [];
                    activitiesvm.selectedAll = false;
                    loggingData = res.activities;

                    $scope.template.isComplexity = [];
                    for (var i = 0; i < activitiesvm.activities.length; i++) {
                        $scope.template.isComplexity.push(activitiesvm.activities[i].isComplexity)

                    }
                    //activitiesvm.activities.isComplexity = [];
                    //for (var i = 0; i < activitiesvm.activities.length; i++) {

                    // activitiesvm.activities.isComplexity.push(activitiesvm.activities[i].isComplexity)

                    //}
                    //var bool = new Boolean(data);
                    // for (var i = 0; i < activitiesvm.activities.length; i++) {
                    //if (activitiesvm.activities[i].isComplexity == true) {
                    // activitiesvm.hideComplexity = false;
                    //}
                    //}
                    // activitiesvm.hidecomplexity = [];
                    //for (var i = 0; i < activitiesvm.activities.length; i++) {
                    //    if (activitiesvm.activities[i].isComplexity == true) {
                    //        activitiesvm.hidecomplexity[i] = true;
                    //    }

                    //    else {
                    //        activitiesvm.hidecomplexity[i] = true;
                    //    }
                    //}
                    //data.forEach(function (bool) {
                    // if (bool === true) {
                    // activitiesvm.hideComplexity = false;
                    //}
                    //else {
                    //  activitiesvm.hideComplexity = true;
                    // }
                    // });
                    // bool = new Boolean(data);

                    //var LINQ = require("node-linq").LINQ;
                    //var queryResult = new LINQ(res)
                    //.Where(function (x) { return x.activities.isComplexity == false })

                    //.ToArray();
                    //console.log(queryResult);
                    //console.log(trueCount, falseCount);
                    //for (var i = 0 ; i < data.length; i++) {
                    //    if (data1.indexOf[i].value === false) {
                    //        var x = document.getElementById("hideComplexity");
                    //        if (x.style.display === "none") {
                    //            x.style.display = "block";
                    //        } else {
                    //            x.style.display = "none";
                    //        }
                    //        activitiesvm.hideComplexity = true;
                    //        alert("true");
                    //    }
                    //}
                    //var versionList = new Array();
                    // for (var i = 0; i < activitiesvm.activities[i].length; i++) {
                    // versionList.push(toString(activitiesvm.activities[i].isComplexity));
                    //}
                    //loggingData = res.activities;
                });
            })


        }

        getResultsPage();

        activitiesvm.pageChangeHandler = function (newPageNumber, oldPageNumber, searchText) {
            if (newPageNumber !== oldPageNumber) {
                activitiesvm.pagination.current = newPageNumber;
                if (searchText == '')
                    getResultsPage();
                else
                    getSearchResults();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };

        activitiesvm.searchTemplate = function (searchText) {
            activitiesvm.searchFilter.title = searchText;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
            SharedService.logEvent('LocalSearch', { title: searchText, itemTypeId: 2, url: window.location.href });
        };

        activitiesvm.sortBy = function (sortItem, searchText) {
            activitiesvm.sortType = sortItem;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
            $state.go('.', { sort: sortItem }, { notify: false });
        };

        //activitiesvm.toggleView = function () {
        //    activitiesvm.isListMode = !activitiesvm.isListMode;
        //};

        activitiesvm.emailFeedBack = function (template) {
            SharedService.logEvent('Rating', { methodId: JSON.parse(localStorage.getItem('userMethodologyId')), methodName: localStorage.getItem('userMethodologyName'), phaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'), emailType: 3, ContentRating: localStorage.getItem('commentsStatus'), feedback: localStorage.getItem('comment'), activityName: null, url: window.location.href });
        };
        //activitiesvm.localSearchEvent = function (template, title) {

        //    var searchText = template.key;

        //    SharedService.logEvent('LocalSearch', { ItemTitle:searchText, url: window.location.href });
        //};

        $(document).on("click", function (e) {
            var operationId = e.target.id;

            SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        });

        activitiesvm.togglePreview = function (template) {
            template.isPreviewing = !template.isPreviewing;
        };
        activitiesvm.copyComplexityLink = function (sample, template) {
            sample.copyLink = 'Copied!'
            $timeout(function () {
                delete sample.copyLink;

            }, 1000);
        }
        activitiesvm.dynamicPopover = {
            templateUrl: 'views/partials/preview-template.html',
            appendToBody: true
        };

        //copy to clipboard
        activitiesvm.textToCopy = 'I am cool';

        activitiesvm.copyLinkFn = function (template) {
            template.copyLink = 'Copied!';
            $timeout(function () {
                delete template.copyLink;
            }, 1000);
        };

        activitiesvm.fail = function (err) {
            console.error('Error!', err);
        };

        activitiesvm.checkAll = function (isSelectedAll, selectedTemplates, searchText) {
            activitiesvm.selection = [];
            angular.forEach(selectedTemplates, function (template) {
                template.Selected = isSelectedAll;
                if (isSelectedAll) {
                    activitiesvm.selection.push(template);
                }
            });
        };

        //activitiesvm.checkAll = function () {
        //    if (activitiesvm.selectedAll) {
        //        activitiesvm.selectedAll = true;
        //    } else {
        //        activitiesvm.selectedAll = false;
        //    }
        //    angular.forEach(activitiesvm.activities, function (activity) {
        //        activity.Selected = activitiesvm.selectedAll;
        //        if (activitiesvm.selectedAll) {
        //            activity.fileLocation && activitiesvm.selection.push(activity);
        //        } else {
        //            activitiesvm.selection = [];
        //            return;
        //        }

        //    });
        //};
        activitiesvm.toggleSingleSelection = function (template) {
            var idx = 0;
            for (var i = 0; i < activitiesvm.selection.length; i++) {
                var templateSelected = activitiesvm.selection[i];
                if (template.id === templateSelected.id) {
                    idx = -1;
                    activitiesvm.selection.pop(templateSelected, 1);
                    break;
                }
            }
            if (idx > -1) {
                template.fileLocation && activitiesvm.selection.push(template);
            }
        };

        activitiesvm.addToFavorite = function (id) {
            if (activitiesvm.selection.length > 0) {
                var data = [];
                for (var i = 0; i < activitiesvm.selection.length; i++) {
                    activitiesvm.selection[i].isFavourite = true; // update ui with active color
                    data.push({
                        id: activitiesvm.selection[i].id,
                        title: activitiesvm.selection[i].title,
                        isFavourite: true,
                        complexityId: activitiesvm.selection[i].complexityId
                    });
                }
                ActivitiesService.updateFavourite(data).success(function () {
                    if (activitiesvm.selection.length == 1) {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                    }
                    else {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITES_ADDED);
                    }
                });

            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_ACTIVITY_SELECTED);
            }
        };

        activitiesvm.toggleFavourite = function (activity) {
            activity.isFavourite = !activity.isFavourite;
            var data = [{
                id: activity.id,
                title: activity.title,
                isFavourite: activity.isFavourite,
                complexityId: activity.complexityId
            }];
            ActivitiesService.updateFavourite(data).success(function (res) {
                if (activity.isFavourite) {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                }

            });
        };



        activitiesvm.mailToFunctionality = function () {
            if (activitiesvm.selection.length > 0) {
                var body_message = '',
                    win = '',
                    email = '',
                    subject = 'List of Activities',
                    mailto_link;

                for (var i = 0; i < activitiesvm.selection.length; i++) {
                    var activityUrl = activitiesvm.selection[i].fileLocation;
                    body_message = body_message + (i + 1) + '. ' + encodeURIComponent(activityUrl) + '%0D%0A';
                }

                mailto_link = 'mailto:' + email + '?subject=' + subject + '&body=' + body_message;

                win = window.open(mailto_link, 'emailWindow');
                if (win && win.open && !win.closed) {
                    $timeout(function () {
                        win.close()
                    }, 1000);
                    // win.close()
                };
            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_ACTIVITY_SELECTED);
            }

        }

        // filtering 
        $rootScope.$on('phaseFilterChanged', function (event, filterIds, searchText) {
            activitiesvm.filterIds = filterIds;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();

        });

        $rootScope.$on('roleFilterChanged', function (event, roleIds, complexityId, searchText) {
            activitiesvm.roles = roleIds;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
        });

        activitiesvm.openReadMore = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/read-more.html',
                controller: 'ReadMoreCtrl',
                aria: 'Read More',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });

        };

        activitiesvm.openActivityModal = function (template) {
            //if (!template.isExternal) {
            //    //$ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
            //    //ActivitiesService.getActivityDescription(template.id).success(function (res) {
            //    //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
            //    //                    .then(function () {
            //    //                        var modalInstance = $uibModal.open({
            //    //                            templateUrl: 'components/activities/activityDescription.html',
            //    //                            controller: 'ActivityDescCtrl',
            //    //                            size: 'lg',
            //    //                            aria: 'Activity Content',
            //    //                            resolve: {
            //    //                                selectedItem: function () {
            //    //                                    return res;
            //    //                                }
            //    //                            }
            //    //                        });
            //    //                    });
            //    //});
            //    //var url = $state.href('activities.activityContent', { id: template.id });
            //    //window.open(url, '_blank');
            //    //$window.open($state.href('activities.activityContent', { id: template.id }, { absolute: true }), '_blank');
            //    //$state.go('activities.activityContent', { id: template.id })
            //    //SharedService.openModal('activity', template.title, location.protocol + '//' + location.host + '/sdm/activityC:ontent/activityDetail.html?id=' + template.id + '');
            //    var complexityId = activitiesvm.complexityType ? activitiesvm.complexityType : 1;
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(template.fileLocation, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();

            //    //$window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + template.id + '', { id: template.id }, { absolute: true }, '_blank');

            //    //var height = screen.height;
            //    //window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + template.id + '', '_blank', "width=" + screen.width + ",height=" + height + ",resizable=yes,scrollbars=yes,titlebar=yes,top=" + screen.height / 2 + ",left=" + screen.width / 2 + "", true).focus();
            //     //window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + template.id + '', '_blank', "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width="+screen.width+", height=1000, top=1, left=1");


            //}
            //else {
            //   // SharedService.openModal(template.type, template.title, template.fileLocation);
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(template.fileLocation, template.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            if (template.isExternal) {
                SharedService.logEvent('Activity', {
                    itemTypeId: 2,
                    title: template.title,
                    url: template.fileLocation,
                    version: template.version,
                    MethodName: template.solutionMethodName,
                    phaseName: template.phaseTitle,
                    rating: null,
                    phaseId: template.phaseIds,
                    itemId: template.id,
                    solutionMethodId: template.solutionMethodId,
                    complexityType: template.complexityName
                });
            }
            //$rootScope.$on('$locationChangeStart', function (event, current, previous) {
            // console.log("Previous URL" + previous);
            //});

            var complexityId = activitiesvm.complexityType ? activitiesvm.complexityType : 1;
            var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            var mywindow = window.open(template.fileLocation, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            mywindow.focus();


        };

        activitiesvm.openRating = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                aria: 'rating',
                size: 'sm',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                template.title = selectedItem.title;
                template.fileLocation = selectedItem.fileLocation;
                template.version = null;
                template.comment = selectedItem.comment;
                template.rating = selectedItem.rating;

            });
        };
        $rootScope.$on('maskHidden', function () {
            if (activitiesvm.selectedTemplateIndex !== undefined && activitiesvm.selectedTemplateIndex !== null) {
                activitiesvm.templates[activitiesvm.selectedTemplateIndex].templateExpanded = false;
                activitiesvm.templates[activitiesvm.selectedTemplateIndex].sampleActive = false;
                activitiesvm.templates[activitiesvm.selectedTemplateIndex].localizedActive = false;
                clearSubSelection(activitiesvm.selectedTemplateIndex);
                angular.element(activitiesvm.sourceElem).focus();
            }
        });

    }
    angular.module('sdmApp')
        .controller('ActivitiesCtrl', ActivitiesCtrl)
        .controller('ReadMoreCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('ActivityDescCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('RatingCtrl', function ($scope, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem, $http) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.title = selectedItem.title;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };

            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                ratingData.isSubmit = true;
                var data = {
                    itemTypeId: 2,
                    title: ratingData.title,
                    url: ratingData.fileLocation,
                    version: ratingData.version,
                    rating: ratingData.rating,
                    comment: ratingData.comment,
                    MethodName: ratingData.solutionMethodName,
                    phaseName: ratingData.phaseTitle,
                    complexityType: ratingData.complexityName,
                    phaseId: ratingData.phaseIds,
                    itemId: ratingData.id,
                    solutionMethodId: ratingData.solutionMethodId
                };
                if (ratingData.rating == null) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    SharedService.logEvent('Rating', data);

                    if (ratingData.solutionMethodName !== null) {
                        if (ratingData.solutionMethodId > 0) {
                            SharedService.sendUserFeedback({ methodId: ratingData.solutionMethodId, methodName: ratingData.solutionMethodName, phaseName: ratingData.phaseTitle, phaseId: ratingData.phaseIds, emailType: 3, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: ratingData.title, activityId: ratingData.id, url: ratingData.fileLocation }).success(function (res) {
                                if (res.status) {
                                    alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                                }
                                else {
                                    alerting.alert('danger', res.errorMessage)
                                }
                                $scope.cancel();
                            })
                        }
                        else {
                            alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                            $scope.cancel();
                        }

                    }
                    else {
                        SharedService.logEvent('Rating', data);
                        alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                        $scope.cancel();
                    }

                }

            };


        });

})();
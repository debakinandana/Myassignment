﻿(function () {
    function TopicService($http, URLS) {
        this.getTopics = function () {
            return $http.get(URLS.topics);
        };

        this.updateFavourite = function (data) {
            return $http.patch(URLS.topics, data);
        };
        this.updateRating = function (data) {
            return $http.patch(URLS.topics, data);
        };
       this.getTopic=function(id){
           return $http.get(URLS.topics);
       };
    }

    angular.module('sdmApp')
        .service('TopicService', TopicService);
})();
﻿(function () {
    function TopicsCtrl($rootScope, $scope, TopicService, $state, $ocLazyLoad, $uibModal, alerting, TOAST_MESSAGE, $sce, SharedService, $location) {
        var topicvm = this;
        topicvm.selectedTopic = null;
        topicvm.$state = $state;
        console.log($state)
        function getSelectedTopic(resArr, topicName) {
            return resArr.filter(function (item) {
                return item.name === (topicName || $state.params.topicName);
            })[0];
        }
        $('.scroll-to').bind('click');
        $('body').on('click', '.scroll-to', function (e) {
            if (document.getElementById(e.currentTarget.getAttribute('data-attr-id')))
                $('body').scrollTop(document.getElementById(e.currentTarget.getAttribute('data-attr-id')).offsetTop - 50);
        })
        $('body').on('click', '.scroll-up', function (e) {
            $(window).scrollTop(0);
        })
        function createGroupedArray(arr, chunkSize) {
            var groups = [], i;
            for (i = 0; i < arr.length; i += chunkSize) {
                groups.push({ categoryTopics: arr.slice(i, i + chunkSize) });
            }
            return groups;
        }
        TopicService.getTopics()
            .success(function (res) {
                //topicvm.topics = createGroupedArray(res, 3);
                topicvm.topics = res;
                $(window).scrollTop(0);
            });


        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});

        topicvm.selectTopic = function (topic) {

            topicvm.selectedTopic = topic;
            topicvm.svgPath = topic.visioFilePath;
            topicvm.diagramName = topic.diagramName;
            $rootScope.$emit('gotSelectedTopic', topic);
            $rootScope.$emit('gotVisioDetail', topic);
            SharedService.logLinkEvent('Topic', {
                name: topic.name,
                url: topic.type === 'Visio' ? location.protocol + "//" + location.host + topic.visioFilePath : topic.type === 'Link' ? topic.diagramName : location.protocol + "//" + location.host + location.pathname + '#/topics/' + encodeURIComponent(topic.name),
                referrer: window.location.hash.indexOf('ref') > 0 ? window.location.hash.substr(window.location.hash.indexOf('ref') + 4, window.location.hash.length) : 'sdmplus'
            })
        };

        var togglefav = $rootScope.$on('togglefav', function (e, isFavorite) {
            var data = [{
                id: topicvm.selectTopicObj.id,
                isFavorite: isFavorite,
                name: topicvm.selectTopicObj.name
            }];

            TopicService.updateFavourite(data).success(function (topic) {
                if (isFavorite) {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                }
                topicvm.topics.forEach(function (categroyObj) {
                    categroyObj.topic.forEach(function (topicObj) {
                        if (topicObj.name === topic[topic.length - 1].name) {
                            topicObj.isFavorite = topic[topic.length - 1].isFavorite;
                        }
                    })
                })
            });
        });
        var ratingOption = $rootScope.$on('ratingOption', function (e, topic) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingTopicCtrl',
                size: 'sm',
                resolve: {
                    selectedItem: function () {
                        return topic;
                    }
                }
            });

            modalInstance.result.then(function (selectedItem) {
                topic.title = selectedItem.name;
                topic.name = selectedItem.name;
                topic.comment = selectedItem.comment;
                topic.rating = selectedItem.rating;
            });


        });
        //$rootScope.$on('getSelectedTopicDetails', function (e, topicName, id, currentState) {
        //    var selectedTopicId, count = 0;
        //    console.log(currentState)
        //    topicvm.isOpened = false;
        //    topicvm.selectTopicObj = new Object();
        //    if (currentState === 'topicDetails') {
        //        topicvm.selectTopicObj = new Object();
        //        topicvm.topics.forEach(function (categoryObj) {
        //            categoryObj.isSelected = false;
        //            categoryObj.isSelected = false;
        //            categoryObj.isOpen = false;
        //            categoryObj.topic.forEach(function (topicObj) {
        //                topicObj.isSelected = false;
        //                if (topicObj.id === parseInt(id, 10) || topicObj.name === topicName) {
        //                    topicvm.selectTopicObj = topicObj;
        //                    console.log($state);
        //                    if (topicObj.type === 'Link') {
        //                        var url = topicObj.diagramName;
        //                        SharedService.openModal('Topic', topicName, url);
        //                        //SharedService.logLinkEvent('Topic', {
        //                        //    name: topicName,
        //                        //    url: url
        //                        //})
        //                    }
        //                    categoryObj.isSelected = true;
        //                    categoryObj.isOpen = true;
        //                    topicObj.isSelected = true;
        //                    $rootScope.$emit('gotVisioDetail', topicObj);
        //                    $(window).scrollTop(0);
        //                    SharedService.logLinkEvent('Topic', {
        //                        name: topicObj.name,
        //                        url: topicObj.type === 'Link' ? topicObj.diagramName : location.origin + topicObj.visioFilePath,
        //                        referrer: window.location.hash.indexOf('referrer') > 0 ? window.location.hash.substr(window.location.hash.indexOf('referrer') + 9, window.location.hash.length) : null,
        //                        ComplexityType: null
        //                    })
        //                }
        //            })
        //        })
        //        if (Object.keys(topicvm.selectTopicObj).length === 0 && $state.current.name === 'Topic Detail') {
        //            alerting.addAlert('danger', 'No Topic Found');
        //            $state.go('topics');
        //        }
        //    }

        //})
        //console.log($state)

        $rootScope.$on('getSelectedTopicDetails', function (e, topicName, id) {
            var selectedTopicId, count = 0;
            if (window.localStorage.getItem('currentUrl').search('#/topics') >= 0) {
                topicvm.selectTopicObj = new Object();
                topicvm.topics.forEach(function (categoryObj) {
                    categoryObj.isSelected = false;
                    categoryObj.isSelected = false;
                    categoryObj.isOpen = false;
                    categoryObj.topic.forEach(function (topicObj) {
                        topicObj.isSelected = false;
                        if (topicObj.id === parseInt(id, 10) || topicObj.name === topicName) {
                            topicvm.selectTopicObj = topicObj;
                            console.log($state);

                            if (topicObj.type === 'Link') {
                                var url = topicObj.diagramName;
                                SharedService.openModal('Topic', topicName, url);
                                //SharedService.logLinkEvent('Topic', {
                                //    name: topicName,
                                //    url: url
                                //})
                            }
                            categoryObj.isSelected = true;
                            categoryObj.isOpen = true;
                            topicObj.isSelected = true;
                            $rootScope.$emit('gotVisioDetail', topicObj);
                            $(window).scrollTop(0);
                            SharedService.logLinkEvent('Topic', {
                                name: topicObj.name,
                                url: topicObj.type === 'Link' ? topicObj.diagramName : location.origin + topicObj.visioFilePath,
                                referrer: window.location.hash.indexOf('ref') > 0 ? window.location.hash.substr(window.location.hash.indexOf('ref') + 4, window.location.hash.length) : 'sdmplus',
                                ComplexityType: null
                            })
                        }
                    })
                })
                if (Object.keys(topicvm.selectTopicObj).length === 0) {
                    $state.go('topics');
                }
            }

        })
        //console.log($state)

        $scope.$watch('topicvm.topics', function (oldVal, newVal) {

            var selectedTopicId, count = 0;
            if (topicvm.topics) {
                topicvm.isOpened = false;
                topicvm.selectTopicObj = new Object();
                topicvm.topics.forEach(function (categoryObj) {
                    categoryObj.isSelected = false;
                    categoryObj.isOpen = false;
                    categoryObj.topic.forEach(function (topicObj) {
                        topicObj.isSelected = false;
                        if (topicObj.id === parseInt($state.params.id, 10) || topicObj.name === $state.params.topicName) {
                            topicvm.selectTopicObj = topicObj;
                            console.log($state);
                            count += 1;
                            categoryObj.isSelected = true;
                            categoryObj.isOpen = true;
                            topicObj.isSelected = true;
                            if (topicObj.type === 'Link' && !topicvm.isOpened) {
                                var url = topicObj.diagramName;
                                topicvm.isOpened = true;
                                SharedService.openModal('Topic', $state.params.topicName, url);

                            }
                            SharedService.logLinkEvent('Topic', {
                                name: topicObj.name,
                                url: topicObj.type === 'Link' ? topicObj.diagramName : location.origin + topicObj.visioFilePath,
                                referrer: window.location.hash.indexOf('ref') > 0 ? window.location.hash.substr(window.location.hash.indexOf('ref') + 4, window.location.hash.length) : 'sdmplus',
                                ComplexityType: null
                            })
                            $(window).scrollTop(0);
                            $rootScope.$emit('gotVisioDetail', topicObj);
                        }
                    })
                    //if (Object.keys(topicvm.selectTopicObj).length === 0) {
                    //    $state.go('topics');
                    //}
                })
            }
        });
        var gotSearchResult = $rootScope.$on('gotSearchResult', function (e, topicName) {
            if (topicvm.selectedTopic && (topicvm.selectedTopic.name !== topicName)) {
                topicvm.selectedTopic = getSelectedTopic(topicvm.topics, topicName);
                topicvm.svgPath = topicvm.selectedTopic.visioFilePath;
            }
        });

        $scope.$on('$destroy', function () {
            // remove listener.
            gotSearchResult();
            togglefav();
            ratingOption();
        });

        $('.scroll-to').on('click', function (e) {
            console.log(e);
        })
        $scope.scrollTo = function (elem) {
            alert(elem);
        }
    }

    angular.module('sdmApp')
        .controller('TopicsCtrl', TopicsCtrl)
        .controller('RatingTopicCtrl', function ($scope, $location, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.title = selectedItem.name;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };

            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                ratingData.isSubmit = true;
                var data = {
                    itemTypeId: 10,
                    title: ratingData.name,
                    url: window.location.href,
                    version: null,
                    rating: ratingData.rating,
                    comment: ratingData.comment,
                    MethodName: localStorage.getItem('userMethodologyName') ? localStorage.getItem('userMethodologyName') : null

                };
                if (ratingData.rating == null) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    SharedService.logEvent('Rating', data);
                    $scope.cancel();
                    alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                }
            };


        });

})();
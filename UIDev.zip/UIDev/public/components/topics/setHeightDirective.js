﻿(function () {
    angular.module('sdmApp').directive('setHeightElement', function ($timeout) {
        return {
            restrict: 'EA',
            scope: {
                lastElement: '=',
                targetElement: '=',
                sourceElement: '='
            },
            link: function (scope, elem, attr) {
                $timeout(function () {
                    if (screen.width >=1920) {
                        //$('.category-list').find('li').find('.topic-nav-list').eq(0)
                        $('.masonry').css('height', '33%');
                    }
                    if (screen.width >= 1536 && screen.width<1920) {
                        //$('.category-list').find('li').find('.topic-nav-list').eq(0)
                        $('.masonry').css('height', '33%');
                    }
                    if (screen.width >= 1440 && screen.width < 1536) {
                        //$('.category-list').find('li').find('.topic-nav-list').eq(0)
                        $('.masonry').css('height', '25vw');
                    }
                }, 50);

            }
        }
    })
})();
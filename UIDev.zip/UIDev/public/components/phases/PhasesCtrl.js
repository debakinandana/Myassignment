﻿(function () {
    function PhasesCtrl($rootScope, $state, $stateParams, phases) {
        var phasesvm = this,
            filterArr = [],
            phaseName = $state.params.phaseName,
            subPhaseName = $state.params.subPhaseName;

        if (phases.data && phases.data.subPhases.length) {
            phasesvm.phases = phases.data.subPhases;
        }

        function filterPhase(filterArr, phaseName) {
            return filterArr.subPhases.filter(function (item) {
                return item.phaseName === phaseName;
            })[0];
        }

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});
        function getPhase() {
            var phase = null;

            if (phaseName) {
                phase = filterPhase(phases.data, phaseName);
            }
            
            if (subPhaseName) {
                phase = filterPhase(phase, subPhaseName);
            }

            phasesvm.phase = phase;
        }

        getPhase();

        $rootScope.$on('gotSubPhase', function (event, subPhase) {
            
            phasesvm.phase = subPhase;
        });

        $rootScope.$on('gotPhase', function (event, phase) {
            phasesvm.phase = phase;
        });

    }


    angular.module("sdmApp")
        .controller('PhasesCtrl', PhasesCtrl);
})();

﻿(function () {
    angular.module('sdmApp')
	.service('PhaseService', function ($http, URLS) {
	    this.getPhases = function (selectedMethodologyId) {
	        return $http.get(URLS.methodologyPhases + selectedMethodologyId+ '/phases');
	    };
	});
})();
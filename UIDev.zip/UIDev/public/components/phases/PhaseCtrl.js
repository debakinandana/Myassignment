﻿(function () {
    function PhaseCtrl($rootScope, subPhase) {
        var phasevm = this;
        console.log(subPhase);
        phasevm.name = 'Hemant Singh';

        $rootScope.$on('gotSubPhase', function(event, subPhase){
            console.log(subPhase);
        });
    }


    angular.module("sdmApp")
        .controller('PhaseCtrl', PhaseCtrl);
})();

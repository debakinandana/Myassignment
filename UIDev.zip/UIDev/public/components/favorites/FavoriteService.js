﻿(function () {
    angular.module('sdmApp')
    .service('FavoriteService', function ($http, URLS) {
        this.getFavorites = function (searchSortPaginateConfig) {
            var pageNumber = "?pageNumber=" + searchSortPaginateConfig.pageNumber,
                serachQuery = searchSortPaginateConfig.searchValue ? "&searchValue=" + searchSortPaginateConfig.searchValue : '',
                sort = searchSortPaginateConfig.sort ? "&sort=" + searchSortPaginateConfig.sort : '';
              return $http.get(URLS.favorites + pageNumber + "&pageSize=12" + serachQuery + sort);
        };

        this.updateFavourite = function (data) {
            return $http.patch(URLS.favorites, data);
        };

        this.getLanguages = function () {
            return $http.get(URLS.languages);
        };
        this.getActivityDescription = function (id) {
            return $http.get(URLS.GetDynamicActivityContent, { params: { activityIdentifier: id } });
        };
    });
})();
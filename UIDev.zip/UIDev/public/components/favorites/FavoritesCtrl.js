﻿(function () {
    function FavoritesCtrl($rootScope, $scope, $state, $location, $timeout, $ocLazyLoad, $uibModal, FavoriteService, TOAST_MESSAGE, alerting, SharedService,sdmSiteRefresh,$http) {
        var favvm = this;

        favvm.$state = $state;
        favvm.isListMode = true;
        //favvm.copyLink = 'Copy Link';
        favvm.selection = [];
        favvm.selectedCard = null;
        favvm.selectedSubTemplate = null;
        var subSelection = [];

        // pagination
        favvm.language = '';
        favvm.favorites = [];
        favvm.totalItems = 0;
        favvm.pageSize = 12;
        favvm.pagination = {
            current: $state.params.page
        };
        favvm.sortType = $state.params.sort;
        //favvm.searchFilter = {
        //    title: ''
        //};
        favvm.filterIds = [];
        $rootScope.$emit('updateUserView');  
        function getResultsPage() {
             return FavoriteService.getFavorites({ pageNumber: favvm.pagination.current, sort: favvm.sortType, filterIds: favvm.filterIds, language: favvm.language }).success(function (res) {
                         favvm.favorites = res.favorites;
                         favvm.totalItems = res.count;
                         favvm.selection = [];
                 favvm.selectedAll = false;

                 $scope.favorite.isComplexity = [];
                 for (var i = 0; i < favvm.favorites.length; i++) {

                     $scope.favorite.isComplexity.push(favvm.favorites[i].isComplexity)

                 }
                
                 

                     });
           
        }
        
            getResultsPage();
        
        favvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                favvm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        favvm.openPopup = function(title){
            window.open('https://microsoft.sharepoint.com/sites/campus/Pages/CampusSearch.aspx?k=' + title + '')
        }
        //favvm.searchTemplate = function (title) {
        //    favvm.searchFilter.title = title;
        //    getResultsPage();
        //};
        favvm.openModal = function (sItem) {
            var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            var mywindow = window.open(sItem.fileLocation, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            mywindow.focus();
            if (sItem.isExternal) {
                SharedService.logEvent('Activity', {
                    itemTypeId: 2,
                    title: sItem.title,
                    url: sItem.fileLocation,
                    version: sItem.version,
                    MethodName: sItem.solutionMethodName,
                    phaseName: sItem.phaseTitle,
                    complexityType: sItem.complexityName,
                    rating: null,
                    phaseId: sItem.phaseIds,
                    itemId: sItem.favouriteTypeDataId,
                    solutionMethodId: sItem.solutionMethodId,
                });
            }
            
            //if (!sItem.isExternal) {
            //    //$ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
            //    //FavoriteService.getActivityDescription(sItem.id).success(function (res) {
            //    //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
            //    //                    .then(function () {
            //    //                        var modalInstance = $uibModal.open({
            //    //                            templateUrl: 'components/activities/activityDescription.html',
            //    //                            controller: 'ReadMoreCtrl',
            //    //                            size: 'lg',
            //    //                            aria: 'Activity Content',
            //    //                            resolve: {
            //    //                                selectedItem: function () {
            //    //                                    return res;
            //    //                                }
            //    //                            }
            //    //                        });
            //    //                    });
            //    //});
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(sItem.fileLocation, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            //else {
            //    // SharedService.openModal(sItem.type, sItem.title, sItem.fileLocation);
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(sItem.fileLocation, sItem.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
        }
        favvm.sortBy = function (sortItem) {
            favvm.sortType = sortItem;
            getResultsPage();
            $state.go('.', { sort: sortItem }, { notify: false });
        };

        favvm.filterByLanguage = function (selectedLanguage) {
            favvm.language = selectedLanguage;
            getResultsPage();
        };


        favvm.dynamicPopover = {
            templateUrl: 'views/partials/preview-template.html',
            appendToBody: true
        };

        favvm.copyLinkFn = function (template) {
            template.copyLinkText = 'Copied!';
            $timeout(function () {
                delete template.copyLinkText;
            }, 1000);
        };

        favvm.getTopicUrl = function (topicName) {
            var absUrl = $location.absUrl().split('#')[0];
            return location.origin + '#topics/'+topic.id+'/'+topic.name+'?ref=sdmplus';
        };

        favvm.getVisioUrl = function (visioFilePath) {
            var text = ""; filePath = visioFilePath;
            var text = ""; filePath = visioFilePath.split('/');
            for (var i = 1; i < filePath.length; i++) {
                text += "%252F" + filePath[i];
            }
            return location.origin + location.pathname + "#/methodology/" + text;
           
        };

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});
        favvm.emailFeedBack = function (template) {
            var data = {
                itemTypeId: JSON.parse(ratingData.favouriteTypeId),
                title: template.title,
                url: JSON.parse(ratingData.favouriteTypeId) === 2 ? template.isExternal ? template.fileLocation : location.protocol + "//" + location.host + "/sdm/activityContent/activityDetail.html?id=" + template.id + "" : JSON.parse(ratingData.favouriteTypeId) ? location.protocol + "//" + location.host + '/sdm/Index#/methodology/' + text : template.diagramName,
                version: template.version,
                rating: localStorage.getItem('commentsStatus'),
                comment: localStorage.getItem('comment'),
                MethodName: ratingData.methodName,
                PhaseName: ratingData.phaseName,
                Domain: localStorage.getItem('userDomainName'),
                Methodology: localStorage.getItem('userMethodologyName'),
                ComplexityType: template.complexityName ? template.complexityName : null,
                phaseId: template.phaseId,
                itemId: template.id,
                solutionMethodId: template.solutionMethodId

            };
            SharedService.logEvent('Rating', data);
           // SharedService.logEvent('Rating', { methodId: JSON.parse(localStorage.getItem('userMethodologyId')), methodName: localStorage.getItem('userMethodologyName'), phaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'), emailType: 3, ContentRating: localStorage.getItem('commentsStatus'), feedback: localStorage.getItem('comment'), activityName: null, url: window.location.href });
        }
        favvm.checkAll = function (isSelectedAll, selectedTemplates) {
            favvm.selection = [];
            angular.forEach(selectedTemplates, function (template) {
                template.Selected = isSelectedAll;
                if (isSelectedAll) {
                    favvm.selection.push(template);
                }
            });
        };

        //favvm.checkAll = function () {
        //    angular.forEach(favvm.favorites, function (favorite) {
        //        favorite.Selected = favvm.selectedAll;
        //        if (favvm.selectedAll) {
        //            favvm.selection.push(favorite);
        //        } else {
        //            favvm.selection = [];
        //            return;
        //        }

        //    });
        //};
        favvm.toggleSingleSelection = function (template) {
            if (favvm.selection.indexOf(template) > -1) {
                favvm.selection.splice(template, 1);
            } else {
                favvm.selection.push(template);
            }
        };

        favvm.toggleFavourite = function (template) {
            template.isFavourite = !template.isFavourite;
            FavoriteService.updateFavourite([{
                favouriteTypeId: template.favouriteTypeId,
                favouriteTypeDataId: template.favouriteTypeDataId,
                title: template.title,
                isFavourite: template.isFavourite,
                complexityId: template.complexityId
            }])
                .success(function (res) {
                    if (!template.isFavourite) {
                        getResultsPage().success(function () {
                            //favvm.favorites.splice(favvm.favorites.indexOf(template), 1);
                            //favvm.totalItems -= 1;
                            alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                        });
                    }

                });
           
        };

        favvm.mailToFunctionality = function () {
            if (favvm.selection.length > 0) {
                var body_message = '',
                    win = '',
                    email = '',
                    subject = 'List of Favorites',
                    mailto_link, count = 1;

                for (var i = 0; i < favvm.selection.length; i++) {
                    var url;
                    if (!favvm.selection[i].inProgress) {
                        if (favvm.selection[i].fileLocation) {
                            if (favvm.selection[i].favouriteTypeId == 15) {
                                url = favvm.getVisioUrl(favvm.selection[i].fileLocation);
                            }
                            else {
                                url = favvm.selection[i].fileLocation;
                            }

                        } else if (favvm.selection[i].favouriteTypeId == 10) {
                            url = favvm.getTopicUrl(favvm.selection[i].title);
                        } else if (favvm.selection[i].favouriteTypeId == 11) {
                            url = favvm.getVisioUrl(favvm.selection[i].visioFilePath);
                        } else if (favvm.selection[i].favouriteTypeId == 15) {
                            url = favvm.getVisioUrl(favvm.selection[i].fileLocation);
                        }
                       
                        body_message = body_message + (count) + '. ' + encodeURIComponent(url) + '%0D%0A';
                        count++;
                    }
                    
                    

                  
                }

                mailto_link = 'mailto:' + email + '?subject=' + subject + '&body=' + body_message;

                win = window.open(mailto_link, 'emailWindow');
                if (win && win.open && !win.closed) {
                    $timeout(function () {
                        win.close()
                    }, 1000);
                    // win.close()
                };
            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_ITEM_SELECTED);
            }
        };

        function clearSubSelection(selectedIndex) {
            subSelection = [];
            favvm.subSelectAll = false;
            var property;

            if (favvm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else if (favvm.templateType === 'sample') {
                property = 'sampleTemplates';
            }
            else {
                property = "projectComplexityDetails";
            }
            angular.forEach(favvm.favorites[selectedIndex][property],
                function (subTemplate) {
                    subTemplate.Selected = false;
                });
        }


        favvm.toggleTemplates = function (template, tmplName, index, e, favorite) {
            // resetCollapsed(template.id, tmplName);
            if (favorite.isComplexity) {
                template.templateExpanded = !template.templateExpanded;
                template.isComplexitySelected = tmplName === 'projectComplexityDetails';
                favvm.selectedTemplateIndex = index;
                favvm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? 'projectComplexityDetails' : tmplName + 'Templates'];
                template.subtemplateslength = favvm.selectedSubTemplate.length;
                template[tmplName + 'Active'] = !template[tmplName + 'Active'];
                favvm.templateType = tmplName;
                favvm.sourceElem = e.currentTarget;
                clearSubSelection(favvm.selectedTemplateIndex);
                template.selectedFileType = template.favouriteTypeId
            }
        };

        $rootScope.$on('maskHidden', function () {
            if (favvm.selectedTemplateIndex !== undefined && favvm.selectedTemplateIndex !== null) {
                favvm.favorites[favvm.selectedTemplateIndex].templateExpanded = false;
                favvm.favorites[favvm.selectedTemplateIndex].sampleActive = false;
                favvm.favorites[favvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
                clearSubSelection(favvm.selectedTemplateIndex);
                angular.element(favvm.sourceElem).focus();
            }
        });
        favvm.showCardDetailSection = function (e, template, appvm) {

            if (e.keyCode === 27) {
                favvm.favorites[favvm.selectedTemplateIndex].templateExpanded = false;
                favvm.favorites[favvm.selectedTemplateIndex].sampleActive = false;
                favvm.favorites[favvm.selectedTemplateIndex].localizedActive = false;
                favvm.favorites[favvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
                appvm.screenMask = !appvm.screenMask;
                clearSubSelection(favvm.selectedTemplateIndex);
                template.selectedFileType = template.favouriteTypeId
            }
        }

        favvm.toggleTemplates = function (template, tmplName, index, e) {
            // resetCollapsed(template.id, tmplName);
            template.templateExpanded = !template.templateExpanded;
            favvm.selectedTemplateIndex = index;
            template.isComplexitySelected = tmplName === 'projectComplexityDetails';
            favvm.selectedSubTemplate = template[tmplName === "projectComplexityDetails" ? tmplName : tmplName + 'Templates'];
            template.subtemplateslength = favvm.selectedSubTemplate.length;
            template[tmplName + 'Active'] = !template[tmplName + 'Active'];
            favvm.templateType = tmplName;
            favvm.sourceElem = e.currentTarget;
            clearSubSelection(favvm.selectedTemplateIndex);
            template.selectedFileType = template.favouriteTypeId

        };

        $rootScope.$on('maskHidden', function () {
            if (favvm.selectedTemplateIndex !== undefined && favvm.selectedTemplateIndex !== null) {
                favvm.favorites[favvm.selectedTemplateIndex].templateExpanded = false;
                favvm.favorites[favvm.selectedTemplateIndex].sampleActive = false;
                favvm.favorites[favvm.selectedTemplateIndex].localizedActive = false;
                favvm.favorites[favvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
                clearSubSelection(favvm.selectedTemplateIndex);
            }
        });

        favvm.openReadMore = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js'])
                .then(function () {
                    var modalInstance = $uibModal.open({
                        templateUrl: 'components/common/modals/read-more.html',
                        controller: 'ReadMoreCtrl',
                        aria: 'read more',
                        resolve: {
                            selectedItem: function () {
                                return template;
                            }
                        }
                    });
                });
        };
        favvm.openRating = function (favorite) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                aria: 'rating',
                size: 'sm',
                resolve: {
                    selectedItem: function () {
                        return favorite;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                favorite.title = selectedItem.title;
                favorite.fileLocation = selectedItem.fileLocation;
                favorite.version = selectedItem.version;
                favorite.comment = selectedItem.comment;
                favorite.rating = selectedItem.rating;

            });
        };
    }
    angular.module('sdmApp')
		.controller('FavoritesCtrl', FavoritesCtrl)
        .controller('ReadMoreCtrl', function ($scope, $uibModalInstance, selectedItem) {
            selectedItem.title = selectedItem.title;
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('RatingCtrl', function ($scope, $location, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem,$state) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.title = selectedItem.title;
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };

            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                var url;
                $scope.getTopicUrl = function (topicName) {
                    var absUrl = $location.absUrl().split('#')[0];
                    return absUrl + $state.href('topics.detail', { topicName: topicName });
                };
                if ($scope.originalData.favouriteTypeId == 10 || $scope.originalData.favouriteTypeId == 11) {
                    url = $location.host() + $scope.originalData.visioFilePath;
                }

                else {
                    url = $scope.originalData.fileLocation;
                }
                var data = {
                    itemTypeId: $scope.originalData.favouriteTypeId,
                    title: $scope.originalData.title,
                    url: url,
                    version: $scope.originalData.version,
                    rating: ratingData.rating,
                    comment: ratingData.comment
                };
                if (ratingData.rating == null) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    var favUrl=null;
                    if (ratingData.favouriteTypeId) {
                        if (JSON.parse(ratingData.favouriteTypeId) === 15 || JSON.parse(ratingData.favouriteTypeId) === 11) {
                            var text = ""; filePath = ratingData.fileLocation ? ratingData.fileLocation.split('/') ? ratingData.fileLocation.split('/') : "" : ratingData.visioFilePath.split('/') ? ratingData.visioFilePath.split('/'):"";
                            for (var i = 1; i < filePath.length; i++) {
                                text += "%252F" + filePath[i];
                            }
                            favUrl=location.protocol + "//" + location.host + '/sdm/Index#/methodology/' + text;
                        }
                    }
                    else {
                        favUrl= window.location.href;
                    }
                    
                    var data = {
                        itemTypeId: JSON.parse(ratingData.favouriteTypeId),
                        title: ratingData.title,
                        url: JSON.parse(ratingData.favouriteTypeId) === 2 ? ratingData.fileLocation : JSON.parse(ratingData.favouriteTypeId) === 15 || JSON.parse(ratingData.favouriteTypeId) === 11 ? favUrl : JSON.parse(ratingData.favouriteTypeId) === 10 ? $scope.getTopicUrl(ratingData.diagramName) : ratingData.fileLocation,
                        version: ratingData.version,
                        rating: ratingData.rating,
                        comment: ratingData.comment,
                        MethodName: ratingData.solutionMethodName,
                        PhaseName: JSON.parse(ratingData.favouriteTypeId) === 2 || JSON.parse(ratingData.favouriteTypeId) === 15 || JSON.parse(ratingData.favouriteTypeId) === 11 ? ratingData.phaseTitle ? ratingData.phaseName : null : null,
                        ComplexityType: ratingData.complexityName ? ratingData.complexityName : null,
                        phaseId: ratingData.phaseId,
                        itemId: ratingData.id,
                        solutionMethodId: ratingData.solutionMethodId
                    };
                    if (ratingData.solutionMethodId > 0 && JSON.parse(ratingData.favouriteTypeId) === 2 || JSON.parse(ratingData.favouriteTypeId) === 15 || JSON.parse(ratingData.favouriteTypeId) === 11) {
                        SharedService.logEvent('Rating', data);
                        SharedService.sendUserFeedback({ methodId: ratingData.solutionMethodId, methodName: ratingData.solutionMethodName, phaseName: ratingData.phaseTitle, phaseId: ratingData.phaseIds ? ratingData.phaseIds : 0, emailType: JSON.parse(ratingData.favouriteTypeId) === 2 ? 3 : JSON.parse(ratingData.favouriteTypeId) === 11 ? 2 : 1, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: JSON.parse(ratingData.favouriteTypeId) === 2 ? ratingData.title : null, activityId: ratingData.id, url: !ratingData.isExternal ? JSON.parse(ratingData.favouriteTypeId) === 2 ? ratingData.fileLocation : JSON.parse(ratingData.favouriteTypeId) === 11 || JSON.parse(ratingData.favouriteTypeId) === 15 ? favUrl : ratingData.fileLocation : ratingData.fileLocation }).success(function (res) {
                            if (res.status) {
                                alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                            }
                            else {
                                alerting.alert('danger', res.errorMessage)
                            }
                            $scope.cancel();
                        })
                       
                    }


                    else {
                        SharedService.logEvent('Rating', data);
                        alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                        $scope.cancel();
                    }

                }

            };


        });

})();
﻿(function () {
    var fileTypeComponent = {
        bindings: {
            fileType: '@',
            hideTitle:'@'
        },
        templateUrl: 'components/common/filetype/file-type.html',
        controller: function () {
            this.getFileType = function (type,hideTitle) {
                type = type.toLowerCase();
                console.log(this.hideTitle)
                switch (type) {
                    case 'docx':
                        this.fileExtension = 'Word Document';
                        break;
                    case 'DOCX':
                        this.fileExtension = 'Word Document';
                        break;
                    case 'dotx':
                        this.fileExtension = 'Word Document';
                        break;
                    case 'pptx':
                        this.fileExtension = 'PowerPoint Presentation';
                        break;
                    case 'potx':
                        this.fileExtension = 'PowerPoint Presentation';
                        break;
                    case 'xlsx':
                        this.fileExtension = 'MS exceel Sheet';
                        break;
                    case 'xlsm':
                        this.fileExtension = 'MS exceel Sheet';
                        break;
                    case 'pdf':
                        this.fileExtension = 'PDF Document';
                        break;
                    case 'zip':
                        this.fileExtension = 'zip file';
                        break;
                    case 'aspx':
                        this.fileExtension = 'aspx file';
                        break;
                    case 'aspx':
                        this.fileExtension = 'aspx file';
                        break;
                    case 'mpp':
                        this.fileExtension = 'mpp file';
                        break;
                    case 'sharepoint':
                        this.fileExtension = 'sharepoint file';
                        break;
                    case 'topic':
                        this.fileExtension = 'topic file';
                        break;
                    case 'svg':
                        this.fileExtension = 'svg file';
                        break;
                    case 'htm':
                        this.fileExtension = 'htm file';
                        break;
                    case 'vsd':
                        this.fileExtension = 'vsd file';
                        break;
                    case 'visio':
                        this.fileExtension = 'visio file';
                        break;
                    case 'msg':
                        this.fileExtension = 'out look file';
                        break;
                    default:
                        this.fileExtension = 'aspx file';
                        break;
                }
                if (/(word|docx?|docx|dotx)$/.test(type)) {
                    return 'word-icon';
                } else if (/(pptx?|pptx|potx)$/.test(type)) {
                    return 'ppt-icon';
                }
                else if (/(xlsx?|xlsx|xlsm)$/.test(type)) {
                    return 'xls-icon';
                }
                else if (/(method?|method|method)$/.test(type)) {
                    return 'method-icon';
                }
                else if (/(msg)$/.test(type)) {
                    return 'msg-icon';
                }
                else if (/(pdf|zip|aspx|mpp|sharepoint|topic|svg|htm|vsd|visio|msg)$/.test(type)) {
                    return type + '-icon';
                } else {
                    return 'default-icon';
                }
            };
        }
    };

    angular
      .module('sdmApp')
      .component('fileTypeComponent', fileTypeComponent);
})();
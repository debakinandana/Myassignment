﻿angular.module('sdmApp')
	.service('FileTypeService', function () {
	    this.setFileType = function (fileType) {
	        switch (fileType) {
	            case 'docx':
	            case 'doc':
	            case 'DOCX':
	            case 'dotx':
	                {
	                    return 'word-icon';
	                }
	            case 'pdf':
	                {
	                    return 'pdf-icon';
	                }
	            case 'pptx':
	            case 'ppt':
	            case 'potx':
	                {
	                    return 'ppt-icon';
	                }
	            case 'xlsx':
	            case 'XLSX':
	            case 'xls':
	            case 'xlsm':
	                {
	                    return 'xls-icon';
	                }
	            case 'zip':
	                {
	                    return 'zip-icon';
	                }
	            case 'aspx':
	                {
	                    return 'aspx-icon';
	                }
	            case 'mpp':
	                {
	                    return 'mpp-icon';
	                }
	            case 'vsd':
	                {
	                    return 'visio-icon';
	                }
	            case 'sharepoint':
	                {
	                    return 'sharepoint-icon';
	                }
	            case 'topic':
	                {
	                    return 'icon-topic';
	                }

	        }

	    };
	});
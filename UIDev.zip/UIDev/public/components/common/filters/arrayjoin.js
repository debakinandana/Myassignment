﻿(function () {
    angular.module('sdmApp')
    .filter('arrayjoin', function () {
        return function (inputArr) {
            if (inputArr) {
                return inputArr.map(function (elem) {
                    return elem.roleAbbr;
                }).join(", ")
            }
        };
    });
})();
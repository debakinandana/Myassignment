﻿(function () {
    angular.module('sdmApp')
    .filter('trustAsHTML', ['$sce', function ($sce) {
        return function (text) {
            return $sce.trustAsHtml(text);
        };
    }]);
})();
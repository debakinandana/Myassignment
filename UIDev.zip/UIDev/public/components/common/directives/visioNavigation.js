﻿(function () {
    angular.module('sdmApp')
        .directive('visio', function ($window, $rootScope, $timeout, $state, $stateParams, $ocLazyLoad, $uibModal, SharedService, VisioDetailService, MethodologyService, UserService) {
            return {
                scope: {
                    visioactivities: '=',
                    haveActivity: '=?'
                },
                controller: function ($scope) {
                    var gotRole = $rootScope.$on('roleFilterChanged', function (event, roleIds, complexityId) {
                        $rootScope.roleIds = roleIds;
                        $rootScope.complexityId = complexityId;
                        MethodologyService.getVisioaAtivities(roleIds.length ? roleIds : [], complexityId ? complexityId : 0, $stateParams.selectedMethodologyVisio)
                            .success(function (res) {
                                $scope.complexityActivities = res;
                                $scope.visioactivities = roleIds.length ? res : [];
                            });



                    });

                    $scope.$on('$destroy', function () {
                        // remove listener.
                        gotRole();
                    });
                },

                link: function (scope, el, attr) {
                    el[0].addEventListener('load', function () {
                        var svgDoc = el[0].contentDocument,
                            svgElm = svgDoc.documentElement,
                            svgRatio = (svgElm.getBoundingClientRect().height / svgElm.getBoundingClientRect().width) * 100 + "%";
                        if ($(svgDoc).find('[activityID]').length) {
                            $timeout(function () {
                                scope.haveActivity = true;
                            }, 0);
                        }
                        $timeout(function () {

                            el.parent('.embed-responsive').css('padding-bottom', svgRatio);
                        }, 0);
                        $(svgDoc).find('a[xlink\\:href$=".svg"]').on('click', function (e) {
                            e.preventDefault();
                            var url = $(this).attr('xlink:href');

                            el.attr('data', url);

                            console.log("Visio URL1 " + url);
                            $state.go('methodology', { selectedMethodologyVisio: encodeURIComponent(url) });
                        });

                        $(svgDoc).find('a[xlink\\:href]').not('a[xlink\\:href$=".svg"]').on('click', function (e) {
                            e.preventDefault();

                            var url = $(this).attr('xlink:href');
                            var id = $(this).attr('activityID');
                            var url = $(this).attr('xlink:href');
                            var activityID = $(this).attr('activityID');
                            var isTemplate = $(this).attr('templateID') ? true : false;
                            var exp = new RegExp("^(https?://)?(www\\.)?([-a-z0-9]{1,63}\\.)*?[a-z0-9][-a-z0-9]{0,61}[a-z0-9]\\.[a-z]{2,6}(/[-\\w@\\+\\.~#\\?&/=%]*)?$", "i");
                            console.log("Visio URL " + url);
                            //if (isTemplate) {
                            //    if (/\.(pptx?|docx|xls(x|m)?|zip|mpp|pdf|vsd|aspx|net|co|com)$/.test(url)) {
                            //        //window.location.assign(url);
                            //        var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
                            //        var mywindow = window.open(url, "", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
                            //        mywindow.focus();
                            //        SharedService.trackView('Template', 'Visio Page', url);
                            //    }
                            //}
                            //else {
                            //    openActivityModal(activityID, e);
                            //}
                            if (/\.(pptx?|docx|xls(x|m)?|zip|mpp|pdf|vsd|aspx|net|co|com)$/.test(url) || exp.test(url)) {
                                var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
                                var mywindow = window.open(url, "", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
                                mywindow.focus();

                                var tempObj = $rootScope.complexityIdList.filter(function (complexityObj) {
                                    return complexityObj.id === $rootScope.complexityId;
                                })
                                SharedService.trackTemplateView(isTemplate ? 'Template' : 'Activity', isTemplate ? $(this).attr('templatename') : $(this).find('title').text(), url, tempObj.length ? tempObj[tempObj.length - 1].name : 'Type 1 [High]', $(this).attr('version') ? $(this).attr('version') : null, $(this).attr('phasename') ? $(this).attr('phasename') : null, null, $(this).attr('templateID') ? $(this).attr('templateID') : $(this).attr('activityID'), $(this).attr('templateID') ? true : false, $(this).attr('templateID')?window.location.href:null,'sdmplus');
                            }
                            //window.location.assign(url);o
                            //if (/\.(pptx?|docx|xls(x|m)?|zip|mpp|pdf|vsd|aspx|net|co|com)$/.test(url) || exp.test(url))
                            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
                            //    var mywindow = window.open(url, "", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
                            //    mywindow.focus();
                            //    SharedService.trackView('Template', 'Visio Page', url);
                            //}
                            else {
                                if (activityID) {
                                    openActivityModal(activityID, e);
                                    //SharedService.trackView('Activity', 'Visio Activity', url, $rootScope.complexityId);
                                }

                            }
                        });

                        function openActivityModal(activityPageId, event) {
                            //$ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
                            //VisioDetailService.getActivityDescription(activityPageId).success(function (res) {
                            //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
                            //                    .then(function () {
                            //                        var modalInstance = $uibModal.open({
                            //                            templateUrl: 'components/activities/activityDescription.html',
                            //                            controller: function ($scope, $uibModalInstance, selectedItem) {
                            //                                $scope.selectedTemplate = selectedItem;

                            //                                $scope.cancel = function () {
                            //                                    $uibModalInstance.dismiss('cancel');
                            //                                };
                            //                            },
                            //                            size: 'lg',
                            //                            aria: 'Activity Content',
                            //                            resolve: {
                            //                                selectedItem: function () {
                            //                                    return res;
                            //                                }
                            //                            }
                            //                        });
                            //                    });
                            //});
                            var complexityId = 3;
                            if ($(event.currentTarget).hasClass('viso-activity')) {
                                complexityId = $rootScope.complexityId ? $rootScope.complexityId : 3;
                            }
                            else {
                                complexityId = 3;
                            }
                            var urlLoc = window.location.href;
                            var urlNmae = urlLoc.split('#')[1]
                            var urlPathName = urlNmae.split('/')[1];
                            var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
                            var mywindow = window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + activityPageId + '&complexityType=' + complexityId + '&urlPathName=' + urlPathName + '&ref=sdmplus', "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
                            mywindow.focus();
                        };
                        //function updateRoleLocation() {
                        //    var roleIndicatorId=null,roleIndicatorList=[],roleInicatorObj,status;
                        //    scope.visioactivities && scope.visioactivities.map(function (item, i) {
                        //        var $sbgElm = $(svgDoc).find('[activityID="' + item.activityId + '"]');

                        //        if ($sbgElm.length) {
                        //            //var rawElm = $sbgElm[0].getBoundingClientRect();
                        //            //item.x = rawElm.left + rawElm.width / 2 - 24;
                        //            //item.y = rawElm.top + 168;
                        //            for (var j = 0; j < $sbgElm.length; j++) {
                        //                var rawElm = $sbgElm[j].getBoundingClientRect();
                        //                item.x = rawElm.left + rawElm.width / 2 - 24;
                        //                item.y = rawElm.top + 168;
                        //            }
                        //        }
                        //    })
                        //}
                        //}
                        function updateRoleLocation() {
                            var roleIndicatorList = [], updatedActivties;
                            $(svgDoc).find('a').find('path').removeAttr('style');
                            scope.visioactivities && scope.visioactivities.map(function (item, i) {
                                var $sbgElm = $(svgDoc).find('[activityID="' + item.activityId + '"]'), indicatorId;
                                indicatorId = 'roleIndicator_' + item.activityId;
                                if ($sbgElm.length) {
                                    for (var j = 0; j < $sbgElm.length; j++) {
                                        var rawElm = $sbgElm[j].getBoundingClientRect();
                                        var elemWidth = rawElm.width > 50 ? Math.round(Math.round(rawElm.width) / 2) > 50 ? rawElm.left + 50 : rawElm.left + 30 : rawElm.left;
                                        roleIndicatorList.push({
                                            x: elemWidth,
                                            y: rawElm.top + 168,
                                            id: indicatorId,
                                            roleObj: item
                                        });



                                    }
                                    item.id = indicatorId;
                                    item.roleIndicatorList = roleIndicatorList;
                                }

                            })

                        }
                        function upateComplexActivities() {
                            $(svgDoc).find('a').find('path').removeAttr('style');
                            $(svgDoc).find('a').find('rect').removeAttr('style')
                            $(svgDoc).find('a').removeClass('viso-activity')
                            var $sbgElm;
                            scope.complexityActivities && scope.complexityActivities.map(function (item, i) {
                                if (item['activityId']) {
                                    $sbgElm = $(svgDoc).find('[activityID="' + item.activityId + '"]')
                                }
                                else if (item['templateId']) {
                                    $sbgElm = $(svgDoc).find('[templateID="' + item.templateId + '"]')
                                    $sbgElm.attr('templatename', item.templateName).attr('xlink:href', item.inProgress ? 'javascript:void(0);' : item.templateUrl).attr('version', item.version).attr('phasename',item.phaseName);
                                   
                                }
                                for (var j = 0; j < $sbgElm.length; j++) {
                                    if (item.showComplexityIndicator) {
                                        var elem = $($sbgElm[j]).find('path'), elem1 = $($sbgElm[j]).find('rect');
                                        //$($sbgElm[j]).find('path').attr('style', 'stroke:#ffff00;stroke-width: 2.18px');
                                        if (elem.length) {
                                            $(elem).attr('style', 'stroke:#ffff00;stroke-width: 2.18px');
                                        }
                                        else if (elem1.length) {
                                            $(elem1).attr('style', 'stroke:#ffff00;stroke-width: 2.18px');
                                        }
                                        $($sbgElm[j]).addClass('viso-activity')
                                    }

                                }
                            });


                        }
                        scope.$watchCollection('visioactivities', function (newValue, oldValue) {
                            updateRoleLocation();
                        });
                        scope.$watchCollection('complexityActivities', function (newValue, oldValue) {
                            upateComplexActivities();
                        });
                        // svg resize 
                        angular.element($window).on('resize', function () {
                            scope.$apply(function () {
                                updateRoleLocation();
                            });
                        });
                    }, false);
                }
            };
        });
})();
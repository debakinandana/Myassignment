﻿(function () {
    angular.module('sdmApp')
        .directive('print', function ($document) {

            function link(scope, element, attrs) {
                element.on('click', function () {
                    window.print();
                });
            }

            return {
                link: link,
                restrict: 'A'
            };
        });

})();
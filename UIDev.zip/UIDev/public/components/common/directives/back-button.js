﻿(function () {
    angular.module('sdmApp')
        .directive('backButton', ["$window", function ($document) {
            return {
                restrict: "A",
                link: function (scope, elem, attrs) {
                    elem.bind("click", function () {
                        $window.history.back();
                    });
                }
            };
        }]);
})();

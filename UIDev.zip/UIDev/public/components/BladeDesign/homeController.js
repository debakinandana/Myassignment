(function () {

    function HomeController() {
        var exportvm = this;
       
    }
    angular.module('sdmApp').controller('HomeController', HomeController);
})();
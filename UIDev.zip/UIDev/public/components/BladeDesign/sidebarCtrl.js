(function () {

    function sidebarController() {
        var exportvm = this;
        $(function () {
            $('.toggle-sidebar').click(function () {
                toggleSideBar();
            });
        });

        $('[data-toggle=offcanvas]').click(function () {
            $('.row-offcanvas').toggleClass('active');
            //$('#sidebar').toggleClass('col-xs-1');
            $('.collapse').toggleClass('in');
        });

        function toggleSideBar() {

            if ($('#sidebar-wrapper').hasClass('show-sidebar')) {
                // Do things on Nav Close
                $('#sidebar-wrapper').removeClass('show-sidebar');
            } else {
                // Do things on Nav Open
                $('#sidebar-wrapper').addClass('show-sidebar');
            }
            //$('#site-wrapper').toggleClass('show-nav');
        }
    }
    angular.module('sdmApp').controller('sidebarController', sidebarController);
})();
(function () {
    function ExportMethodService($http, URLS) {

        this.getMethods = function (data) {
            //return $http.get(URLS.adminExcelMethods);
            return $http.get(URLS.getMethodologies);
        };
        this.downloadMethods = function () {
            return $http.get(URLS.downloadMethodologies);
        };
        this.getComplexities = function () {
            return $http.get(URLS.adminComplexity);
        };
        //this.downloadMethods = function (solutionMethodId) {
        //    //var inData = { param: data, param1: methodId };
        //    return $http.get(URLS.download + '?solutionMethodId=' + solutionMethodId, {
        //        withCredentials: true,
        //        headers: {
        //            'Content-Type': undefined,
        //            //'accept': 'application/json;odata=verbose',
        //            //'Access-Control-Allow-Methods': GET, POST, PUT, DELETE, patch,OPTIONS, HEAD,

        //        },
        //        transformRequest: angular.identity,

        //    }) 
        //};

    }

    angular.module('sdmApp')
        .service('ExportMethodService', ExportMethodService);
})();
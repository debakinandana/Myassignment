(function () {
    function ExportMethodCtrl($rootScope, $scope, ExportMethodService, $state, URLS, $ocLazyLoad, $uibModal, alerting, TOAST_MESSAGE, $sce, SharedService, $location, $http) {
        var mutliDropDownList = [{ listName: 'methods', selectedValue: 0, fieldValue: 'methods', modelObj: 'solutionMethodId' }];
        var exportvm = this;
        exportvm.methodObj = [];
        exportvm.$state = $state;
        exportvm.complexityId = true;

        console.log($state)

        ExportMethodService.getMethods().success(function (res) {
            if (res) {
                exportvm.methods = res.solutionMethods;
            }
        });

        SharedService.getComplexities().success(function (res) {
            if (res) {
                exportvm.complexityList = res;
            }
        });
       
        exportvm.changeSelected = function (SelectedType) {


            if (SelectedType && SelectedType === 'summary') {
                exportvm.complexityId = true;
                exportvm.formSubmitted = false;
                exportvm.methodObj.complexityId = "";
                $state.reload();

            }
            else if (SelectedType && SelectedType === 'details') {
                exportvm.complexityId = false;
                exportvm.formSubmitted = false;

            }

        }

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});

        exportvm.downloadMethods = function (solutionMethodId, complexityId) {

            exportvm.formSubmitted = true;
            $http.get(location.origin + '/api/CheckSiteRefreshing').success(function (response) {

                if (response.siteRefresh) {
                    alerting.addAlert('danger', 'We are making some content updates and the site is being refreshed. Please try again after 5 minutes');
                }


                else {
                    if (exportvm.methodObj.solutionMethodId.length > 0 && $scope.isDetails && exportvm.methodObj.complexityId != undefined) {
                        //exportvm.formSubmitted = true;

                        window.open(URLS.downloadMethodologies + encodeURI('?solutionMethodId=' + exportvm.methodObj.solutionMethodId + '&complexityId=' + exportvm.methodObj.complexityId + '&checkedValue=details'));

                    }



                    if (exportvm.methodObj.solutionMethodId.length > 0 && !$scope.isDetails) {

                        window.open(URLS.downloadMethodologies + encodeURI('?solutionMethodId=' + exportvm.methodObj.solutionMethodId + ''));

                    }

                }
            })
           
        }







    }

    angular.module('sdmApp').controller('ExportMethodCtrl', ExportMethodCtrl);


})();

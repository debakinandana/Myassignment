﻿(function () {
    function ActivityDetailCtrl($timeout, $stateParams, $ocLazyLoad, $uibModal, ActivityDetailService, FavoriteService, TOAST_MESSAGE, alerting, SharedService, $rootScope,$scope, sdmSiteRefresh, $http) {
        var activityDetailvm = this;

        ActivityDetailService.getActivity($stateParams.id)
            .success(function (res) {
                console.log(res);
                activityDetailvm.activityDetail = res;

                //$scope.activityDetailvm.isComplexity = [];
                //for (var i = 0; i < activityDetailvm.activityDetail.length; i++) {
                //    $scope.activityDetailvm.isComplexity.push(activityDetailvm.activityDetail[i].isComplexity)

                //}
                //if (res.isComplexity == true) {
                //    activityDetailvm.hideComplexity = false;
                //}
                //else {
                //    activityDetailvm.hideComplexity = true;
                //}

            });
        activityDetailvm.emailFeedBack = function (template) {
            var data = {
                itemTypeId: 2,
                title: template.title,
                url: template.isExternal ? template.fileLocation : location.protocol + "//" + location.host + "/sdm/activityContent/activityDetail.html?id=" + template.id + "&complexityId=0",
                version: template.version,
                rating: localStorage.getItem('commentsStatus'),
                comment: localStorage.getItem('comment'),
                MethodName: localStorage.getItem('userMethodologyName') === "null" ? null : localStorage.getItem('userMethodologyName'),
                PhaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'),
                Domain: localStorage.getItem('userDomainName'),
                Methodology: localStorage.getItem('userMethodologyName'),
                complexityType: template.complexityName,
                phaseId: template.phaseIds,
                itemId: template.id,
                solutionMethodId: template.solutionMethodId
            };
            SharedService.logEvent('Rating', data);
        }
        activityDetailvm.toggleFavourite = function (activity) {
            activity.isFavourite = !activity.isFavourite;
            var data = [{
                id: activity.id,
                isFavourite: activity.isFavourite,
                title: activity.title,
                complexityId: activity.complexityId
            }];
            // FavoriteService.updateFavourite([{
            //     "favouriteId": 0,
            //     "displayValue": activity.title,
            //     "favouriteTypeId": 2,
            //     "favouriteTypeDataId": activity.id,
            //     "isFavourite": activity.isFavourite
            // }]);
            // ActivityDetailService.updateActivity(activity.id, {
            //     isFavourite: activity.isFavourite
            //});
            ActivityDetailService.updateFavourite(data).success(function (res) {
                if (activity.isFavourite) {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                }
            });

        };
        $rootScope.$on('maskHidden', function () {
            //if (templateDetailvm.selectedTemplateIndex !== undefined && templateDetailvm.selectedTemplateIndex !== null) {
            activityDetailvm.templateExpanded = false;

            //activityDetailvm.searchResults[activityDetailvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
            angular.element(activityDetailvm.sourceElem).focus();
            //}
        });
        activityDetailvm.toggleTemplates = function (template, tmplName, index, event, appvm) {
            // resetCollapsed(template.id, tmplName);
            activityDetailvm.templateExpanded = !activityDetailvm.templateExpanded;
            activityDetailvm.selectedTemplateIndex = index;
            activityDetailvm.isComplexitySelected = tmplName === 'projectComplexityDetails';
            activityDetailvm.selectedTemplateIndex = index;
            activityDetailvm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? tmplName : tmplName + 'Templates'];
            template.subtemplateslength = activityDetailvm.selectedSubTemplate.length;
            template[tmplName + 'Active'] = !template[tmplName + 'Active'];
            activityDetailvm.templateType = tmplName;
            activityDetailvm.sourceElem = event.currentTarget;

        };
        activityDetailvm.openActivityModal = function (template) {
            //if (!template.isExternal) {
            //    //$ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
            //    //ActivityDetailService.getActivityDescription(template.id).success(function (res) {
            //    //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
            //    //                    .then(function () {
            //    //                        var modalInstance = $uibModal.open({
            //    //                            templateUrl: 'components/activities/activityDescription.html',
            //    //                            controller: 'ActivityDescriptionDetailCtrl',
            //    //                            size: 'lg',
            //    //                            aria: 'Activity Content',
            //    //                            resolve: {
            //    //                                selectedItem: function () {
            //    //                                    return res;
            //    //                                }
            //    //                            }
            //    //                        });
            //    //                    });
            //    //});
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + template.id + '&complexityId=0', "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            //else {
            //   // SharedService.openModal(template.type, template.title, template.fileLocation);
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(template.fileLocation, template.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            if (template.isExternal) {
                SharedService.logEvent('Activity', {
                    itemTypeId: 2,
                    title: template.title,
                    url: template.fileLocation,
                    version: template.version,
                    MethodName: template.solutionMethodName,
                    PhaseName: template.phaseTitle,
                    ComplexityType: template.complexityName,
                    rating: null,
                    phaseId: template.phaseIds,
                    itemId: template.id,
                    solutionMethodId: template.solutionMethodId,
                    complexityType: template.complexityName
                });
            }
            var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            var mywindow = window.open(template.fileLocation, template.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            mywindow.focus();
        };
        activityDetailvm.openReadmore = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/read-more.html',
                controller: 'ReadMoreCtrl',
                aria: 'Read More',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
        }
        activityDetailvm.openRating = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                size: 'sm',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                template.title = selectedItem.title;
                template.fileLocation = selectedItem.fileLocation;
                template.version = null;
                template.comment = selectedItem.comment;
                template.rating = selectedItem.rating;

            });
        };

        // copy to clipboard
        activityDetailvm.copyLinkFn = function (activity) {
            activity.copyLink = 'Copied!';
            $timeout(function () {
                delete activity.copyLink;
            }, 1000);
        };

        //activityDetailvm.setFileType = function (fileType) {
        //    return FileTypeService.setFileType(fileType);
        //};
    }

    angular.module('sdmApp')
    .controller('ActivityDetailCtrl', ActivityDetailCtrl)
        .controller('ActivityDescriptionDetailCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        }).controller('ReadMoreCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        }).controller('RatingCtrl', function ($scope, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.title = selectedItem.title;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };

            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                ratingData.isSubmit = true;
                var data = {
                    itemTypeId: 2,
                    title: $scope.originalData.title,
                    url: $scope.originalData.fileLocation,
                    version: null,
                    rating: ratingData.rating,
                    comment: ratingData.comment
                };
                if (ratingData.rating == null) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    var data = {
                        itemTypeId: 2,
                        title: ratingData.title,
                        url: ratingData.fileLocation,
                        version: ratingData.version,
                        rating: ratingData.rating,
                        comment: ratingData.comment,
                        MethodName: ratingData.solutionMethodName,
                        PhaseName: ratingData.phaseName,
                        ComplexityType: ratingData.complexityName,
                        phaseId: ratingData.phaseId,
                        solutionMethodId: ratingData.solutionMethodId,
                        itemId: ratingData.id

                    };
                    SharedService.logEvent('Rating', data);
                    if (ratingData.solutionMethodId > 0) {
                        SharedService.sendUserFeedback({ methodId: ratingData.solutionMethodId, methodName: ratingData.solutionMethodName, phaseName: ratingData.phaseTitle, phaseId: ratingData.phaseIds, emailType: 3, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: ratingData.title, activityId: ratingData.id, url: ratingData.fileLocation }).success(function (res) {
                            if (res.status) {
                                alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);

                            }
                            else {
                                alerting.alert('danger', res.errorMessage)
                            }
                            $scope.cancel();
                        })

                    }
                    else {
                        alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                        $scope.cancel();
                    }
                }
            };
        });

})();
﻿(function () {
    angular.module('sdmApp')
	.service('ActivityDetailService', function ($http, URLS) {
	    this.getActivity = function (id) {
	        return $http.get(URLS.activities + "?id=" + id);
	    };

	    this.updateActivity = function (id, data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.post(URLS.activities + id, data, config);
	    };
	    this.updateFavourite = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.patch(URLS.activities, data, config);
	    };
	    this.updateRating = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.patch(URLS.activities, data, config);
	    };
	    this.getActivityDescription = function (id) {
	        return $http.get(URLS.GetDynamicActivityContent, { params: { activityIdentifier: id } });
	    };
	});
})();
﻿(function (sdmApp) {
    var requestUrlList = [];
    var addToken = function () {

        return {
            request: function (config) {
                var csrfToken = angular.element("input[name='__RequestVerificationToken']").val();
                console.log(csrfToken)
                config.headers['__RequestVerificationToken'] = csrfToken || "Hemanatta";
                config.headers['requestUrl'] = window.location.href;
                return config;
            }
        };
    };
    var addRequestUrl = function () {
        return {
            request: function (config) {
                config.headers['requestUri'] = window.location.href;
            }
        };
    }
    sdmApp
        .factory("addToken", addToken).service("addOperationId", ['$q', '$injector', '$window', 'TOAST_MESSAGE', '$rootScope', function ($q, $injector, $window, TOAST_MESSAGE, $rootScope) {
            var operationId = null , j = 0;/* SharedService = SharedService || $injector.get('SharedService')*/  /*SharedService = SharedService || $injector.get('SharedService')*/;
            return {
                request: function (config) {
                    if (config.url.search('.html') < 0 && config.url.search('.js') < 0 && config.url.search('.css') < 0 && config.url.search('.json') < 0 && config.url.search('/api/CheckSiteRefreshing') < 0) {
                        if (requestUrlList.length !== 0) {
                            operationId = null;
                            for (var i = 0; i < requestUrlList.length; i++) {
                                if (requestUrlList[i].url === config.url) {
                                    operationId = requestUrlList[i].operation;
                                    j = i;
                                }
                            }
                            if (operationId === null) {
                                var crypto = window.crypto || window.msCrypto;
                                operationId = crypto.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 8) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + crypto.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 19);
                                requestUrlList.push({ url: config.url, operation: operationId });
                                operationId = operationId;
                            }
                        }
                        else {
                            var crypto = window.crypto || window.msCrypto;
                            operationId = crypto.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 8) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + Math.floor(1000 + crypto.getRandomValues(new Uint32Array(1))[0] * 9000) + '-' + crypto.getRandomValues(new Uint32Array(1))[0].toString(36).substr(2, 19);
                            requestUrlList.push({ url: config.url, operation: operationId });
                        }
                        console.log(config.url, operationId);
                        config.headers.correlationId = operationId;
                        $rootScope.$emit('Service Corelation', { correlationId: operationId, requestUrl: config.url, title: document.title });
                    }
                   
                  return config;
                }
            }

        }]).factory('errorHttpInterceptor', ['$q', '$injector', '$window', 'TOAST_MESSAGE','$rootScope', function ($q, $injector, $window, TOAST_MESSAGE,$rootScope) {
            return {
                
                responseError: function responseError(rejection) {
                   
                    var isRejected = rejection.status === -1,
                        errMsg = null;

                    if (isRejected) {
                        errMsg = TOAST_MESSAGE.AUTH_REQUIRED
                        $window.location.href = '/';
                    } else if (rejection.data !== "site is refreshing aborting all api requests") {
                        errMsg = TOAST_MESSAGE.HTTP_ERROR
                    }

                    var alerting = $injector.get('alerting');
                    if (rejection.data === "Invalid Data" ) {
                        window.location.href = location.protocol+'//'+location.hostname+'/sdm/Error?message=InvalidModel';
                    }
                    if (errMsg) {
                        alerting.addDanger(errMsg);
                    }
                    
                    return $q.reject(rejection);   
                },
                reponse: function response(res, status, header, config) {
                    window.localStorage.setItem('key', angular.element("input[name='__RequestVerificationToken']").val());
                    console.log(res, 'res')
                    return response;
                }
            };
        }]).config(['$httpProvider', '$provide',  function ($httpProvider, $provide, $q) {
            //$provide.decorator('$exceptionHandler', function ($delegate, $injector) {
            //    return function (exception, cause) {
            //        $delegate(exception, cause);
            //        var alerting = $injector.get('alerting');
            //        alerting.addDanger(exception.message);
            //    };
            //});
            $httpProvider.interceptors.push('addOperationId');
            $httpProvider.interceptors.push('errorHttpInterceptor');
            $httpProvider.interceptors.push("addToken");
            
          
        }]).run(['$http', function ($http) {
            //$http.defaults.headers.common['Authorization'] = 'Basic d2VudHdvcnRobWFuOkNoYW5nZV9tZQ==';
            //$http.defaults.headers.common['Accept'] = 'application/json;odata=verbose';
              $http.defaults.headers.common.redirectUri = window.location.href
        }]);

}(angular.module('sdmApp')));
﻿(function () {
    angular.module('sdmApp')
	.service('TemplateDetailService', function ($http, URLS, $q) {
	    this.getTemplate = function (id) {
	        //return $http.get(URLS.templateDetail + id + '.json');
	        return $http.get(URLS.templates + id);
	    };

	    this.updateTemplate = function (data) {
	        //return $http.patch(URLS.templateDetail + id + '.json', data);
	        return $http.post(URLS.favorites, data);
	    };

	    this.updateFavourite = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.patch(URLS.templates, data, config);
	    };
	    this.updateRating = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.patch(URLS.templates, data, config);
	    };
	});
})();
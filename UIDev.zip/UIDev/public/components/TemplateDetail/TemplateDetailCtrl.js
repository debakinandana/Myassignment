﻿(function () {
    function TemplateDetailCtrl($rootScope, $timeout, $stateParams, $state, $ocLazyLoad, $uibModal, TemplateDetailService, alerting, TOAST_MESSAGE, sdmSiteRefresh) {
        var templateDetailvm = this;

        TemplateDetailService.getTemplate($stateParams.id)
            .success(function (res) {
                templateDetailvm.templateDetail = res;
            });

        templateDetailvm.toggleFavourite = function (template) {
            templateDetailvm.templateDetail.isFavourite = !templateDetailvm.templateDetail.isFavourite;
            var data = [{
                id: template.id,
                isFavourite: template.isFavourite,
                title: template.title,
                complexityId: template.complexityId
            }];

            //data.push({
            //    'favouriteId': 0,
            //    'displayValue': template.title,
            //    'favouriteTypeId': 1,
            //    'favouriteTypeDataId': template.id,
            //    'isFavourite': template.isFavourite
            //});
            TemplateDetailService.updateFavourite(data).success(function (res) {
                if (templateDetailvm.templateDetail.isFavourite) {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                }

            });
            
        };

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});

        templateDetailvm.showCardDetailSection = function (e, template, appvm) {

            if (e.keyCode === 27) {
                template.templateExpanded = !template.templateExpanded;
                appvm.screenMask = !appvm.screenMask;
                template.localizedActive = false;
                template.sampleActive = false;
            }
        }
        templateDetailvm.openPopup = function(title){
            window.open('https://microsoft.sharepoint.com/sites/campus/Pages/CampusSearch.aspx?k=' + title + '')
        }
        templateDetailvm.toggleTemplates = function (template, tmplName, index, event, appvm) {
            // resetCollapsed(template.id, tmplName);
            template.templateExpanded = !template.templateExpanded;
            templateDetailvm.selectedTemplateIndex = index;
            templateDetailvm.isComplexitySelected = tmplName === 'projectComplexityDetails';
            templateDetailvm.selectedTemplateIndex = index;
            templateDetailvm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? tmplName : tmplName + 'Templates'];
            template.subtemplateslength = templateDetailvm.selectedSubTemplate.length;
            template[tmplName + 'Active'] = !template[tmplName + 'Active'];
            templateDetailvm.templateType = tmplName;
            templateDetailvm.sourceElem = event.currentTarget;
            
        };

        $rootScope.$on('maskHidden', function () {
            //if (templateDetailvm.selectedTemplateIndex !== undefined && templateDetailvm.selectedTemplateIndex !== null) {
                templateDetailvm.templateDetail.templateExpanded = false;
                templateDetailvm.templateDetail.sampleActive = false;
                templateDetailvm.templateDetail.localizedActive = false;
                templateDetailvm.searchResults[templateDetailvm.selectedTemplateIndex].projectComplexityActive = false;
                angular.element(templateDetailvm.sourceElem).focus();
            //}
        });

        templateDetailvm.dynamicPopover = {
            templateUrl: 'views/partials/preview-template.html',
            appendToBody: true
        };

        // copy to clipboard
        templateDetailvm.copyLinkFn = function (template) {
            template.copyLinkText = 'Copied!';
            $timeout(function () {
                delete template.copyLinkText;
            }, 1000);
        };
       

        //templateDetailvm.setFileType = function (fileType) {
        //    return FileTypeService.setFileType(fileType);
        //};

        templateDetailvm.goBack = function () {
            $state.go('templates.grid', { page: $state.current }, { reloadOnSearch: false })
            
        }
        templateDetailvm.openRating = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                aria:'rating',
                size: 'sm',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                template.title = selectedItem.title;
                template.fileLocation = selectedItem.fileLocation;
                template.version = selectedItem.version;
                template.comment = selectedItem.comment;
                template.rating = selectedItem.rating;

            });
        };
    }


    angular.module('sdmApp')
    .controller('TemplateDetailCtrl', TemplateDetailCtrl)
    .controller('RatingCtrl', function ($scope, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem) {
        $scope.ratingData = angular.copy(selectedItem);
        $scope.originalData = selectedItem;
        $scope.title = selectedItem.title;
        $scope.placeholder = "Tell us why? (optional)";
        $scope.ratingYes = function (e) {
            $scope.ratingData.rating = true;
            $scope.placeholder = "Tell us why? (optional)";
        };

        $scope.ratingNo = function (e) {
            $scope.ratingData.rating = false;
            $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.trackRating = function (ratingData, event) {
            ratingData.isSubmit = true;
            var data = {
                itemTypeId: 1,
                title: $scope.originalData.title,
                url: $scope.originalData.fileLocation,
                version: $scope.originalData.version,
                rating: ratingData.rating,
                comment: ratingData.comment,
                complexityType: ratingData.complexityName,
                itemId: ratingData.id,
                phaseName: ratingData.phaseName,
                phaseId: ratingData.phaseIds.length ? ratingData.phaseIds[0] : null,
                solutionMethodId: null
            };
            if (ratingData.rating == null) {
                alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
            } else {
                SharedService.trackRatingView('Rating', data);
                $scope.cancel();
                alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
            }
        };


    });

})();
﻿(function () {
    angular.module('sdmApp')
        .service('adminSampleTemplateService', function ($http, URLS) {
            this.getSampleTemplates = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminSampleTemplates + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminSampleTemplates + '?pageNumber=1&pageSize=10');
                }

            };
            this.addSampleTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminSampleTemplates, data, config);
            };
            this.getSampleTemplate = function (data) {
                return (data) ? $http.get(URLS.adminSampleTemplates + '/' + data) : $http.get(URLS.adminSampleTemplates + '/' + data);
            };
            this.editSampleTemplates = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminSampleTemplates, data, config);
            };
            this.deleteSampleTemplates = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminSampleTemplates + '/' + itemId, config);
            };
        });
})();
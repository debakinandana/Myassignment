﻿(function () {
    function adminSampleTemplateCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminSampleTemplateService, alerting, TOAST_MESSAGE, $scope, $http, URLS) {
        var adminSampleTemplatevm = this;
        adminSampleTemplatevm.$state = $state;
        adminSampleTemplatevm.solutionMethod = [];
        adminSampleTemplatevm.totalItems = 0;
        adminSampleTemplatevm.pageSize = 10;
        adminSampleTemplatevm.pagination = {
            current: $state.params.page
        };
        adminSampleTemplatevm.searchFilter = {
            title: ''
        };

        function getResultsPage() {
            adminSampleTemplateService.getSampleTemplates({ pageNumber: adminSampleTemplatevm.pagination.current, searchValue: encodeURIComponent(adminSampleTemplatevm.searchFilter.title) }).success(function (res) {
               
                adminSampleTemplatevm.sampleTemplates = res.sampleTemplates;
                adminSampleTemplatevm.totalItems = res.count;
                adminSampleTemplatevm.parentTemplates = res.parentTemplates;
            });
            //$http.get(URLS.countries).success(function (response) {
            //    adminSampleTemplatevm.countries = response;

            //})
            //$http.get(URLS.languages).success(function (response) {
            //    adminSampleTemplatevm.languages = response;
            //})
        }
        function phaseFilter(arrayList, key, sourceObj) {
            result = null;
            arrayList.some(function (value, index) {
                
                if (value.id === sourceObj.parentTemplateId) {
                    result = value;
                    adminSampleTemplatevm.result = result;
                }
                else {
                    adminSampleTemplatevm.result = null;
                    result = null;
                }
                return value.id === sourceObj.parentTemplateId?value:null;
            })

        }
       
            getResultsPage();
      
       

        $rootScope.$on('updatedResults', function (e, data) {
            adminSampleTemplatevm.solutionMethod = data;
        });

        adminSampleTemplatevm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminSampleTemplatevm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminSampleTemplatevm.searchMethod = function (title) {
            adminSampleTemplatevm.searchFilter.title = title;
            getResultsPage();
        };

        adminSampleTemplatevm.DeleteConfirm = function (method) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteSampleTemplateCtrl',
                resolve: {
                    selectedItem: function () {
                        return method;
                    }
                }
            });
        };

        adminSampleTemplatevm.submitForm = function () {
            adminSampleTemplatevm.formSubmitted = true;
            if ($scope.templateForm.$valid) {
                if ($state.current.name === "AdminMain.administration.manageSampleTemplates.editSampleTemplate") {
                    adminSampleTemplateService.editSampleTemplates(adminSampleTemplatevm.templateObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.manageSampleTemplates.editSampleTemplate") {
                                alerting.addAlert('success', TOAST_MESSAGE.SAMTEMP_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.SAMTEMP_ADDED);
                            }
                            $state.go('AdminMain.administration.manageSampleTemplates', {}, { reload: true });
                        }
                    });
                }
                else {
                    adminSampleTemplateService.addSampleTemplate(adminSampleTemplatevm.templateObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.manageSampleTemplates.editSampleTemplate") {
                                alerting.addAlert('success', TOAST_MESSAGE.SAMTEMP_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.SAMTEMP_ADDED);
                            }
                            $state.go('AdminMain.administration.manageSampleTemplates', {}, { reload: true });
                        }
                    });
                }
          
                
            }
        }


        function getMethodDetails(methodId) {
            adminSampleTemplateService.getSampleTemplate(methodId).success(function (res) {
                if (res) {
                   // adminSampleTemplatevm.templateObj = {};
                    adminSampleTemplatevm.templateObj = res.sampleTemplates[0];
                    adminSampleTemplatevm.parentTemplates = res.parentTemplates;
                    
                }
            })
        }

        if ($state.current.name === "AdminMain.administration.manageSampleTemplates.editSampleTemplate") {

            getMethodDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
		.controller('adminSampleTemplateCtrl', adminSampleTemplateCtrl)
    .controller('deleteSampleTemplateCtrl', function ($rootScope, $scope, $uibModalInstance, adminSampleTemplateService, alerting, TOAST_MESSAGE, selectedItem, $state) {
        $scope.getResultsPage = function () {
            adminSampleTemplateService.getSampleTemplate().success(function (res) {
                $scope.sampleTemplates = res.sampleTemplates;
            });
        }

        $scope.selectedMethod = selectedItem;
        $scope.title = selectedItem.title;
        $scope.deleteItem = function (selectedItem) {

            adminSampleTemplateService.deleteSampleTemplates($scope.selectedMethod.id).success(function (res) {
                if (res) {
                    alerting.addAlert('success', TOAST_MESSAGE.SAMTEMP_DELETED);
                    $rootScope.$emit("updatedResults", res.solutionMethod);
                    $state.go('AdminMain.administration.manageSampleTemplates', {}, { reload: true });
                }
            });
            $scope.cancel();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })
})();
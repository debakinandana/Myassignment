﻿(function () {
    angular.module('sdmApp')
        .service('adminPhasesService', function ($http, URLS) {
            this.getPhases = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminPhases + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminPhases + '?pageNumber=1&pageSize=10');
                }

            };
            this.addPhase = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminPhases, data, config);
            };
            this.getPhase = function (data) {
                return $http.get(URLS.adminPhases + '/' + data);
            };
            this.editPhase = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminPhases, data, config);
            };
            this.deletePhase = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                //return $http.delete(URLS.adminPhases + '/' + itemId);
                return $http.delete(URLS.adminPhases + '/' + itemId, config);
                //return $http.delete(URLS.adminPhases + '/' + itemId);
            };
        });
})();
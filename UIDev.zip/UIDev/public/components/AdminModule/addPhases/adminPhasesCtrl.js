﻿(function () {
    function adminPhaseCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminPhasesService, alerting, TOAST_MESSAGE, $scope) {
        var adminPhasevm = this;
        adminPhasevm.$state = $state;
        adminPhasevm.phases = [];
        adminPhasevm.totalItems = 0;
        adminPhasevm.pageSize = 10;
        adminPhasevm.pagination = {
            current: $state.params.page
        };
        adminPhasevm.searchFilter = {
            title: ''
        };
        //function phaseFilter(arrayList, key, sourceObj) {
        //    result = null;
        //    arrayList.some(function (value,index) {
        //        console.log(value,index)
        //        result = value.isSelected === true ? value : null;
        //        if (value.isSelected) {
        //            adminPhasevm.result = result;
        //        }
        //        else {
        //            adminPhasevm.result = null;
        //        }
        //        return value.isSelected === true;
        //    })
            
        //}
        console.log(tinymce);
        adminPhasevm.tinymceOptions = {
            selector: "textarea",
            menubar: false,
            statusbar: false,
            content_css: 'components/common/commoncss/tinymce.css',
            plugins: ['advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools', 'codesample'],
            toolbar: 'undo redo | insert | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image | code | codesample | forecolor | backcolor',
            custom_undo_redo_levels: 10,
            browser_spellcheck: true,
            textcolor_rows: "4",
            table_default_attributes: {
                'border': 1, 'width': 300, 'height': 100, 'cellspacing': 0
            },
            contextmenu: 'inserttable | cell row column deletetable',
            extended_valid_elements: ['script[src|type|language]', 'img[class|src|alt|title]', 'div[rel|class|id]'],
            codesample_languages: [
        { text: 'HTML/XML', value: 'markup' },
        { text: 'JavaScript', value: 'javascript' }
            ]
        };
        function getResultsPage() {
            adminPhasesService.getPhases({ pageNumber: adminPhasevm.pagination.current, searchValue: encodeURIComponent(adminPhasevm.searchFilter.title) }).success(function (res) {
                adminPhasevm.phases = res.phases;
                //adminPhasevm.parentPhase = res.parentPhase;
                adminPhasevm.totalItems = res.count;
                adminPhasevm.solutionMethods = res.solutionMethods;
            });
        }
        getResultsPage();

        $rootScope.$on('updatedResults', function (e, data) {
            adminPhasevm.phases = data;
        });

        adminPhasevm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminPhasevm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminPhasevm.searchPhase = function (title) {
            adminPhasevm.searchFilter.title = title;
            getResultsPage();
        };

        adminPhasevm.DeleteConfirm = function (phase) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deletePhaseCtrl',
                resolve: {
                    selectedItem: function () {
                        phase.name = phase.displayValue;
                        return phase;
                    }
                }
            });
        };



        adminPhasevm.submitForm = function () {
            adminPhasevm.formSubmitted = true;

            if ($scope.phaseForm.$valid) {
                //adminPhasevm.phaseObj['parentId'] = adminPhasevm.phaseObj['parentId'] === undefined || !adminPhasevm.phaseObj['parentId'] ? -2 : adminPhasevm.phaseObj['parentId'];
                //adminPhasevm.phaseObj['solutionMethodId'] = adminPhasevm.phaseObj['solutionMethodId'] === undefined || !adminPhasevm.phaseObj['solutionMethodId']  ? -2 : adminPhasevm.phaseObj['solutionMethodId'];
                if ($state.current.name === "AdminMain.administration.managePhases.editPhase") {
                    adminPhasesService.editPhase(adminPhasevm.phaseObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.managePhases.editPhase") {
                                alerting.addAlert('success', TOAST_MESSAGE.PHASE_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.PHASE_ADDED);
                            }
                            $state.go('AdminMain.administration.managePhases', {}, { reload: true })
                        }
                        else {
                            if (response.errorMsg)
                                alerting.addAlert('danger', response.errorMsg);
                        }
                    })
                }
                else if ($state.current.name === "AdminMain.administration.managePhases.addPhase") {
                    adminPhasesService.addPhase(adminPhasevm.phaseObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.managePhases.editPhase") {
                                alerting.addAlert('success', TOAST_MESSAGE.PHASE_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.PHASE_ADDED);
                            }
                            $state.go('AdminMain.administration.managePhases', {}, { reload: true })
                        }
                        else {
                            if (response.errorMsg)
                                alerting.addAlert('danger', response.errorMsg);
                        }
                    })
                }

            }
        }
        function getPhaseDetails(phaseId) {
            adminPhasesService.getPhase(phaseId).success(function (res) {
                if (res) {
                    if (res.phases.length) {
                        adminPhasevm.phaseObj = res.phases[0];
                        adminPhasevm.solutionMethods = res.solutionMethods;
                        //phaseFilter(res.parentPhase, 'parentId', adminPhasevm.phaseObj);
                        //adminPhasevm.phaseObj.parentId = adminPhasevm.result ? adminPhasevm.result.id : "";
                        //phaseFilter(res.solutionMethods, 'solutionMethodId', adminPhasevm.phaseObj);
                        //adminPhasevm.phaseObj.solutionMethodId = adminPhasevm.result ? adminPhasevm.result.id : "";
                    }
                    
                    
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.managePhases.editPhase") {

            getPhaseDetails($state.params.id)
        }
    }
    angular.module('sdmApp').
        controller('adminPhasesCtrl', adminPhaseCtrl)
        .controller('deletePhaseCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminPhasesService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.getResultsPage = function () {
                adminPhasesService.getPhases().success(function (res) {
                    $scope.phases = res.phases;
                });
            }

            $scope.selectedPhase = selectedItem;
            $scope.title = selectedItem.name;
            $scope.deleteItem = function (selectedItem) {

                adminPhasesService.deletePhase($scope.selectedPhase.id).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.PHASE_DELETED);
                        $rootScope.$emit("updatedResults", res.phases);
                        $state.go('AdminMain.administration.managePhases', {}, { reload: true });
                    }
                    else {
                        alerting.addAlert('danger', res.errorMsg);
                    }
                });
                $scope.cancel();
            }
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        });
})();
﻿(function () {
    angular.module('sdmApp')
        .service('adminMethodService', function ($http, URLS) {
            this.getMethods = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminMethods + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminMethods + '?pageNumber=1&pageSize=10');
                }

            };
            this.addMethod = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminMethods, data, config);
            };
            this.getMethod = function (data) {
                return (data) ? $http.get(URLS.adminMethods +'/'+ data) : $http.get(URLS.adminMethods+'/'+ data);
            };
            this.editMethod = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminMethods, data, config);
            };
            this.deleteMethod = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminMethods + '/' + itemId, config);
            };
        });
})();
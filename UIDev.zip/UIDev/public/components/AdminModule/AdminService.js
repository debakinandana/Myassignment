﻿(function () {
    angular.module('sdmApp')
        .service('adminService', function ($http, URLS) {

            this.syncImages = function () {
                return $http.get(URLS.adminSyncImages)
            }
        });
})();
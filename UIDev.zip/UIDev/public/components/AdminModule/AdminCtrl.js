﻿(function () {
    function AdminCtrl($rootScope, $state, $stateParams, $ocLazyLoad, adminService, alerting, TOAST_MESSAGE) {
        var adminvm = this;
        adminvm.$state = $state;
         $rootScope.$emit('updateUserView');  
        adminvm.syncImages = function () {
            adminService.syncImages().success(function (res) {
                if (res.status) {
                    alerting.addAlert('success', TOAST_MESSAGE.SYNC_STATUS);
                }
                else {
                    alerting.addAlert('danger', res.errMsg);
                }
            })
        }
    }
    angular.module('sdmApp')
		.controller('AdminCtrl', AdminCtrl)
})();
﻿(function () {
    angular.module('sdmApp')
        .service('adminRoleService', function ($http, URLS) {
            this.getRoles = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminRoles + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminRoles + '?pageNumber=1&pageSize=10');
                }

            };
            this.addRole = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminRoles, data, config);
            };
            this.getRole = function (data) {
                return $http.get(URLS.adminRoles+'/'+data);
            };
            this.editRole = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminRoles, data, config);
            };
            this.deleteRole = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminRoles +'/'+ itemId, config);
            };
        });
})();
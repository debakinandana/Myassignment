﻿(function () {
    function adminRoleCtrl($rootScope, $scope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminRoleService, alerting, TOAST_MESSAGE) {
        var adminRolevm = this;
        adminRolevm.$state = $state;
        adminRolevm.adminRoles = [];
        adminRolevm.totalItems = 0;
        adminRolevm.pageSize = 10;
        adminRolevm.pagination = {
            current: $state.params.page
        };
        adminRolevm.searchFilter = {
            title: ''
        };

        function getResultsPage() {
            adminRoleService.getRoles({ pageNumber: adminRolevm.pagination.current, searchValue: encodeURIComponent(adminRolevm.searchFilter.title) }).success(function (res) {
                adminRolevm.adminRoles = res.adminRoles;
                adminRolevm.totalItems = res.count;
            });
        }
        getResultsPage();

        $rootScope.$on('updatedResults', function (e, data) {
            adminRolevm.adminRoles = data;
        });

        adminRolevm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminRolevm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminRolevm.searchRole = function (title) {
            adminRolevm.searchFilter.title = title;
            getResultsPage();
        };
        adminRolevm.submitForm = function () {
            adminRolevm.formSubmitted = true;
            if ($scope.roleForm.$valid) {
                adminRoleService.addRole(adminRolevm.roleObj).success(function (response) {
                    if (response.status) {
                        if ($state.current.name === "AdminMain.administration.manageRoles.editRole") {
                            alerting.addAlert('success', TOAST_MESSAGE.ROLE_UPDATED);
                        }
                        else {
                            alerting.addAlert('success', TOAST_MESSAGE.ROLE_ADDED);
                        }
                        $state.go('AdminMain.administration.manageRoles', {}, { reload: true });
                    }
                })
            }
        }
        adminRolevm.DeleteConfirm = function (role) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteRoleCtrl',
                resolve: {
                    selectedItem: function () {
                        return role;
                    }
                }
            });
        };

        function getRoleDetails(RoleId) {
            adminRoleService.getRole(RoleId).success(function (res) {
                if (res) {
                    adminRolevm.roleObj = res.adminRoles[0];
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.manageRoles.editRole") {

            getRoleDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
		.controller('adminRoleCtrl', adminRoleCtrl)
    .controller('deleteRoleCtrl', function ($rootScope,$state, $scope, $uibModalInstance, adminRoleService, alerting, TOAST_MESSAGE, selectedItem) {

        $scope.getResultsPage = function () {
            adminRoleService.getRoles().success(function (res) {
                $scope.roles = res.adminRoles;
            });
        }
        $scope.selectedRole = selectedItem;
        $scope.title = selectedItem.name;
        $scope.deleteItem = function (selectedItem) {
            adminRoleService.deleteRole($scope.selectedRole.id).success(function (res) {
                if(res.status){
                alerting.addAlert('success', TOAST_MESSAGE.ROLE_DELETED);
                $rootScope.$emit("updatedResults", res.adminRoles);
                $state.go('AdminMain.administration.manageRoles', {}, { reload: true });
                }
                else {
                    alerting.addAlert('danger', res.errorMsg);
                }
            });
            $scope.cancel();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })



})();
﻿(function () {
    angular.module('sdmApp')
        .service('manageTopicCategoryService', function ($http, URLS) {
            this.getTopicCategoryList = function (data) {
                return $http.get(URLS.adminTopicCategory);
            }
            this.addCategory = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminTopicCategory,data, config);
            }
            this.deleteCategory = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminTopicCategory + '/'+itemId, config);
            }
        });
})();
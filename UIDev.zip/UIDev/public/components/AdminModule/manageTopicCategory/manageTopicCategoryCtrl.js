﻿(function () {
    function manageTopicCategoryCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, manageTopicCategoryService, alerting, TOAST_MESSAGE, $scope) {
        var manageTopicCategoryvm = this;
        manageTopicCategoryvm.$state = $state;
        manageTopicCategoryvm.gridListObj = {};
        manageTopicCategoryvm.gridListObj.categoryList = [];
        function getResultPage() {
            manageTopicCategoryService.getTopicCategoryList().success(function (response) {
                if (response) {
                    manageTopicCategoryvm.gridListObj.categoryList = response.adminTopicsCategory ? response.adminTopicsCategory:[]
                }
            })
        }
        getResultPage();
        manageTopicCategoryvm.deleteCategory = function (categoryObj,index) {
            if (categoryObj.id) {
                $ocLazyLoad.load('components/common/commoncss/modal.css');
                var modalInstance = $uibModal.open({
                    templateUrl: 'components/common/modals/delete-confirmation.html',
                    controller: 'deleteCategoryCtrl',
                    resolve: {
                        selectedItem: function () {
                            return categoryObj;
                        }
                    }
                });
            }
            else {
                manageTopicCategoryvm.gridListObj.categoryList.splice(index, 1);
            }
            
        }
        $rootScope.$on('updatedResults', function (e,data) {
            manageTopicCategoryvm.gridListObj.categoryList = data ? data:[];
        })
        manageTopicCategoryvm.addNewCategory = function () {
            manageTopicCategoryvm.gridListObj.categoryList.push(new Object({ name: null, uId:0}));
        }
        function checkDuplicateInObject(propertyName, inputArray) {
            var seenDuplicate = false,
                testObject = {},
                sampleObject = null;
            inputArray.map(function (item) {
                var itemPropertyName = item[propertyName];
                if (itemPropertyName !== undefined && itemPropertyName in testObject) {
                    console.log(itemPropertyName)
                    testObject[itemPropertyName].duplicate = true;
                    item.isSequenceDuplicate = true;
                    seenDuplicate = true;
                   
                }
                else {
                    testObject[itemPropertyName] = item;
                    item.isSequenceDuplicate = false;
                    delete item.duplicate;
                }
            });

            return sampleObject;
        }

       
        manageTopicCategoryvm.checkSequenceExists = function (sequnceNumber) {
            checkDuplicateInObject('sequence', manageTopicCategoryvm.gridListObj.categoryList);
            
        }
        manageTopicCategoryvm.addCategory = function () {
            manageTopicCategoryvm.formSubmitted = true;
            checkDuplicateInObject('sequence', manageTopicCategoryvm.gridListObj.categoryList);
            if ($scope.gridForm.$valid ) {
                manageTopicCategoryService.addCategory(manageTopicCategoryvm.gridListObj.categoryList).success(function (response) {
                    if (response.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.CATEGORY_ADDED);
                        $state.go('AdminMain.administration');
                    }
                    else {
                        manageTopicCategoryvm.gridListObj.categoryList = response.adminTopicsCategory;
                        if (response.errorMsg) {
                            alerting.addAlert('danger', response.errorMsg);
                            
                        }
                        
                       
                    }
                })
            }
            else {
                if (!manageTopicCategoryvm.gridListObj.categoryList.length) {
                    alerting.addAlert('danger', TOAST_MESSAGE.CATEGORY_ERROR);
                }
            }
          
        }
    }
    function deleteCategoryCtrl($rootScope,$scope, $uibModalInstance, $ocLazyLoad, $uibModal, selectedItem, manageTopicCategoryService,TOAST_MESSAGE,alerting) {
        //$scope.whatsNewObj = selectedItem;
        
        $scope.selectedItem = selectedItem;
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        }
        $scope.deleteItem = function (selectedItem) {
            manageTopicCategoryService.deleteCategory(selectedItem.id).success(function (response) {
                $uibModalInstance.dismiss('cancel');
                if (response.status) {
                    alerting.addAlert('success', TOAST_MESSAGE.CATEGORY_DELETE);
                   $rootScope.$emit("updatedResults", response.adminTopicsCategory);
                }
                else {
                    alerting.addAlert('danger', response.errorMsg);
                }
                
            })
        }
    }
    angular.module('sdmApp').controller('deleteCategoryCtrl', deleteCategoryCtrl).controller('manageTopicCategoryCtrl', manageTopicCategoryCtrl);
})();
﻿(function () {
    function manageFileUploadCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, manageFileUploadService, alerting, TOAST_MESSAGE, $scope, URLS, $http) {
        var manageFileUploadsvm = this;
        manageFileUploadsvm.$state = $state;
        manageFileUploadsvm.fileChoosen = false;
        manageFileUploadsvm.fileSelected = null;
        manageFileUploadsvm.gridObj = {};
        var fd;
        manageFileUploadsvm.phaseListObj = {
            phases: []
        };
        manageFileUploadsvm.status = {
            isopen: false
        };
       
        function getBrowserType() {
            var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
            var isFirefox = typeof InstallTrigger !== 'undefined';
            var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            var isEdge = !isIE && !!window.StyleMedia;
            var isChrome = !!window.chrome && !!window.chrome.webstore;
            var isBlink = (isChrome || isOpera) && !!window.CSS;
            return { isIE: isIE, isChrome:isChrome, isEdge:isEdge }
        }
        manageFileUploadsvm.hideError = function () {
            $('.file-error-container').addClass('collapse');
            $('.file-upload-error').addClass('collapse');
            manageFileUploadsvm.formSubmitted = false;
            $('#exampleFormControlFile1').val(null);
            $('#fileName').text('No File Choosen');
            manageFileUploadsvm.fileChoosen = false;
        }
        manageFileUploadService.getMethods().success(function (res) {
            if (res) {
              
                manageFileUploadsvm.methods = res;
            }
        })

        manageFileUploadsvm.generateJson = function (optionType) {
            manageFileUploadsvm.downloadJsonClick = true;
            manageFileUploadsvm.uploadJsonClick = false;
            manageFileUploadsvm.generateJsonClick = true;
                       if (parseInt(optionType, 10) === 1) {
                manageFileUploadsvm.formSubmitted = true;
                if (manageFileUploadsvm.fileChoosen) {
                    manageFileUploadService.generateJson(parseInt(optionType, 10), fd).success(function (res) {
                        if (res.status) {

                            alerting.addAlert('success', TOAST_MESSAGE.FILE_UPLOAD);
                            //manageFileUploadsvm.downloadJsonClick = false;
                            var browserObject = getBrowserType();
                            //window.open(res.fileLocation)
                           
                            var blobObject = new Blob([browserObject.isIE ? res.fileData : res.fileData]);
                            if (window.navigator.msSaveBlob) {
                                window.navigator.msSaveBlob(blobObject, '' + res.fileName + '.json');
                                //$state.go('AdminMain.administration');
                            }
                       // }
                        else{
                            var parseFile = JSON.parse(res.fileData);
                            var parseStr = JSON.stringify(parseFile);
                            //manageFileUploadsvm.generateJsonClick = false;
                            //alerting.addAlert('success', TOAST_MESSAGE.FILE_UPLOAD);
                            var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(parseStr);
                            //var dataStr1 = "data:text/json;charset=utf-8," + encodeURIComponent((res));
                            var dlAnchorElem = document.getElementById('downloadLink');
                           
                            dlAnchorElem.setAttribute("href", dataStr);
                            dlAnchorElem.setAttribute("download", res.fileName + '.json');
                            dlAnchorElem.click();
                            }
                        }
                            // else {
                             // $('#downloadLink').attr(window.URL.createObjectURL(blobObject)).attr('download', res.fileName + '.json');
                             // document.getElementById('downloadLink').click();
                             // $state.go('AdminMain.administration');
                             //}

                             //}
                        else {
                            alerting.addAlert('danger', res.errorMsg);
                        }
                    })
                }
            }
        
               else {
                  $('.file-upload-error').removeClass('collapse');
                }
            }
            //else if (parseInt(optionType, 10) === 2) {
            //    manageFileUploadsvm.formSubmitted = true;
            //    if (manageFileUploadsvm.gridObj.domainId && manageFileUploadsvm.methodObj.methodId && manageFileUploadsvm.gridObj.complexityId.length) {
            //        manageFileUploadService.generateJson(parseInt(optionType, 10), { methodId: manageFileUploadsvm.methodObj.methodId, code: complexityList.length ? complexityList : null }).success(function (res,header,config) {
            //            if (res.status) {
            //                alerting.addalert('success', toast_message.activity_grid_status);
            //                $state.go('adminmain.administration');
            //                //var browserObject = getBrowserType();
            //                // window.open(res.fileLocation)
            //                //var blobObject = new Blob([browserObject.isIE ? res.fileData : res.fileData]);
            //                //if (window.navigator.msSaveOrOpenBlob) {
            //                   // window.navigator.msSaveOrOpenBlob(blobObject, '' + res.fileName + '.json');
            //                //}
            //                //else {
            //                   // $('#downloadLink').attr('href', window.URL.createObjectURL(blobObject)).attr('download', res.fileName + '.json');
            //                    //document.getElementById('downloadLink').click();
            //               // }

            //            }
            //            else {
            //                alerting.addAlert('danger', res.errorMsg);
            //            }
            //        })
            //    }

            //}

        //}
        manageFileUploadsvm.downloadJson = function (optionType) {
            manageFileUploadsvm.generateJsonClick = true;
            manageFileUploadsvm.downloadJsonClick = false;
            manageFileUploadsvm.uploadJsonClick = true;
            if (parseInt(optionType, 10) === 1) {
                manageFileUploadsvm.formSubmitted = true;
                if (manageFileUploadsvm.fileChoosen) {
                    manageFileUploadService.generateJson(parseInt(optionType, 10), fd).success(function (res) {
                        if (res.status) {
                            var parseFile = JSON.parse(res.fileData);
                            var parseStr = JSON.stringify(parseFile);
                            //manageFileUploadsvm.generateJsonClick = false;
                            //alerting.addAlert('success', TOAST_MESSAGE.FILE_UPLOAD);
                            var dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(parseStr);
                            //var dataStr1 = "data:text/json;charset=utf-8," + encodeURIComponent((res));
                            var dlAnchorElem = document.getElementById('downloadLink');
                           
                            dlAnchorElem.setAttribute("href", dataStr);
                            dlAnchorElem.setAttribute("download", res.fileName + '.json');
                            dlAnchorElem.click();
                            //$state.go('AdminMain.administration');
                            //var browserObject = getBrowserType();
                           // window.open(res.fileLocation)
                           // var blobObject = new Blob([browserObject.isIE ? res.fileData : res.fileData]);
                            //if (window.navigator.msSaveBlob) {
                               // window.navigator.msSaveBlob(blobObject, '' + res.fileName + '.json');
                               // $state.go('AdminMain.administration');
                           // }

                            //else {
                              //  $('#downloadLink').attr(window.URL.createObjectURL(blobObject)).attr('download', res.fileName + '.json');
                               // document.getElementById('downloadLink').click();
                               // $state.go('AdminMain.administration');
                            //}
                        }

                        else {
                            alerting.addAlert('danger', res.errorMsg);
                        }
                    })
                }
            }
            else {
                $('.file-upload-error').removeClass('collapse');
            }
        }
        manageFileUploadsvm.fileNameChanged = function (e) {
            $('.file-error-container,.file-upload-error').addClass('collapse');
            $('#fileName').text('No File Choosen');
            if (e.target.files.length) {
                var fileType = e.target.files[0];
                var methodIds = manageFileUploadsvm.methodObj.methodId;
                fd = new FormData();
                $('#fileValue').val(fileType.name);
                fileType = fileType.name.split('.');
                if (fileType[fileType.length - 1] === 'xlsx' || fileType[fileType.length - 1] === 'xls') {
                    manageFileUploadsvm.showFileError = false;
                    fd.append('methodId', methodIds);
                    //$('#methodId').text(methodIds);
                    fd.append('fileLocation', e.target.files[0]);
                    $('#fileName').text(e.target.files[0].name);
                    manageFileUploadsvm.fileChoosen = true;
                    $('#uploadBtn').removeAttr('disbaled');
                }
                else {
                    if ($('.file-error-container').hasClass('collapse')){
                        $('.file-error-container').removeClass('collapse');
                     
                        
                        manageFileUploadsvm.fileChoosen = false;
                    }
                    $('#fileValue').val(null);
                    e.currentTarget.value = null;
                    e.stopPropagation();

                }
            }
        }
            
        //manageFileUploadsvm.downloadExcel = function (obj) {

        //    $http.get(location.origin + '/api/CheckSiteRefreshing').success(function (response) {
        //        manageFileUploadsvm.formSubmitted = true;
        //        if (response.siteRefresh) {
        //            alerting.addAlert('danger', 'We are making some content updates and the site is being refreshed. Please try again after 5 minutes');
        //        }
        //        else {
        //            if (!manageFileUploadsvm.methodObj.methodId) {
        //                manageFileUploadsvm.formSubmitted = false;
        //                window.open(URLS.adminDownloadExcel + encodeURI( '?methodId=' + parseInt(obj.methodId ? obj.methodId : 0, 10) + ''));
        //            }
        //            if (manageFileUploadsvm.methodObj.methodId) {
        //                window.open(URLS.adminDownloadExcel + encodeURI( '?methodId=' + parseInt(obj.methodId ? obj.methodId : 0, 10) + ''));
        //            }
        //        }
        //    })


        //}
        
        
    }


    angular.module('sdmApp').controller('manageFileUploadCtrl', manageFileUploadCtrl);
})();
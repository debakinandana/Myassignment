﻿(function () {
    angular.module('sdmApp')
        .service('manageFileUploadService', function ($http, URLS) {
            this.getMethods = function (data) {
                return $http.get(URLS.adminExcelMethods);
            };
            //this.uploadExcel = function (data) {
                //return $http.patch(URLS.adminUploadExcel + '?methodId=' + data.methodId)
           
            //};
            //this.downloadJson = function () {
            //    return $http.get(URLS.adminDownloadExcel);
            //}
            this.generateJson = function (optionType, data) {
                //var inData = { param: data, param1: methodId };
                return optionType === 1 ? $http.patch(URLS.adminUploadExcel,data, {
                    withCredentials: true,
                    headers: {
                        'Content-Type': undefined,
                        //'accept': 'application/json;odata=verbose',
                        //'Access-Control-Allow-Methods': GET, POST, PUT, DELETE, patch,OPTIONS, HEAD,
                                               
                    },
                    transformRequest: angular.identity,
                    
                }) : $http.get(URLS.adminToJson + '?methodId=' + data.methodId + '&code=' + data.code);
            };
        });
})();
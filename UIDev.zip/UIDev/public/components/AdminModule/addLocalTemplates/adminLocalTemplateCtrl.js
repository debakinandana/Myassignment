﻿(function () {
    function adminLocalTemplateCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminLocalTemplateService, alerting, TOAST_MESSAGE, $scope, $http, URLS) {
        var adminLocalTemplatevm = this;
        adminLocalTemplatevm.$state = $state;
        adminLocalTemplatevm.locTemplates = [];
        adminLocalTemplatevm.totalItems = 0;
        adminLocalTemplatevm.pageSize = 10;
        adminLocalTemplatevm.pagination = {
            current: $state.params.page
        };
        adminLocalTemplatevm.searchFilter = {
            title: ''
        };
        function phaseFilter(arrayList, key, sourceObj) {
            result = null;
            arrayList.some(function (Obj) {
                if (Obj.isSelected) {
                    adminPhasevm.result = Obj;
                }
                else {
                    adminPhasevm.result = null;
                }
                return Obj.isSelected === true;
            })
            adminPhasevm.result = result;
        }
        function getResultsPage() {
            adminLocalTemplateService.getlocalTemplates({ pageNumber: adminLocalTemplatevm.pagination.current, searchValue: encodeURIComponent(adminLocalTemplatevm.searchFilter.title) }).success(function (res) {
                adminLocalTemplatevm.locTemplates = res.locTemplates;
                adminLocalTemplatevm.parentTemplates = res.parentTemplates;
                adminLocalTemplatevm.totalItems = res.count;
            });

            $http.get(URLS.countries).success(function (response) {
                adminLocalTemplatevm.countries = response;

            })
            $http.get(URLS.languages).success(function (response) {
                adminLocalTemplatevm.languages = response;
            })
        }
        getResultsPage();

        $rootScope.$on('updatedResults', function (e, data) {
            adminLocalTemplatevm.locTemplates = data;
        });

        adminLocalTemplatevm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminLocalTemplatevm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminLocalTemplatevm.searchLocTemplate = function (title) {
            adminLocalTemplatevm.searchFilter.title = title;
            getResultsPage();
        };

        adminLocalTemplatevm.DeleteConfirm = function (locTemplate) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deletelocalTemplateCtrl',
                resolve: {
                    selectedItem: function () {
                        return locTemplate;
                    }
                }
            });
        };
        adminLocalTemplatevm.submitForm = function () {
            adminLocalTemplatevm.formSubmitted = true;
            if ($scope.localTemplateForm.$valid) {
                if ($state.current.name === "AdminMain.administration.manageLocalisedTemplates.editLocalTemplate") {
                    adminLocalTemplateService.editLocalTemplate(adminLocalTemplatevm.locTemplateObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.manageLocalisedTemplates.editLocalTemplate") {
                                alerting.addAlert('success', TOAST_MESSAGE.LOCTEMP_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.LOCTEMP_ADDED);
                            }
                            $state.go('AdminMain.administration.manageLocalisedTemplates', {}, { reload: true });
                        }
                    })
                }
                else {
                    adminLocalTemplateService.addLocalTemplate(adminLocalTemplatevm.locTemplateObj).success(function (response) {
                        if (response.status) {
                            if ($state.current.name === "AdminMain.administration.manageLocalisedTemplates.editLocalTemplate") {
                                alerting.addAlert('success', TOAST_MESSAGE.LOCTEMP_UPDATED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.LOCTEMP_ADDED);
                            }
                            $state.go('AdminMain.administration.manageLocalisedTemplates', {}, { reload: true });
                        }
                    })
                }
                
            }
        }
        function getLocTemplateDetails(locTemplateId) {
            adminLocalTemplateService.getLocalTemplate(locTemplateId).success(function (res) {
                if (res) {
                    adminLocalTemplatevm.locTemplateObj = res.locTemplates[0];
                    adminLocalTemplatevm.parentTemplates = res.parentTemplates;
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.manageLocalisedTemplates.editLocalTemplate") {

            getLocTemplateDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
		.controller('adminLocalTemplateCtrl', adminLocalTemplateCtrl)
    .controller('deletelocalTemplateCtrl', function ($rootScope, $scope, $uibModalInstance, adminLocalTemplateService, alerting, TOAST_MESSAGE, selectedItem, $state) {
        $scope.getResultsPage = function () {
            adminLocalTemplateService.getlocalTemplates().success(function (res) {
                $scope.locTemplates = res.locTemplates;
            });
        }

        $scope.selectedLocalTemplate = selectedItem;
        $scope.title = selectedItem.title;
        $scope.deleteItem = function (selectedItem) {

            adminLocalTemplateService.deleteLocalTemplate($scope.selectedLocalTemplate.id).success(function (res) {
                if (res) {
                    alerting.addAlert('success', TOAST_MESSAGE.LOCTEMP_DELETED);
                    $rootScope.$emit("updatedResults", res.locTemplates);
                    $state.go('AdminMain.administration.manageLocalisedTemplates', {}, { reload: true });
                }

            });
            $scope.cancel();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })
})();
﻿(function () {
    angular.module('sdmApp')
        .service('adminLocalTemplateService', function ($http, URLS) {
            this.getlocalTemplates = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminLocalTemplates + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminLocalTemplates + '?pageNumber=1&pageSize=10');
                }

            };
            this.addLocalTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminLocalTemplates, data, config);
            };
            this.getLocalTemplate = function (data) {
                return (data) ? $http.get(URLS.adminLocalTemplates + '/' + data) : $http.get(URLS.adminLocalTemplates + '/' + data);
            };
            this.editLocalTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminLocalTemplates, data, config);
            };
            this.deleteLocalTemplate = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminLocalTemplates +'/' +itemId, config);
            };
        });
})();
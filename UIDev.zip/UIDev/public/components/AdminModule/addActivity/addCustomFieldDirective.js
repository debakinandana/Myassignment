﻿(function () {
    angular.module('sdmApp').directive('addCustomFields', [function () {
        self = this, keys = null, keyName = null;
        return {
            restrict: "EA",
            required: '^ngModel',

            templateUrl: "components/AdminModule/addActivity/addCustomFields.html",
            scope: {
                listModel: '=',
                labelName: '@',
                isTextAreaEnabled: '@',
                isTextAreaRequired: '@',
                isTextBoxEnabled: '@',
                isTextBoxRequired: '@',
                isDropDownEnabled: '@',
                isDropDownRequired: '@',
                dropDown: '=',
                dropDownModel: '=ngModel',
                maxLength: '=',
                attrId: '@',
                fieldId: '@'
            },
            link: function (originalScope, element, attrs, modelCtrl) {
                var scope = originalScope.$new();
                scope.listModel = originalScope.listModel;
                scope.labelName = originalScope.labelName;
                scope.isTextAreaEnabled = originalScope.isTextAreaEnabled;
                scope.isTextAreaRequired = originalScope.isTextAreaRequired;
                scope.isTextBoxEnabled = originalScope.isTextBoxEnabled;
                scope.isTextBoxRequired = originalScope.isTextBoxRequired;
                scope.isDropDownEnabled = originalScope.isDropDownEnabled;
                scope.isDropDownRequired = originalScope.isDropDownRequired;
                scope.dropDownModel = originalScope.dropDownModel;
                scope.attrId = originalScope.attrId;
                scope.maxLength = originalScope.maxLength;
                scope.fieldId = scope.fieldId.split(',');
                originalScope.parent = originalScope.$parent;
                var tempObj = new Object();

                if (scope.isTextBoxEnabled) {
                    scope.textFieldId = scope.fieldId[0];
                }
                if (scope.isTextAreaEnabled) {
                    scope.textAreaId = scope.fieldId[1]
                }
                if (scope.isDropDownEnabled) {
                    scope.dropDownId = scope.fieldId[2]
                }

                originalScope.$watch('dropDown', function (oldVal, newVal) {
                    scope.dropDown = oldVal;
                })
                originalScope.deleteItem = function (itemIndex) {
                    originalScope.listModel.splice(itemIndex, 1)
                }

                originalScope.addItem = function (e) {
                    originalScope.listModel = originalScope.listModel === undefined ? [] : originalScope.listModel;
                    originalScope.listModel.push(new Object({ textFieldId: scope.textFieldId, textAreaId: scope.textAreaId, dropDownId: scope.dropDownId }));

                }
                originalScope.greaterThan = function (val, length) {
                    if (val === undefined ? false : val.length > length) {
                        //originalScope.parent.formSubmitted = false;
                        originalScope.$parent.activityForm.$valid = false;
                    }
                    else if (val !== undefined) {
                        if (val.length > 0) {
                            originalScope.$parent.activityForm.$valid = true;
                        }
                        else if (val.length <= 0 || val === null || val.trim() === "") {
                            originalScope.$parent.activityForm.$valid = false;
                        }

                    }
                    return val === undefined ? false : val.length > length;
                }

            }
        };
    }])
})();
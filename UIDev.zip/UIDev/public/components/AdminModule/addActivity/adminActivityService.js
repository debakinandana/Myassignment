﻿(function () {
    angular.module('sdmApp')
        .service('adminActivityService', function ($http, URLS) {
            this.getActivities = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminActivities + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminActivities + '?pageNumber=1&pageSize=10');
                }

            };
            this.addActivity = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminActivities, data, config);
            };
            this.getActivity = function (data) {
                return (data.complexityId) ? $http.get(URLS.adminActivities + '?id=' + data.id + '&complexityId=' + data.complexityId + '') : $http.get(URLS.adminActivities + data.id);
            };
            this.editActivity = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminActivities, data, config);
            };
            this.deleteActivity = function (data) {
                var config = URLS.AntiforgeryConfig;
                return data.complexityId ? $http.delete(URLS.adminActivities + data.activityId + '/' + data.complexityId, config) : $http.delete(URLS.adminActivities + {}, { params: data }, config);
            };
            this.getComplexity = function () {
                return $http.get(URLS.adminComplexity);
            };
            this.getActivityVersions = function (data) {

                //return $http.get(URLS.adminActivityAllVersionsJson + '?complexityId=' + data.complexityId + '&artifactTypeId=' + data.artifactTypeId + '&artifactActualId=' + data.artifactActualId + '&versionNumber=' + data.versionNumber);
                //return (data.complexityId) ? $http.get(URLS.adminActivityAllVersionsJson + '?id=' + data.id + '&complexityId=' + data.complexityId + '&artifactTypeId=' + data.artifactTypeId + '&artifactActualId=' + data.artifactActualId + '&versionNumber=' + data.versionNumber) : $http.get(URLS.adminActivityAllVersionsJson + data.id);
                return $http.get(URLS.adminActivityAllVersionsJson + '?complexityId=' + data.complexityId + '&artifactTypeId=' + data.artifactTypeId + '&artifactActualId=' + data.artifactActualId + '&versionNumber=' + data.versionNumber);

            };
        });
})();
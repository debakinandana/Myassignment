﻿(function () {
    function addActivityCtrl($rootScope, $state, $document, $scope, $timeout, $ocLazyLoad, $uibModal, TOAST_MESSAGE, alerting, adminActivityService, SharedService) {
        var mutliDropDownList = [{ listName: 'responsible', selectedValue: 0, fieldValue: 'responsible', modelObj: 'activityRoleResponsibleIds' }, { listName: 'accountable', selectedValue: 0, fieldValue: 'accountable', modelObj: 'activityRoleAccountableIDs' }, { listName: 'consulted', selectedValue: 0, fieldValue: 'consulted', modelObj: 'activityRoleConsultedIds' }, { listName: 'informed', selectedValue: 0, fieldValue: 'informed', modelObj: 'activityRoleInformedIds' }, { listName: 'adminPhase', selectedValue: 0, fieldValue: 'adminPhase', modelObj: 'activityPhaseIds' }];
        var activityCtrl = this, tempVersion = null;
        activityCtrl.$state = $state;
        activityCtrl.adminActivities = [];
        activityCtrl.totalItems = 0;
        activityCtrl.pageSize = 10;
        activityCtrl.pagination = {
            current: $state.params.page
        };
        activityCtrl.searchFilter = {
            title: ''
        };


        function getResultsPage() {
            adminActivityService.getActivities({ pageNumber: activityCtrl.pagination.current, searchValue: encodeURIComponent(activityCtrl.searchFilter.title) }).success(function (res) {
                activityCtrl.activityObj = {};
                activityCtrl.adminActivities = res.adminActivities;
                activityCtrl.totalItems = res.count;
            });
        }
        if ($state.current.name === 'AdminMain.administration.manageActivities') {
            getResultsPage();
        }
        activityCtrl.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                activityCtrl.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        activityCtrl.searchActivity = function (title) {
            activityCtrl.searchFilter.title = title;
            getResultsPage();
        };
        activityCtrl.DeleteConfirm = function (activity) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteActivityCtrl',
                resolve: {
                    selectedItem: function () {
                        return activity;
                    }
                }
            });
        };
        $scope.editActivity = function (activityId) {
            if (activityId) {
                $state.go('editActivity', { id: activityId });
            }
        };

    }
    angular.module('sdmApp').controller('activityController', addActivityCtrl)

        .controller('deleteActivityCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminActivityService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.getResultsPage = function () {
                adminActivityService.getActivities().success(function (res) {
                    $scope.activities = res.adminActivities;
                });
            };


            $scope.selectedActivity = selectedItem;
            $scope.title = selectedItem.title;

            console.log(selectedItem);

            $scope.deleteItem = function (selectedItem) {

                adminActivityService.deleteActivity({ id: $scope.selectedActivity.id, activityId: $scope.selectedActivity.activityId }).success(function (res) {
                    alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_DELETED);
                    $rootScope.$emit('updatedResults', res.adminActivities);
                    $state.go('AdminMain.administration.manageActivities', {}, { reload: true });
                });
                $scope.cancel();
            }



            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        }).controller('deleteComplexityActivityCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminActivityService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.selectedActivity = selectedItem.activityObj;
            $scope.title = selectedItem.activityObj.title;
            $scope.selectedComplexity = selectedItem.projectComplexityList.filter(function (filterObj) {
                return filterObj.id === $scope.selectedActivity.complexityId;
            })
            $scope.selectedComplexity = $scope.selectedComplexity[0].name;
            $scope.deleteItem = function (selectedItem) {
                adminActivityService.deleteActivity({ activityId: $scope.selectedActivity.activityId, complexityId: $scope.selectedActivity.complexityId, type: 'complexity' }).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.COMPLEXITY_STATUS);
                        $state.reload();
                    }
                    else {
                        alerting.addAlert('danger', res.errorMsg);
                    }

                });
                $scope.cancel();
            }
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        }).controller('activityPreviewCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminActivityService, alerting, TOAST_MESSAGE, previewObj) {
            if (previewObj.activityObj) {
                $scope.previewObj = previewObj;

                if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                    previewObj.activityObj.activityVersion = "1.00";
                    var date = new Date();
                    //var datePart = date.match(/\d+/g);
                    var dd = date.getDate();
                    var mm = date.getMonth() + 1;
                    var yyyy = date.getFullYear();
                    //if (dd < 10) {
                    //    dd = '0' + dd;
                    //}

                    //if (mm < 10) {
                    //    mm = '0' + mm;
                    //}
                    var newDate = mm + "/" + dd + "/" + yyyy;
                    previewObj.activityObj.versionModifiedDate = newDate;
                }
                //if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                //    addActivityCtrl.updateVersion = function (versionType) {
                //        if (versionType && versionType === 'major' && versionType && versionType === 'major') {
                //            previewObj.activityObj.versionModifiedDate = previewObj.activityObj.versionModifiedDate;

                //        }
                //        if (versionType && versionType === 'nochange') {
                //            var date = new Date();
                //            //var datePart = date.match(/\d+/g);
                //            var dd = date.getDate();
                //            var mm = date.getMonth() + 1;
                //            var yyyy = date.getFullYear();
                //            //if (dd < 10) {
                //            //    dd = '0' + dd;
                //            //}

                //            //if (mm < 10) {
                //            //    mm = '0' + mm;
                //            //}
                //            var newDate = mm + "/" + dd + "/" + yyyy;
                //            previewObj.activityObj.versionModifiedDate = newDate;
                //        }
                //    }
                //}
                if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                    if (previewObj.activityObj.activityVersion !== previewObj.activityObj.selectedVersion) {
                        var date = new Date();
                        //var datePart = date.match(/\d+/g);
                        var dd = date.getDate();
                        var mm = date.getMonth() + 1;
                        var yyyy = date.getFullYear();
                        //if (dd < 10) {
                        //    dd = '0' + dd;
                        //}

                        //if (mm < 10) {
                        //    mm = '0' + mm;
                        //}
                        var newDate = mm + "/" + dd + "/" + yyyy;
                        previewObj.activityObj.versionModifiedDate = newDate;
                    } else if (previewObj.activityObj.activityVersion === previewObj.activityObj.selectedVersion) {

                        var date = previewObj.activityObj.modifiedDate;
                        var datepart = date.match(/\d+/g);
                        var year = datepart[0].substring();
                        var month = datepart[1];
                        var day = datepart[2];
                        var newdate = month + "/" + day + "/" + year;

                        previewObj.activityObj.versionModifiedDate = newdate;

                    }
                }
                //var date = previewObj.activityObj.modifiedDate;
                //var datePart = date.match(/\d+/g);
                //var year = datePart[0].substring();
                //var month = datePart[1];
                //var day = datePart[2];
                // var newDate = month + "/" + day + "/"+ year;
                //$scope.newDate=previewObj.activityObj.modifiedDate;
                //var versionDate = previewObj.activityObj.newDate;
                // previewObj.activityObj.modifiedDate=newDate;
                if ($scope.previewObj.activityObj.activityPhaseIds && $scope.previewObj.activityObj.activityPhaseIds.length > 0) {
                    $scope.previewObj.phaseName = $scope.previewObj.phaseList.filter(function (phaseObj) {
                        return $scope.previewObj.activityObj.activityPhaseIds[0] === phaseObj.id;
                    });
                    $scope.previewObj.phaseName = $scope.previewObj.phaseName[0];
                }
                if ($scope.previewObj.activityObj.activityRoleResponsibleIds && $scope.previewObj.activityObj.activityRoleResponsibleIds.length > 0) {
                    $scope.previewObj.responsibleName = "";
                    $scope.previewObj.responsibleList.forEach(function (listObj) {
                        $scope.previewObj.activityObj.activityRoleResponsibleIds.forEach(function (selectedObj, index) {
                            $scope.previewObj.responsibleName = selectedObj === listObj.id ? index < $scope.previewObj.activityObj.activityRoleResponsibleIds.length - 1 && $scope.previewObj.activityObj.activityRoleResponsibleIds.length > 1 ? $scope.previewObj.responsibleName + listObj.name + ',' : $scope.previewObj.responsibleName + listObj.name : $scope.previewObj.responsibleName;
                        })
                    });
                }
                if ($scope.previewObj.activityObj.activityRoleAccountableIds && $scope.previewObj.activityObj.activityRoleAccountableIds.length > 0) {
                    $scope.previewObj.accountableName = "";
                    $scope.previewObj.accountableList.forEach(function (listObj) {
                        $scope.previewObj.activityObj.activityRoleAccountableIds.forEach(function (selectedObj, index) {
                            $scope.previewObj.accountableName = selectedObj === listObj.id ? index < $scope.previewObj.activityObj.activityRoleAccountableIds.length - 1 && $scope.previewObj.activityObj.activityRoleAccountableIds.length > 1 ? $scope.previewObj.accountableName + listObj.name + ',' : $scope.previewObj.accountableName + listObj.name : $scope.previewObj.accountableName;
                        });
                    });
                }
                if ($scope.previewObj.activityObj.activityRoleConsultedIds && $scope.previewObj.activityObj.activityRoleConsultedIds.length > 0) {
                    $scope.previewObj.consultedName = "";
                    $scope.previewObj.consultedList.forEach(function (listObj) {
                        $scope.previewObj.activityObj.activityRoleConsultedIds.forEach(function (selectedObj, index) {
                            $scope.previewObj.consultedName = selectedObj === listObj.id ? index < $scope.previewObj.activityObj.activityRoleConsultedIds.length - 1 && $scope.previewObj.activityObj.activityRoleConsultedIds.length > 1 ? $scope.previewObj.consultedName + listObj.name + ',' : $scope.previewObj.consultedName + listObj.name : $scope.previewObj.consultedName;
                        })
                    });
                }
                if ($scope.previewObj.activityObj.activityRoleInformedIds && $scope.previewObj.activityObj.activityRoleInformedIds.length > 0) {
                    $scope.previewObj.informedName = "";
                    $scope.previewObj.informedList.forEach(function (listObj) {
                        $scope.previewObj.activityObj.activityRoleInformedIds.forEach(function (selectedObj, index) {
                            $scope.previewObj.informedName = selectedObj === listObj.id ? index < $scope.previewObj.activityObj.activityRoleInformedIds.length - 1 && $scope.previewObj.activityObj.activityRoleInformedIds.length > 1 ? $scope.previewObj.informedName + listObj.name + ',' : $scope.previewObj.informedName + listObj.name : $scope.previewObj.informedName;
                        })
                    });
                }
                if ($scope.previewObj.activityObj.activityTemplateIds && $scope.previewObj.activityObj.activityTemplateIds.length > 0) {
                    $scope.previewObj.templateListObj = [];
                    $scope.previewObj.templateList.forEach(function (templateObj) {
                        $scope.previewObj.activityObj.activityTemplateIds.forEach(function (selectedObj, index) {
                            selectedObj === templateObj.id ? $scope.previewObj.templateListObj.push(templateObj) : $scope.previewObj.templateListObj;
                        })
                    });
                }
                if ($scope.previewObj.activityObj.topicId) {
                    $scope.previewObj.topicName = null;
                    $scope.previewObj.topicName = $scope.previewObj.topicsList.filter(function (topicObj) {
                        return topicObj.id === $scope.previewObj.activityObj.topicId;
                    });
                    $scope.previewObj.topicName = $scope.previewObj.topicName[0].name;

                }
                if ($scope.previewObj.activityObj.description) {
                    if ($scope.previewObj.activityObj.description.search('<img') > 0 && $scope.previewObj.activityObj.description.search('../images') > 0) {
                        $scope.previewObj.activityObj.description = $scope.previewObj.activityObj.description.replace(new RegExp('../images', 'g'), '/sdm/images');
                    }
                    if ($scope.previewObj.activityObj.description.search('../activityContent/activityDetail.html?id') > 0) {
                        $scope.previewObj.activityObj.description = $scope.previewObj.activityObj.description.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.supportingActivities) {
                    if ($scope.previewObj.activityObj.supportingActivities.search('<img') >= 0 && $scope.previewObj.activityObj.supportingActivities.search('../images') >= 0) {
                        $scope.previewObj.activityObj.supportingActivities = $scope.previewObj.activityObj.supportingActivities.replace(new RegExp('../images', 'g'), '/sdm/images');
                    }
                    if ($scope.previewObj.activityObj.supportingActivities.search('../activityContent/activityDetail.html?id') > 0) {
                        $scope.previewObj.activityObj.supportingActivities = $scope.previewObj.activityObj.supportingActivities.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.deliverables) {
                    if ($scope.previewObj.activityObj.deliverables.search('<img') >= 0 && $scope.previewObj.activityObj.deliverables.search('../images') >= 0) {
                        $scope.previewObj.activityObj.deliverables = $scope.previewObj.activityObj.deliverables.replace(new RegExp('../images', 'g'), '/sdm/images');
                    }
                    if ($scope.previewObj.activityObj.deliverables.search('../activityContent/activityDetail.html?id') > 0) {
                        $scope.previewObj.activityObj.deliverables = $scope.previewObj.activityObj.deliverables.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.toolsAndGuidance) {
                    if ($scope.previewObj.activityObj.toolsAndGuidance.search('<img') >= 0 && $scope.previewObj.activityObj.toolsAndGuidance.search('../images') >= 0) {
                        $scope.previewObj.activityObj.toolsAndGuidance = $scope.previewObj.activityObj.toolsAndGuidance.replace(new RegExp('../images', 'g'), '/sdm/images');
                    }
                    if ($scope.previewObj.activityObj.toolsAndGuidance.search('../activityContent/activityDetail.html?id') > 0) {
                        $scope.previewObj.activityObj.toolsAndGuidance = $scope.previewObj.activityObj.toolsAndGuidance.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                    }

                }
                if ($scope.previewObj.activityObj.tipsAndTechniques) {
                    if ($scope.previewObj.activityObj.tipsAndTechniques.search('<img') >= 0 && $scope.previewObj.activityObj.tipsAndTechniques.search('../images') >= 0) {
                        $scope.previewObj.activityObj.tipsAndTechniques = $scope.previewObj.activityObj.tipsAndTechniques.replace(new RegExp('../images', 'g'), '/sdm/images');
                    }
                    if ($scope.previewObj.activityObj.tipsAndTechniques.search('../activityContent/activityDetail.html?id') > 0) {
                        $scope.previewObj.activityObj.tipsAndTechniques = $scope.previewObj.activityObj.tipsAndTechniques.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.activityTasks && $scope.previewObj.activityObj.activityTasks.length) {
                    $scope.previewObj.activityObj.activityTasks.forEach(function (taskObj) {
                        if (taskObj.description == undefined) taskObj.description = '';
                        if (taskObj.name.search('<img') >= 0 && taskObj.name.search('../images') >= 0) {
                            taskObj.name = taskObj.name.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (taskObj.name.search('../activityContent/activityDetail.html?id') > 0) {
                            taskObj.name = taskObj.name.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }
                        if (taskObj.description.search('<img') >= 0 && taskObj.description.search('../images') >= 0) {
                            taskObj.description = taskObj.description.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (taskObj.description.search('../activityContent/activityDetail.html?id') > 0) {
                            taskObj.description = taskObj.description.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }

                    })
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.entryActivityCriteria && $scope.previewObj.activityObj.entryActivityCriteria.length) {
                    $scope.previewObj.activityObj.entryActivityCriteria.forEach(function (entryCriteriaObj) {
                        if (entryCriteriaObj.description == undefined) entryCriteriaObj.description = '';
                        if (entryCriteriaObj.name.search('<img') >= 0 && entryCriteriaObj.name.search('../images') >= 0) {
                            entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (entryCriteriaObj.name.search('../activityContent/activityDetail.html?id') > 0) {
                            entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }
                        if (entryCriteriaObj.description.search('<img') >= 0 && entryCriteriaObj.name.search('../images') >= 0) {
                            entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (entryCriteriaObj.description.search('../activityContent/activityDetail.html?id') > 0) {
                            entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }

                    })
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.exitActivityCriteria && $scope.previewObj.activityObj.exitActivityCriteria.length) {
                    $scope.previewObj.activityObj.exitActivityCriteria.forEach(function (exitCriteriaObj) {
                        if (exitCriteriaObj.description == undefined) exitCriteriaObj.description = '';
                        if (exitCriteriaObj.name.search('<img') >= 0 && exitCriteriaObj.name.search('../images') >= 0) {
                            exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (exitCriteriaObj.name.search('../activityContent/activityDetail.html?id') > 0) {
                            exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }
                        if (exitCriteriaObj.description.search('<img') >= 0 && exitCriteriaObj.name.search('../images') >= 0) {
                            exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('../images', 'g'), '/sdm/images');
                        }
                        if (exitCriteriaObj.description.search('../activityContent/activityDetail.html?id') > 0) {
                            exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('../activityContent/activityDetail.html', 'g'), '/sdm/activityContent/activityDetail.html');
                        }

                    })
                }

            }

            $scope.cancel = function () {
                if ($scope.previewObj.activityObj.description) {
                    if ($scope.previewObj.activityObj.description.search('<img') > 0 && $scope.previewObj.activityObj.description.search('/sdm/images') >= 0) {
                        $scope.previewObj.activityObj.description = $scope.previewObj.activityObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                    }
                    if ($scope.previewObj.activityObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                        $scope.previewObj.activityObj.description = $scope.previewObj.activityObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.supportingActivities) {
                    if ($scope.previewObj.activityObj.supportingActivities.search('<img') > 0 && $scope.previewObj.activityObj.supportingActivities.search('/sdm/images') >= 0) {
                        $scope.previewObj.activityObj.supportingActivities = $scope.previewObj.activityObj.supportingActivities.replace(new RegExp('/sdm/images', 'g'), '../images');
                    }
                    if ($scope.previewObj.activityObj.supportingActivities.search('/sdm/activityContent/activityDetail.html') > 0) {
                        $scope.previewObj.activityObj.supportingActivities = $scope.previewObj.activityObj.supportingActivities.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.deliverables) {
                    if ($scope.previewObj.activityObj.deliverables.search('<img') > 0 && $scope.previewObj.activityObj.deliverables.search('/sdm/images') >= 0) {
                        $scope.previewObj.activityObj.deliverables = $scope.previewObj.activityObj.deliverables.replace(new RegExp('/sdm/images', 'g'), '../images');
                    }
                    if ($scope.previewObj.activityObj.deliverables.search('/sdm/activityContent/activityDetail.html') > 0) {
                        $scope.previewObj.activityObj.deliverables = $scope.previewObj.activityObj.deliverables.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.toolsAndGuidance) {
                    if ($scope.previewObj.activityObj.toolsAndGuidance.search('<img') > 0 && $scope.previewObj.activityObj.toolsAndGuidance.search('/sdm/images') >= 0) {
                        $scope.previewObj.activityObj.toolsAndGuidance = $scope.previewObj.activityObj.toolsAndGuidance.replace(new RegExp('/sdm/images', 'g'), '../images');
                    }
                    if ($scope.previewObj.activityObj.toolsAndGuidance.search('/sdm/activityContent/activityDetail.html') > 0) {
                        $scope.previewObj.activityObj.toolsAndGuidance = $scope.previewObj.activityObj.toolsAndGuidance.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj.tipsAndTechniques) {
                    if ($scope.previewObj.activityObj.tipsAndTechniques.search('<img') > 0 && $scope.previewObj.activityObj.tipsAndTechniques.search('/sdm/images') >= 0) {
                        $scope.previewObj.activityObj.tipsAndTechniques = $scope.previewObj.activityObj.tipsAndTechniques.replace(new RegExp('/sdm/images', 'g'), '../images');
                    }
                    if ($scope.previewObj.activityObj.tipsAndTechniques.search('/sdm/activityContent/activityDetail.html') > 0) {
                        $scope.previewObj.activityObj.tipsAndTechniques = $scope.previewObj.activityObj.tipsAndTechniques.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                    }
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.activityTasks && $scope.previewObj.activityObj.activityTasks.length) {
                    $scope.previewObj.activityObj.activityTasks.forEach(function (taskObj) {
                        if (taskObj.name.search('<img') >= 0 && taskObj.name.search('/sdm/images') >= 0) {
                            taskObj.name = taskObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (taskObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                            taskObj.name = taskObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                        if (taskObj.description.search('<img') >= 0 && taskObj.description.search('/sdm/images') >= 0) {
                            taskObj.description = taskObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (taskObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                            taskObj.description = taskObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }

                    })
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.entryActivityCriteria && $scope.previewObj.activityObj.entryActivityCriteria.length) {
                    $scope.previewObj.activityObj.entryActivityCriteria.forEach(function (entryCriteriaObj) {
                        if (entryCriteriaObj.name.search('<img') >= 0 && entryCriteriaObj.name.search('/sdm/images') >= 0) {
                            entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (entryCriteriaObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                            entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                        if (entryCriteriaObj.description.search('<img') >= 0 && entryCriteriaObj.description.search('/sdm/images') >= 0) {
                            entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (entryCriteriaObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                            entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }

                    })
                }
                if ($scope.previewObj.activityObj && $scope.previewObj.activityObj.exitActivityCriteria && $scope.previewObj.activityObj.exitActivityCriteria.length) {
                    $scope.previewObj.activityObj.exitActivityCriteria.forEach(function (exitCriteriaObj) {
                        if (exitCriteriaObj.name.search('<img') >= 0 && exitCriteriaObj.name.search('/sdm/images') >= 0) {
                            exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (exitCriteriaObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                            exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                        if (exitCriteriaObj.description.search('<img') >= 0 && exitCriteriaObj.description.search('/sdm/images') >= 0) {
                            exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                        }
                        if (exitCriteriaObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                            exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }

                    })
                }
                $uibModalInstance.dismiss('cancel');
            };


        }).controller('addActivityController', function ($rootScope, $state, $document, $scope, $timeout, $ocLazyLoad, $uibModal, TOAST_MESSAGE, alerting, adminActivityService, SharedService) {
            var addActivityCtrl = this;
            addActivityCtrl.$state = $state;
            addActivityCtrl.tinymceOptions = {
                selector: "textarea",
                menubar: false,
                statusbar: false,
                content_css: 'components/common/commoncss/tinymce.css',
                plugins: ['advlist autolink lists link image charmap print preview hr anchor pagebreak',
                    'searchreplace wordcount visualblocks visualchars code fullscreen',
                    'insertdatetime media nonbreaking save table contextmenu directionality',
                    'emoticons template paste textcolor colorpicker textpattern imagetools', 'codesample'],
                toolbar: 'undo redo | insert | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image | code | codesample| forecolor | backcolor',
                custom_undo_redo_levels: 10,
                textcolor_rows: "4",
                browser_spellcheck: true,
                table_default_attributes: {
                    'border': 1, 'width': 300, 'height': 100, 'cellspacing': 0
                },
                contextmenu: 'inserttable | cell row column deletetable',
                extended_valid_elements: ['script[src|type|language]', 'img[class|src|alt|title|width|height|style]', 'div[rel|class|id]'],
                codesample_languages: [
                    { text: 'HTML/XML', value: 'markup' },
                    { text: 'JavaScript', value: 'javascript' }
                ]
            };

            addActivityCtrl.updateVersion = function (versionType) {

                addActivityCtrl.activityObj.activityVersion = addActivityCtrl.activityObj.selectedVersion ? tempVersion : '1.00';


                if (versionType && versionType === 'major') {

                    addActivityCtrl.activityObj.activityVersion = parseInt(addActivityCtrl.activityObj.activityVersion, 10);
                    addActivityCtrl.activityObj.activityVersion += 1;
                    addActivityCtrl.activityObj.activityVersion = addActivityCtrl.activityObj.activityVersion.toFixed(2);
                    addActivityCtrl.disableOnSelectPrveiousVersion = false;
                    addActivityCtrl.disablePrveiousVersion = false;
                }
                else if (versionType && versionType === 'minor') {
                    addActivityCtrl.activityObj.activityVersion = parseFloat(addActivityCtrl.activityObj.activityVersion) + 0.01;
                    addActivityCtrl.activityObj.activityVersion = addActivityCtrl.activityObj.activityVersion.toFixed(2);
                    addActivityCtrl.disableOnSelectPrveiousVersion = false;
                    addActivityCtrl.disablePrveiousVersion = false;
                }

                if (versionType && versionType === 'nochange') {
                    addActivityCtrl.disableOnSelectPrveiousVersion = false;
                    addActivityCtrl.disablePrveiousVersion = false;
                }
            };
            function updateActivityDetails(response) {
                if (response.adminActivities) {
                    if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                        addActivityCtrl.activityObj.complexityId = data.complexityId ? data.complexityId : "";
                        $scope.selectedVersion = true;
                        //$scope.isActivityMajor = true;
                        //$scope.isActivityMinor = true;
                        //$scope.isNoChange = true;
                        addActivityCtrl.disableActivityMajor = true;
                        addActivityCtrl.disableActivityMinor = true;
                        addActivityCtrl.disableActivityNoChange = true;
                        $scope.addActivityCtrl.activityObj.selectedVersion = "1.00";
                    }

                    else if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {

                        addActivityCtrl.activityObj = response.adminActivities;
                        addActivityCtrl.activityObj.id = parseInt($state.params.id);
                        addActivityCtrl.activityObj.entryActivityCriteria = response['entryActivityCriteria'];
                        addActivityCtrl.activityObj.exitActivityCriteria = response['exitActivityCriteria'];
                        addActivityCtrl.activityObj.activityTasks = response['activityTasks'];
                        addActivityCtrl.activityObj.activityCriteriaMasterList = response['activityCriteriaMasterList'];
                        addActivityCtrl.templateList = response['adminTemplates'];
                        addActivityCtrl.activityObj.activityRoleResponsibleIds = [];
                        addActivityCtrl.activityObj.activityRoleAccountableIds = [];
                        addActivityCtrl.activityObj.activityRoleConsultedIds = [];
                        addActivityCtrl.activityObj.activityRoleInformedIds = [];
                        addActivityCtrl.activityObj.activityPhaseIds = [];
                        addActivityCtrl.activityObj.activityTemplateIds = [];
                        addActivityCtrl.activityObj.deliverableIds = [];
                        addActivityCtrl.activityObj.processGroupIds = [];
                    }
                    addActivityCtrl.responsibleList = response["responsible"];
                    addActivityCtrl.accountableList = response["accountable"];
                    addActivityCtrl.consultedList = response["consulted"];
                    addActivityCtrl.informedList = response["informed"];
                    addActivityCtrl.phaseList = response["adminPhase"];
                    addActivityCtrl.activityObj.activityTasks = response['activityTasks'];
                    addActivityCtrl.activityObj.activityCriteriaMasterList = response['activityCriteriaMasterList'];
                    addActivityCtrl.templateList = response['adminTemplates'];
                    addActivityCtrl.topicsList = response['topicsList'];
                    addActivityCtrl.groupIdList = response['adminActivityGroup'];
                    addActivityCtrl.deliverablesList = response['deliverablesList'];
                    addActivityCtrl.processGroupsList = response['processGroupsList'];

                    addActivityCtrl.responsibleList.forEach(function (responseObj) {
                        if (responseObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleResponsibleIds.push(responseObj.id);
                        }
                    })
                    addActivityCtrl.accountableList.forEach(function (accountableObj) {
                        if (accountableObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleAccountableIds.push(accountableObj.id);
                        }
                    })
                    addActivityCtrl.consultedList.forEach(function (consultedObj) {
                        if (consultedObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleConsultedIds.push(consultedObj.id);
                        }
                    })
                    addActivityCtrl.informedList.forEach(function (informedObj) {
                        if (informedObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleInformedIds.push(informedObj.id);
                        }
                    })

                    addActivityCtrl.groupIdList.forEach(function (responseObj) {
                        if (responseObj.isSelected) {
                            addActivityCtrl.activityObj.groupId = responseObj.id;
                        }
                    })
                    addActivityCtrl.topicsList.forEach(function (responseObj) {
                        if (responseObj.isSelected) {
                            addActivityCtrl.activityObj.topicId = (responseObj.id);
                        }
                    })

                    addActivityCtrl.templateList.forEach(function (templateObj) {
                        if (templateObj.isSelected) {
                            addActivityCtrl.activityObj.activityTemplateIds.push(templateObj.id);
                        }
                    })
                    addActivityCtrl.phaseList.forEach(function (phaseObj) {
                        if (phaseObj.isSelected) {
                            addActivityCtrl.activityObj.activityPhaseIds.push(phaseObj.id);
                        }
                    })

                    addActivityCtrl.deliverablesList.forEach(function (deliverableidObj) {
                        if (deliverableidObj.isSelected) {
                            addActivityCtrl.activityObj.deliverableId.push(deliverableidObj.id);
                        }
                    })
                    addActivityCtrl.processGroupsList.forEach(function (processgroupidObj) {
                        if (processgroupidObj.isSelected) {
                            addactivityctrl.activityobj.processGroupId.push(processgroupidObj.id);
                        }
                    })

                    return addActivityCtrl;
                }
            }
            function getActivityDetails(data) {
                addActivityCtrl.activityObj = {};

                adminActivityService.getActivity(data).success(function (response) {
                    if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                        addActivityCtrl.activityObj.complexityId = data.complexityId ? data.complexityId : "";
                        $scope.selectedVersion = true;
                        //$scope.isActivityMajor = true;
                        //$scope.isActivityMinor = true;
                        //$scope.isNoChange = true;
                        addActivityCtrl.disableActivityMajor = true;
                        addActivityCtrl.disableActivityMinor = true;
                        addActivityCtrl.disableActivityNoChange = true;
                        addActivityCtrl.activityObj.selectedVersion = "1.00";
                    }

                    else if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                        addActivityCtrl.activityObj = response.adminActivities[0];
                        tempVersion = addActivityCtrl.activityObj.selectedVersion;
                        addActivityCtrl.activityObj.entryActivityCriteria = response['entryActivityCriteria'];
                        addActivityCtrl.activityObj.exitActivityCriteria = response['exitActivityCriteria'];
                        addActivityCtrl.activityObj.activityTasks = response['activityTasks'];
                        addActivityCtrl.activityObj.activityCriteriaMasterList = response['activityCriteriaMasterList'];
                        addActivityCtrl.complexityIdList = response['projectComplexity'];
                        //addActivityCtrl.activityObj.activityVersionList.activtyVersions = [];
                        addActivityCtrl.copyToProjectComplexityList = response['copyToProjectComplexity'];
                        addActivityCtrl.templateList = response['adminTemplates'];
                        addActivityCtrl.activityObj.activityRoleResponsibleIds = [];
                        addActivityCtrl.activityObj.activityRoleAccountableIds = [];
                        addActivityCtrl.activityObj.activityRoleConsultedIds = [];
                        addActivityCtrl.activityObj.activityRoleInformedIds = [];
                        addActivityCtrl.activityObj.activityPhaseIds = [];
                        addActivityCtrl.activityObj.activityTemplateIds = [];

                    }
                    addActivityCtrl.responsibleList = response["responsible"];
                    addActivityCtrl.accountableList = response["accountable"];
                    addActivityCtrl.consultedList = response["consulted"];
                    addActivityCtrl.informedList = response["informed"];
                    addActivityCtrl.phaseList = response["adminPhase"];
                    addActivityCtrl.activityObj.activityTasks = response['activityTasks'];
                    addActivityCtrl.activityObj.activityCriteriaMasterList = response['activityCriteriaMasterList'];
                    addActivityCtrl.complexityIdList = response['projectComplexity'];
                    addActivityCtrl.copyToProjectComplexityList = response['copyToProjectComplexity'];
                    addActivityCtrl.templateList = response['adminTemplates'];
                    addActivityCtrl.topicsList = response['topicsList'];
                    addActivityCtrl.groupIdList = response['adminActivityGroup'];
                    addActivityCtrl.deliverIdList = response['DeliverablesList'];
                    addActivityCtrl.processIdList = response['ProcessGroupsList'];
                    addActivityCtrl.deliverablesList = response['deliverablesList'];
                    addActivityCtrl.processGroupsList = response['processGroupsList'];
                    addActivityCtrl.activityObj.selectedComplexity = response.projectComplexity.filter(function (filterObj) {
                        filterObj.id === addActivityCtrl.activityObj.complexityId;
                    })


                    addActivityCtrl.responsibleList.forEach(function (responseObj) {
                        if (responseObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleResponsibleIds.push(responseObj.id)
                        }
                    })
                    addActivityCtrl.accountableList.forEach(function (accountableObj) {
                        if (accountableObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleAccountableIds.push(accountableObj.id)
                        }
                    })
                    addActivityCtrl.consultedList.forEach(function (consultedObj) {
                        if (consultedObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleConsultedIds.push(consultedObj.id)
                        }
                    })
                    addActivityCtrl.informedList.forEach(function (informedObj) {
                        if (informedObj.isSelected) {
                            addActivityCtrl.activityObj.activityRoleInformedIds.push(informedObj.id)
                        }
                    })

                    addActivityCtrl.templateList.forEach(function (templateObj) {
                        if (templateObj.isSelected) {
                            addActivityCtrl.activityObj.activityTemplateIds.push(templateObj.id)
                        }
                    })
                    addActivityCtrl.phaseList.forEach(function (phaseObj) {
                        if (phaseObj.isSelected) {
                            addActivityCtrl.activityObj.activityPhaseIds.push(phaseObj.id)
                        }
                    })

                    addActivityCtrl.deliverablesList.forEach(function (deliverableidObj) {
                        if (deliverableidObj.isSelected) {
                            addActivityCtrl.activityObj.deliverableId.push(deliverableidObj.id);
                        }
                    })
                    addActivityCtrl.processGroupsList.forEach(function (processgroupidObj) {
                        if (processgroupidObj.isSelected) {
                            addactivityctrl.activityobj.processGroupId.push(processgroupidObj.id);
                        }
                    })

                })
            }
            if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                getActivityDetails({ id: -1 });
            }
            else if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                getActivityDetails({ id: $state.params.id });
            }
            addActivityCtrl.changeComplexity = function (complexityId) {
                if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                    getActivityDetails({ id: $state.params.id, complexityId: complexityId });
                }
                if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                    getActivityDetails({ id: -1, complexityId: complexityId });
                }
            }

            function getAuditVersionRecord(data) {


                adminActivityService.getActivityVersions(data).success(function (response) {
                    addActivityCtrl.activityObj = {};
                    addActivityCtrl = updateActivityDetails(response);
                })
            }


            addActivityCtrl.changeVersion = function (complexityId, artifactTypeId, artifactActualId, versionNumber) {
                if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                    getAuditVersionRecord({ artifactTypeId: 1, artifactActualId: addActivityCtrl.activityObj.activityId, versionNumber: addActivityCtrl.activityObj.selectedVersion, complexityId: addActivityCtrl.activityObj.complexityId });
                    var versionList = new Array();
                    for (var i = 0; i < addActivityCtrl.activityObj.activityVersionList.activityVersions.length; i++) {
                        versionList.push(parseFloat(addActivityCtrl.activityObj.activityVersionList.activityVersions[i].versionNumber));
                    }

                    var maxVersion = Math.max.apply(null, versionList);
                    var latestVersion = parseFloat(maxVersion).toFixed(2);
                    if (addActivityCtrl.activityObj.selectedVersion != latestVersion) {
                        addActivityCtrl.activityObj.isNoChange = false;
                        addActivityCtrl.disableSubmit = true;
                        addActivityCtrl.disableActivityMajor = true;
                        addActivityCtrl.disableActivityMinor = true;
                        addActivityCtrl.disableActivityNoChange = true;


                    }
                    else {
                        addActivityCtrl.disableSubmit = false;
                        addActivityCtrl.disableActivityMajor = false;
                        addActivityCtrl.disableActivityMinor = false;
                        addActivityCtrl.disableActivityNoChange = false;
                        addActivityCtrl.activityObj.isNoChange = true;
                    }
                }
            }


            $scope.submitForm = function () {

                $scope.formSubmitted = true;

                var result = addActivityCtrl.activityObj.activityPhaseIds ? addActivityCtrl.activityObj.activityPhaseIds.join('').toString().search('-1') < 0 ? addActivityCtrl.activityObj.activityPhaseIds.length === 0 ? true : false : true : true;
                addActivityCtrl.activityObj.activityVersion = addActivityCtrl.activityObj.activityVersion ? addActivityCtrl.activityObj.activityVersion : addActivityCtrl.activityObj.selectedVersion ? addActivityCtrl.activityObj.selectedVersion : '1.00';



                if ($scope.activityForm.$valid) {

                    if (addActivityCtrl.activityObj.description) {
                        if (addActivityCtrl.activityObj.description.search('<img') > 0 && addActivityCtrl.activityObj.description.search('/sdm/images') > 0) {
                            addActivityCtrl.activityObj.description = addActivityCtrl.activityObj.description.replace(/\/sdm\/images/, '../images');
                        }
                        if (addActivityCtrl.activityObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                            addActivityCtrl.activityObj.description = addActivityCtrl.activityObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                    }
                    if (addActivityCtrl.activityObj.supportingActivities) {
                        if (addActivityCtrl.activityObj.supportingActivities.search('<img') > 0 && addActivityCtrl.activityObj.supportingActivities.search('/sdm/images') > 0) {
                            addActivityCtrl.activityObj.supportingActivities = addActivityCtrl.activityObj.supportingActivities.replace(/\/sdm\/images/, '../images');
                        }
                        if (addActivityCtrl.activityObj.supportingActivities.search('/sdm/activityContent/activityDetail.html') > 0) {
                            addActivityCtrl.activityObj.supportingActivities = addActivityCtrl.activityObj.supportingActivities.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                    }
                    if (addActivityCtrl.activityObj.deliverables) {
                        if (addActivityCtrl.activityObj.deliverables.search('<img') > 0 && addActivityCtrl.activityObj.deliverables.search('/sdm/images') > 0) {
                            addActivityCtrl.activityObj.deliverables = addActivityCtrl.activityObj.deliverables.replace(/\/sdm\/images/, '../images');
                        }
                        if (addActivityCtrl.activityObj.deliverables.search('/sdm/activityContent/activityDetail.html') > 0) {
                            addActivityCtrl.activityObj.deliverables = addActivityCtrl.activityObj.deliverables.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }
                    }
                    if (addActivityCtrl.activityObj.toolsAndGuidance) {
                        if (addActivityCtrl.activityObj.toolsAndGuidance.search('<img') > 0 && addActivityCtrl.activityObj.toolsAndGuidance.search('/sdm/images') > 0) {
                            addActivityCtrl.activityObj.toolsAndGuidance = addActivityCtrl.activityObj.toolsAndGuidance.replace(/\/sdm\/images/, '../images');
                        }
                        if (addActivityCtrl.activityObj.toolsAndGuidance.search('/sdm/activityContent/activityDetail.html') > 0) {
                            addActivityCtrl.activityObj.toolsAndGuidance = addActivityCtrl.activityObj.toolsAndGuidance.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }

                    }
                    if (addActivityCtrl.activityObj.tipsAndTechniques) {
                        if (addActivityCtrl.activityObj.tipsAndTechniques.search('<img') > 0 && addActivityCtrl.activityObj.tipsAndTechniques.search('/sdm/images') > 0) {
                            addActivityCtrl.activityObj.tipsAndTechniques = addActivityCtrl.activityObj.tipsAndTechniques.replace(/\/sdm\/images/, '../images');
                        }
                        if (addActivityCtrl.activityObj.tipsAndTechniques.search('/sdm/activityContent/activityDetail.html') > 0) {
                            addActivityCtrl.activityObj.tipsAndTechniques = addActivityCtrl.activityObj.tipsAndTechniques.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                        }

                    }
                    if (addActivityCtrl.activityObj.activityTasks && addActivityCtrl.activityObj.activityTasks.length) {
                        addActivityCtrl.activityObj.activityTasks.forEach(function (taskObj) {
                            if (taskObj.description == undefined) taskObj.description = '';
                            if (taskObj.name.search('<img') >= 0 && taskObj.name.search('/sdm/images') >= 0) {
                                taskObj.name = taskObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (taskObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                                taskObj.name = taskObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }
                            if (taskObj.description.search('<img') >= 0 && taskObj.description.search('/sdm/images') >= 0) {
                                taskObj.description = taskObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (taskObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                                taskObj.description = taskObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }


                        })
                    }
                    if (addActivityCtrl.activityObj.entryActivityCriteria && addActivityCtrl.activityObj.entryActivityCriteria.length) {
                        addActivityCtrl.activityObj.entryActivityCriteria.forEach(function (entryCriteriaObj) {
                            if (entryCriteriaObj.description == undefined) entryCriteriaObj.description = '';
                            if (entryCriteriaObj.name.search('<img') >= 0 && entryCriteriaObj.name.search('/sdm/images') >= 0) {
                                entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (entryCriteriaObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                                entryCriteriaObj.name = entryCriteriaObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }
                            if (entryCriteriaObj.description.search('<img') >= 0 && entryCriteriaObj.description.search('/sdm/images') >= 0) {
                                entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (entryCriteriaObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                                entryCriteriaObj.description = entryCriteriaObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }

                        })
                    }
                    if (addActivityCtrl.activityObj.exitActivityCriteria && addActivityCtrl.activityObj.exitActivityCriteria.length) {
                        addActivityCtrl.activityObj.exitActivityCriteria.forEach(function (exitCriteriaObj) {
                            if (exitCriteriaObj.description == undefined) exitCriteriaObj.description = '';
                            if (exitCriteriaObj.name.search('<img') >= 0 && exitCriteriaObj.name.search('/sdm/images') >= 0) {
                                exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (exitCriteriaObj.name.search('/sdm/activityContent/activityDetail.html') > 0) {
                                exitCriteriaObj.name = exitCriteriaObj.name.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }
                            if (exitCriteriaObj.description.search('<img') >= 0 && exitCriteriaObj.description.search('/sdm/images') >= 0) {
                                exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('/sdm/images', 'g'), '../images');
                            }
                            if (exitCriteriaObj.description.search('/sdm/activityContent/activityDetail.html') > 0) {
                                exitCriteriaObj.description = exitCriteriaObj.description.replace(new RegExp('/sdm/activityContent/activityDetail.html', 'g'), '../activityContent/activityDetail.html');
                            }

                        })
                    }

                    if ((result) || addActivityCtrl.activityObj['topicId'] === undefined || addActivityCtrl.activityObj['topicId'] === null || addActivityCtrl.activityObj['topicId'] === 0) {
                        addActivityCtrl.activityObj.sequence = addActivityCtrl.activityObj.sequence ? addActivityCtrl.activityObj.sequence : 0;
                        addActivityCtrl.activityObj.groupId = addActivityCtrl.activityObj.groupId ? addActivityCtrl.activityObj.groupId : 0;
                        addActivityCtrl.activityObj.topicId = addActivityCtrl.activityObj.topicId ? addActivityCtrl.activityObj.topicId : 0;
                        var filterComplexityId = addActivityCtrl.activityObj.copyToComplexityIds && addActivityCtrl.activityObj.copyToComplexityIds.filter(function (filterObj) {
                            return filterObj === addActivityCtrl.activityObj.complexityId;
                        })

                        if (filterComplexityId) {
                            if (filterComplexityId.length === 0) {
                                if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                                    adminActivityService.addActivity(addActivityCtrl.activityObj).success(function (response) {
                                        if (response.status) {
                                            alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_ADDED);
                                            $state.go('AdminMain.administration.manageActivities', {}, { reload: true });
                                        }
                                        else {
                                            if (response.errorMsg) {
                                                activityCtrl.activityObj = response;
                                                alerting.addAlert('danger', response.errorMsg);
                                            }
                                        }
                                    });
                                }
                                else if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                                    adminActivityService.editActivity(addActivityCtrl.activityObj).success(function (response) {
                                        if (response.status) {
                                            alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_UPDATED);
                                            $state.go('AdminMain.administration.manageActivities', {}, { reload: true });
                                        }
                                        else {
                                            if (response.errorMsg) {
                                                addActivityCtrl.activityObj = response;
                                                alerting.addAlert('danger', response.errorMsg);
                                            }
                                        }
                                    });
                                }
                            }
                            else {
                                filterComplexityId = addActivityCtrl.complexityIdList.filter(function (filterObj) {
                                    return filterObj.id === addActivityCtrl.activityObj.complexityId;
                                })
                                alerting.addAlert('danger', filterComplexityId[0].name + ' ' + TOAST_MESSAGE.COMPLEXITY_ERR + ' ' + filterComplexityId[0].name);
                            }

                        }
                        else {
                            if ($state.current.name === 'AdminMain.administration.manageActivities.addActivity') {
                                adminActivityService.addActivity(addActivityCtrl.activityObj).success(function (response) {
                                    if (response.status) {
                                        alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_ADDED);
                                        $state.go('AdminMain.administration.manageActivities', {}, { reload: true });
                                    }
                                    else {
                                        if (response.errorMsg) {
                                            addActivityCtrl.activityObj = response;
                                            alerting.addAlert('danger', response.errorMsg);
                                        }
                                    }
                                });
                            }
                            else if ($state.current.name === 'AdminMain.administration.manageActivities.editActivity') {
                                adminActivityService.editActivity(addActivityCtrl.activityObj).success(function (response) {
                                    if (response.status) {
                                        alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_UPDATED);
                                        $state.go('AdminMain.administration.manageActivities', {}, { reload: true });
                                    }
                                    else {
                                        if (response.errorMsg) {
                                            addActivityCtrl.activityObj = response;
                                            alerting.addAlert('danger', response.errorMsg);
                                        }
                                    }
                                });
                            }
                        }

                    }
                    else {
                        alerting.addAlert('danger', TOAST_MESSAGE.ACTIVITY_TOPIC);
                    }
                }


            }
            addActivityCtrl.activityPreview = function () {
                if (addActivityCtrl.activityObj) {
                    var result = addActivityCtrl.activityObj.activityPhaseIds ? addActivityCtrl.activityObj.activityPhaseIds.join('').toString().search('-1') < 0 ? addActivityCtrl.activityObj.activityPhaseIds.length === 0 ? true : false : true : true;
                    if ((result) || addActivityCtrl.activityObj['topicId'] === undefined || addActivityCtrl.activityObj['topicId'] === null || addActivityCtrl.activityObj['topicId'] === 0) {
                        $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css', 'components/common/filters/trustAsHtmlFilter.js']);
                        var modalInstance = $uibModal.open({
                            templateUrl: 'components/AdminModule/addActivity/activity-preview.html',
                            controller: 'activityPreviewCtrl',
                            size: 'lg',
                            aria: 'activity preview',
                            resolve: {
                                previewObj: function () {
                                    return addActivityCtrl;
                                }
                            }
                        });
                    }
                    else {
                        alerting.addAlert('danger', TOAST_MESSAGE.ACTIVITY_TOPIC);
                    }
                }
            }
            addActivityCtrl.handleRedirect = function () {
                //$state.go('AdminMain.administration.manageActivities', { reload: true });
                $state.go("AdminMain.administration.manageActivities", {}, { reload: "AdminMain.administration.manageActivities" })
            }
            addActivityCtrl.deleteComplexity = function () {
                $ocLazyLoad.load('components/common/commoncss/modal.css');
                var modalInstance = $uibModal.open({
                    templateUrl: 'components/common/modals/complexity-template.html',
                    controller: 'deleteComplexityActivityCtrl',
                    resolve: {
                        selectedItem: function () {
                            return { activityObj: addActivityCtrl.activityObj, projectComplexityList: addActivityCtrl.copyToProjectComplexityList };
                        }
                    }
                });
            }
        });



})();
﻿(function () {
    angular.module('sdmApp')
        .service('AdminTemplateService', function ($http, URLS) {
            this.getTemplates = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminTemplates + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminTemplates + '?pageNumber=1&pageSize=10');
                }

            };
            this.getTemplate = function (data) {
                return (data.complexityId) ? $http.get(URLS.adminTemplates + '?id=' + data.id + '&complexityId=' + data.complexityId + '') : $http.get(URLS.adminTemplates + data.id);
            };
            this.addTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminTemplates, data, config);
            };
            this.editTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminTemplates, data, config);
            };
            this.deleteTemplate = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminTemplates + {}, { params: data }, config);
            };
            this.getComplexity = function () {
                return $http.get(URLS.adminComplexity);
            };
        });
})();
﻿(function () {
    function AdminTemplateCtrl($rootScope, $scope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, AdminTemplateService, alerting, TOAST_MESSAGE) {

        var admintemplatevm = this, selectedlistLength;
        admintemplatevm.$state = $state;
        admintemplatevm.adminTemplates = [];
        admintemplatevm.totalItems = 0;
        admintemplatevm.pageSize = 10;
        admintemplatevm.pagination = {
            current: $state.params.page
        }, mutliDropDownList = [{ listName: 'participating', selectedValue: 0, fieldValue: 'participating' }, { listName: 'responsible', selectedValue: 0, fieldValue: 'responsible' }, { listName: 'accountable', selectedValue: 0, fieldValue: 'accountable' }, { listName: 'adminPhase', selectedValue: 0, fieldValue: 'adminPhase' }],
        admintemplatevm.searchFilter = {
            title: ''
        };

        function getResultsPage() {
            AdminTemplateService.getTemplates({ pageNumber: admintemplatevm.pagination.current, searchValue: encodeURIComponent(admintemplatevm.searchFilter.title) }).success(function (res) {
                admintemplatevm.adminTemplates = res.adminTemplates;
                admintemplatevm.totalItems = res.count;
                admintemplatevm.focusList = res.focus;
                admintemplatevm.typeList = res.type;
                admintemplatevm.phaseList = res.adminPhase;
                admintemplatevm.complexityIdList = res['projectComplexity'];
                admintemplatevm.copyToProjectComplexityList = res['copyToProjectComplexity'];

            });
        }
        AdminTemplateService.getComplexity().success(function (res) {
            admintemplatevm.tabs = res;
        })
        function getTemplateDetails(data) {
            AdminTemplateService.getTemplate(data).success(function (res) {
                admintemplatevm.templateObj = res.adminTemplates[0];
                admintemplatevm.phaseList = res.adminPhase;
                admintemplatevm.focusList = res.focus;
                admintemplatevm.typeList = res.type;
                admintemplatevm.complexityIdList = res['projectComplexity'];
                admintemplatevm.copyToProjectComplexityList = res['copyToProjectComplexity'];
                admintemplatevm.templateObj.templatePhaseIds = [];
                admintemplatevm.phaseList.forEach(function (phaseObj) {
                    if (phaseObj.isSelected) {
                        admintemplatevm.templateObj.templatePhaseIds.push(phaseObj.id)
                    }
                })
            })
        }
        if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates' || admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.addTemplate') {
            getResultsPage();
        }
        $rootScope.$on('updatedResults', function (e, data) {
            admintemplatevm.adminTemplates = data;
        });
        admintemplatevm.changeComplexity = function (complexityId) {
            //admintemplatevm.selectedTabContent = tab;
            if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.editTemplate') {
                getTemplateDetails({ id: admintemplatevm.$state.params.id, complexityId: complexityId })
            }
        }
        admintemplatevm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                admintemplatevm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        admintemplatevm.handleRedirect = function () {
            //$state.go('AdminMain.administration.manageActivities', { reload: true });
            $state.go("AdminMain.administration.manageTemplates", {}, { reload: "AdminMain.administration.manageTemplates" })
        }
        admintemplatevm.searchTemplate = function (title) {
            admintemplatevm.searchFilter.title = title;
            getResultsPage();
        };
        admintemplatevm.submitForm = function () {
            $scope.formSubmitted = true;
            if ($scope.templateForm.$valid) {
                admintemplatevm.templateObj.templateId = admintemplatevm.templateObj.templateId ? admintemplatevm.templateObj.templateId : 0;
                admintemplatevm.templateObj.templatePhaseIds = admintemplatevm.templateObj.templatePhaseIds;
                var filterComplexityId = admintemplatevm.templateObj.copyToComplexityIds && admintemplatevm.templateObj.copyToComplexityIds.filter(function (filterObjId) {
                    return filterObjId === admintemplatevm.templateObj.complexityId;
                })
                if (filterComplexityId) {
                    if (filterComplexityId.length === 0) {
                        if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.addTemplate') {
                            AdminTemplateService.addTemplate(admintemplatevm.templateObj).success(function (response) {
                                if (response.status) {
                                    alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_ADDED);
                                    $state.go('AdminMain.administration.manageTemplates', {}, { reload: true })
                                }
                                else {
                                    if (response.errorMsg) {
                                        //$scope.templateObj = response;
                                        //$scope.templateObj.templatePhaseIds = response.adminPhase;
                                        alerting.addAlert('danger', response.errorMsg);
                                    }
                                }
                            })
                        }
                        else if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.editTemplate') {
                            AdminTemplateService.editTemplate(admintemplatevm.templateObj).success(function (res) {
                                if (res.status) {
                                    alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_UPDATED);
                                    $state.go('AdminMain.administration.manageTemplates', {}, { reload: true });
                                }
                                else {
                                    if (res.errorMsg) {
                                        admintemplatevm.templateObj = res.adminTemplates[0];
                                        admintemplatevm.phaseList = res.adminPhase;
                                        admintemplatevm.templateObj.templatePhaseIds = vm.templateObj.templatePhaseIds;
                                        admintemplatevm.templateObj.focusList = res.focus;
                                        admintemplatevm.templateObj.typeList = res.type;
                                        alerting.addAlert('danger', res.errorMsg);
                                    }
                                }
                            })
                        }
                    }
                    else {
                        filterComplexityId = admintemplatevm.copyToProjectComplexityList.filter(function (filterObj) {
                            return filterObj.id === admintemplatevm.templateObj.complexityId;
                        })
                        alerting.addAlert('danger', filterComplexityId[0].name + ' ' + TOAST_MESSAGE.COMPLEXITY_ERR + ' ' + filterComplexityId[0].name);
                    }
                }
                
                else {
                  
                    if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.addTemplate') {
                        AdminTemplateService.addTemplate(admintemplatevm.templateObj).success(function (response) {
                            if (response.status) {
                                alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_ADDED);
                                $state.go('AdminMain.administration.manageTemplates', {}, { reload: true })
                            }
                            else {
                                if (response.errorMsg) {
                                    //$scope.templateObj = response;
                                    //$scope.templateObj.templatePhaseIds = response.adminPhase;
                                    alerting.addAlert('danger', response.errorMsg);
                                }
                            }
                        })
                    }
                    else if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.editTemplate') {
                        AdminTemplateService.editTemplate(admintemplatevm.templateObj).success(function (res) {
                            if (res.status) {
                                alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_UPDATED);
                                $state.go('AdminMain.administration.manageTemplates', {}, { reload: true });
                            }
                            else {
                                if (res.errorMsg) {
                                    admintemplatevm.templateObj = res.adminTemplates[0];
                                    admintemplatevm.phaseList = res.adminPhase;
                                    admintemplatevm.templateObj.templatePhaseIds = vm.templateObj.templatePhaseIds;
                                    admintemplatevm.templateObj.focusList = res.focus;
                                    admintemplatevm.templateObj.typeList = res.type;
                                    alerting.addAlert('danger', res.errorMsg);
                                }
                            }
                        })
                    }
                }

            }
        }
        admintemplatevm.DeleteConfirm = function (template) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteTemplateCtrl',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
        };
        if (admintemplatevm.$state.current.name === 'AdminMain.administration.manageTemplates.editTemplate') {
            getTemplateDetails({ id: admintemplatevm.$state.params.id });
        }
        admintemplatevm.deleteComplexity = function () {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/complexity-template.html',
                controller: 'deleteComplexityTemplateCtrl',
                resolve: {
                    selectedItem: function () {
                        return { templateObj: admintemplatevm.templateObj, projectComplexityList: admintemplatevm.copyToProjectComplexityList };
                    }
                }
            });
        }
    }
    angular.module('sdmApp')
	.controller('AdminTemplateCtrl', AdminTemplateCtrl)
    .controller('deleteTemplateCtrl', function ($rootScope, $state, $scope, $uibModalInstance, AdminTemplateService, alerting, TOAST_MESSAGE, selectedItem) {

        $scope.getResultsPage = function () {
            AdminTemplateService.getTemplates().success(function (res) {
                if (res.status) {
                    $scope.templates = res.adminTemplates;
                }
                alerting.addAlert('danger', res.errorMsg);
                
            });
        }
        $scope.selectedItem = selectedItem;
        $scope.title = selectedItem.title;


        $scope.deleteItem = function (selectedItem) {
           
            AdminTemplateService.deleteTemplate({ id: selectedItem.id }).success(function (res) {
                //$scope.templates.splice($scope.templates.indexOf(selectedItem), 1);
                alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_DELETED);
                $rootScope.$emit("updatedResults", res.adminTemplates);
                $state.go('AdminMain.administration.manageTemplates', {}, { reload: true });
            });
            $scope.cancel();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })
   .controller('EditTemplateCtrl', function ($scope, $state, $stateParams, AdminTemplateService, alerting, TOAST_MESSAGE) {
       var mutliDropDownList = [{ listName: 'participating', selectedValue: 0, fieldValue: 'participating' }, { listName: 'responsible', selectedValue: 0, fieldValue: 'responsible' }, { listName: 'accountable', selectedValue: 0, fieldValue: 'accountable' }, { listName: 'adminPhase', selectedValue: 0, fieldValue: 'adminPhase' }], selectedlistLength;
       var vm = this;
       var id = $stateParams.id;


       // vm.formData = {};
       vm.editTemplate = function () {
           vm.templateObj.templatePhaseIds = vm.templateObj.templatePhaseIds;
           vm.formSubmitted = true;
           if (vm.templateForm.$valid) {
               AdminTemplateService.editTemplate(vm.templateObj).success(function (res) {
                   if (res.status) {
                       alerting.addAlert('success', TOAST_MESSAGE.TEMPLATE_UPDATED);
                       $state.go('AdminMain.administration.manageTemplates', {}, { reload: true });
                   }
                   else {
                       if (res.errorMsg) {
                           vm.templateObj = res.adminTemplates[0];
                           vm.phaseList = res.adminPhase;
                           vm.templateObj.templatePhaseIds = vm.templateObj.templatePhaseIds;
                           vm.templateObj.focusList = res.focus;
                           vm.templateObj.typeList = res.type;
                           alerting.addAlert('danger', res.errorMsg);
                       }
                   }
               })
           }

       }
   })
   .controller('deleteComplexityTemplateCtrl', function ($rootScope, $state, $scope, $uibModalInstance, AdminTemplateService, alerting, TOAST_MESSAGE, selectedItem) {
       $scope.selectedItem = selectedItem.templateObj;
       $scope.title = selectedItem.templateObj.title;
       $scope.selectedComplexity = selectedItem.projectComplexityList.filter(function (filterObj) {
           return filterObj.id === $scope.selectedItem.complexityId;
       })
       $scope.selectedComplexity = $scope.selectedComplexity[0].name;
       $scope.deleteItem = function (selectedItem) {
           AdminTemplateService.deleteTemplate({ templateId: $scope.selectedItem.templateId, complexityId: $scope.selectedItem.complexityId }).success(function (res) {
               if (res.status) {
                   alerting.addAlert('success', TOAST_MESSAGE.COMPLEXITY_STATUS);
                   $state.reload();
               }
               else {
                   alerting.addAlert('danger', res.errorMsg);
               }
               
           });
           $scope.cancel();
       }
       $scope.cancel = function () {
           $uibModalInstance.dismiss('cancel');
       };
   });
})();
﻿(function () {
    angular.module('sdmApp')
        .service('processService', function ($http, URLS) {
            this.getProcessPage = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminProcessGroups + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminProcessGroups + '?pageNumber=1&pageSize=10');
                }

            };
            this.addProcess = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminProcessGroups, data, config);
            };
            this.getProcess = function (data) {
                return $http.get(URLS.adminProcessGroups + '/' + data);
            };
            this.editProcess = function (data) {
                var config = URLS.AntiforgeryConfig;
               return $http.patch(URLS.adminProcessGroups, data, config);
            };
            this.deleteProcess = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminProcessGroups + '/' + itemId, config);
                //test
           };
        });
})();
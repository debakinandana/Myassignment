﻿(function () {
    function processCtrl($rootScope, $scope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, processService, alerting, TOAST_MESSAGE) {
        var adminProcessvm = this;
        adminProcessvm.$state = $state;
        adminProcessvm.adminProcessGroups = [];
        adminProcessvm.totalItems = 0;
        adminProcessvm.pageSize = 10;
        adminProcessvm.pagination = {
            current: $state.params.page
        };
        adminProcessvm.searchFilter = {
            title: ''
        };

        function getResultsPage() {
            processService.getProcessPage({ pageNumber: adminProcessvm.pagination.current, searchValue: encodeURIComponent(adminProcessvm.searchFilter.title) }).success(function (res) {
                adminProcessvm.adminProcessGroups = res.adminProcessGroups;
                adminProcessvm.totalItems = res.count;
            });
        }
        getResultsPage();

        $rootScope.$on('updatedResults', function (e, data) {
            adminProcessvm.adminProcessGroups = data;
        });

        adminProcessvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminProcessvm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminProcessvm.searchProcess = function (title) {
            adminProcessvm.searchFilter.title = title;
            getResultsPage();
        };
        //adminProcessvm.submitForm = function () {
        //    adminProcessvm.formSubmitted = true;
        //    if ($scope.processForm.$valid) {
        //        processService.addProcess(adminProcessvm.processObj).success(function (response) {
        //            if (response.status) {
        //                if ($state.current.name === "AdminMain.administration.manageProcessGroups.editProcess") {
        //                    alerting.addAlert('success', TOAST_MESSAGE.PROCESS_UPDATED);
        //                }
        //                else {
        //                    alerting.addAlert('success', TOAST_MESSAGE.PROCESS_ADDED);
        //                }
        //                $state.go('AdminMain.administration.manageProcessGroups', {}, { reload: true });
        //            }
        //        })
        //    }
        //}
        adminProcessvm.submitForm = function () {
            adminProcessvm.formSubmitted = true;
            if ($scope.processForm.$valid) {
                if ($state.current.name === 'AdminMain.administration.manageProcessGroups.addProcess') {
                    processService.addProcess(adminProcessvm.processObj).success(function (response) {
                        if (response.status) {
                            alerting.addAlert('success', TOAST_MESSAGE.PROCESS_ADDED);
                            $state.go('AdminMain.administration.manageProcessGroups', {}, { reload: true });
                        }
                        else {
                            if (response.errorMsg) {
                                //adminProcessvm.processObj = response;
                                alerting.addAlert('danger', response.errorMsg);
                            }
                        }
                    });
                }
                else if ($state.current.name === 'AdminMain.administration.manageProcessGroups.editProcess') {
                    processService.editProcess(adminProcessvm.processObj).success(function (response) {
                        if (response.status) {
                            alerting.addAlert('success', TOAST_MESSAGE.PROCESS_UPDATED);
                            $state.go('AdminMain.administration.manageProcessGroups', {}, { reload: true });
                        }
                        else {
                            if (response.errorMsg) {
                                //adminProcessvm.processObj = response;
                                alerting.addAlert('danger', response.errorMsg);
                            }
                        }
                    });
                }
            }
        }

        adminProcessvm.DeleteConfirm = function (role) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteProcessCtrl',
                resolve: {
                    selectedItem: function () {
                        return role;
                    }
                }
            });
        };

        function getProcessDetails(ProcessId) {
            processService.getProcess(ProcessId).success(function (res) {
                if (res) {
                    adminProcessvm.processObj = res.adminProcessGroups[0];
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.manageProcessGroups.editProcess") {

            getProcessDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
		.controller('processCtrl', processCtrl)
    .controller('deleteProcessCtrl', function ($rootScope, $state, $scope, $uibModalInstance, processService, alerting, TOAST_MESSAGE, selectedItem) {

        $scope.getResultsPage = function () {
            processService.getProcessPage().success(function (res) {
                $scope.process = res.adminProcessGroups;
            });
        }
        $scope.selectedProcess = selectedItem;
        $scope.title = selectedItem.name;
        $scope.activityProcessGroupCount = selectedItem.activityProcessGroupCount;
        $scope.deleteItem = function (selectedItem) {
            processService.deleteProcess($scope.selectedProcess.id).success(function (res) {
                if (res.status) {
                    alerting.addAlert('success', TOAST_MESSAGE.PROCESS_DELETED);
                    $rootScope.$emit("updatedResults", res.adminProcessGroups);
                    $state.go('AdminMain.administration.manageProcessGroups', {}, { reload: true });
                }
                else {
                    alerting.addAlert('danger', res.errorMsg);
                }
            });
            $scope.cancel();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    })



})();
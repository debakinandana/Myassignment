﻿(function () {
    angular.module('sdmApp')
        .service('adminWhatsNewService', function ($http, URLS) {
            
            this.updateWhatsNew = function (data) {
                return $http.patch(URLS.adminWhatsNew, data);
            };
            this.getWhatsNew = function (data) {
                return (data) ? $http.get(URLS.adminWhatsNew + '/' + data) : $http.get(URLS.adminWhatsNew);
            };
            
        });
})();
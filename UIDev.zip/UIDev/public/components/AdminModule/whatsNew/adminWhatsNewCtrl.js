﻿(function () {
    function adminWhatsNewCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminWhatsNewService, alerting, TOAST_MESSAGE, $scope) {
        var adminWhatsNewvm = this;
        adminWhatsNewvm.tinymceOptions = {
            selector: "textarea",
            menubar: false,
            statusbar: false,
            content_css: 'components/common/commoncss/tinymce.css',
            plugins: ['advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools', 'codesample'],
            toolbar: 'undo redo | insert | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image | code | codesample  | forecolor | backcolor',
            custom_undo_redo_levels: 10,
            textcolor_rows: "4",
            browser_spellcheck: true,
            table_default_attributes: {
                'border': 1, 'width': 300, 'height': 100, 'cellspacing': 0
            },
            contextmenu: 'inserttable | cell row column deletetable',
            extended_valid_elements: ['script[src|type|language]', 'img[class|src|alt|title]', 'div[rel|class|id]'],
            codesample_languages: [
        { text: 'HTML/XML', value: 'markup' },
        { text: 'JavaScript', value: 'javascript' }
            ]
        };
        adminWhatsNewvm.$state = $state;
        adminWhatsNewvm.solutionMethod = [];
        adminWhatsNewvm.totalItems = 0;
        adminWhatsNewvm.pageSize = 10;
        adminWhatsNewvm.pagination = {
            current: $state.params.page
        };

        adminWhatsNewvm.searchFilter = {
            title: ''
        };

        function getResultsPage() {
            adminWhatsNewvm.formSubmitted = false;
            adminWhatsNewService.getWhatsNew().success(function (res) {
                adminWhatsNewvm.whatsNewObj = res;
            });
        }
        getResultsPage();
        adminWhatsNewvm.submitForm = function () {
            adminWhatsNewvm.formSubmitted = true;
            if ($scope.whatsNewForm.$valid) {
                for (var keys in adminWhatsNewvm.whatsNewObj) {
                    if (keys === "sectionHeader1" || keys === "sectionHeader2" || keys === "sectionHeader3") {

                        adminWhatsNewvm.whatsNewObj[keys] = adminWhatsNewvm.whatsNewObj[keys].replace(/<(?:.|\n)*?>/gm, '');
                    }
                }
                adminWhatsNewService.updateWhatsNew(adminWhatsNewvm.whatsNewObj).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.WhatsNew_Msg);
                        $state.go('AdminMain.administration')
                    }
                })
            }

        }
        adminWhatsNewvm.showPreviewDialog = function (whatsNewObj) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/whats-preview.html',
                controller: 'previewCtrl',
                aria: 'rating',
                size: 'sm',
                resolve: {
                    resultObj: function () {
                        return whatsNewObj;
                    }
                }
            });
        }

    }
    function previewCtrl($scope, $uibModalInstance, $ocLazyLoad, $uibModal, resultObj) {
        //$scope.whatsNewObj = selectedItem;
        
        $scope.textObj = resultObj;
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        }
    }
    angular.module('sdmApp').controller('previewCtrl', previewCtrl).controller('adminWhatsNewCtrl', adminWhatsNewCtrl);
})();
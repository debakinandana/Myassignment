﻿(function () {
    angular.module('sdmApp')
        .service('manageActivityGridsService', function ($http, URLS) {
            this.getDomains = function () {
                return $http.get(URLS.adminActivityDomain);
            };
            this.getActivities = function (data) {

                return data.pageNumber ? $http.get(URLS.admindActivityGrid + '?methodId=' + data.methodId + '&complexityId=' + data.complexityId + '&pageNumber=' + data.pageNumber + '&phaseId=' + data.phaseId + '') : $http.get(URLS.admindActivityGrid + '?methodId=' + data.methodId + '&complexityId=' + data.complexityId + '');
            };
            this.updateActvitiyGrid = function (data) {
                return $http.patch(URLS.admindActivityGrid , data);
            };
            this.getComplexities = function () {
                return $http.get(URLS.adminComplexity);
            }
            this.downloadExcel =function(){
                return $http.get(URLS.adminDownloadExcel);
            }
            this.generateJson = function (optionType, data) {
                return optionType === 1 ? $http.patch(URLS.adminFileToJson, data, {
                    withCredentials: true,
                    headers: { 'Content-Type': undefined },
                    transformRequest: angular.identity
                }) : $http.get(URLS.adminToJson + '?methodId=' + data.methodId + '&code=' + data.code)
            }
        });
})();
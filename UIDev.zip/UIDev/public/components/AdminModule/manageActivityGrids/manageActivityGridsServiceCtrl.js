﻿(function () {
    function manageActivityGridsCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, manageActivityGridsService, alerting, TOAST_MESSAGE, $scope, URLS, $http) {
        var manageActivityGridsvm = this;
        manageActivityGridsvm.$state = $state;
        manageActivityGridsvm.fileChoosen = false;
        manageActivityGridsvm.gridObj = {};
        var fd;
        manageActivityGridsvm.phaseListObj = {
            phases: []
        };
        manageActivityGridsvm.status = {
            isopen: false
        };

        // manageActivityGridsvm.complexity = function () {
        // if (complexcityName === "Type 1[ High]") {
        // manageActivityGridsvm.onComplexityType = true;
        // }
        // }
        manageActivityGridsvm.getPhases = function () {


            manageActivityGridsvm.formSubmitted = true;

            if ($scope.gridForm.$valid && manageActivityGridsvm.gridObj.complexityId.length > 0) {
                manageActivityGridsService.getActivities({ methodId: manageActivityGridsvm.gridObj.methodId, complexityId: manageActivityGridsvm.gridObj.complexityId }).success(function (res) {
                    manageActivityGridsvm.phaseListObj = res;
                    if (res.phases.length === 0) {
                        alerting.addAlert('info', 'No Data Found');
                    }
                })
            }
        }
        function getBrowserType() {
            var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
            var isFirefox = typeof InstallTrigger !== 'undefined';
            var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            var isEdge = !isIE && !!window.StyleMedia;
            var isChrome = !!window.chrome && !!window.chrome.webstore;
            var isBlink = (isChrome || isOpera) && !!window.CSS;
            return { isIE: isIE, isChrome: isChrome, isEdge: isEdge }
        }
        manageActivityGridsvm.hideError = function () {
            $('.file-error-container').addClass('collapse');
            $('.file-upload-error').addClass('collapse');
            manageActivityGridsvm.formSubmitted = false;
            $('#exampleFormControlFile1').val(null);
            $('#fileName').text('No File Choosen');
            manageActivityGridsvm.fileChoosen = false;
        }
        manageActivityGridsService.getDomains().success(function (res) {
            if (res) {
                manageActivityGridsvm.domains = res;
            }
        })
        manageActivityGridsvm.generateJson = function (optionType) {
            var complexityList = [];
            manageActivityGridsvm.generateJsonClick = true;

            if (manageActivityGridsvm.gridObj.complexityId.length) {
                manageActivityGridsvm.gridObj.complexityId.forEach(function (complexityId) {
                    manageActivityGridsvm.complexityList.map(function (complexityObj) {
                        if (complexityObj.id === complexityId) {
                            complexityList.push(complexityObj.code);
                        }
                    })
                })
            }
            if (parseInt(optionType, 10) === 1) {
                if (manageActivityGridsvm.fileChoosen) {
                    manageActivityGridsService.generateJson(parseInt(optionType, 10), fd).success(function (res) {
                        if (res.status) {
                            var browserObject = getBrowserType();
                            // window.open(res.fileLocation)
                            var blobObject = new Blob([browserObject.isIE ? res.fileData : res.fileData]);
                            if (window.navigator.msSaveBlob) {
                                window.navigator.msSaveBlob(blobObject, '' + res.fileName + '.json');
                            }
                            else {
                                $('#downloadLink').attr('href', window.URL.createObjectURL(blobObject)).attr('download', res.fileName + '.json');
                                document.getElementById('downloadLink').click();
                            }

                        }
                        else {
                            alerting.addAlert('danger', res.errorMsg);
                        }
                    })
                }
                else {
                    $('.file-upload-error').removeClass('collapse');
                }
            }
            else if (parseInt(optionType, 10) === 2) {
                manageActivityGridsvm.formSubmitted = true;
                if (manageActivityGridsvm.gridObj.domainId && manageActivityGridsvm.gridObj.methodId && manageActivityGridsvm.gridObj.complexityId.length) {
                    manageActivityGridsService.generateJson(parseInt(optionType, 10), { methodId: manageActivityGridsvm.gridObj.methodId, code: complexityList.length ? complexityList : null }).success(function (res) {
                        if (res.status) {
                            var browserObject = getBrowserType();
                            // window.open(res.fileLocation)
                            var blobObject = new Blob([browserObject.isIE ? res.fileData : res.fileData]);
                            if (window.navigator.msSaveOrOpenBlob) {
                                window.navigator.msSaveOrOpenBlob(blobObject, '' + res.fileName + '.json');
                            }
                            else {
                                $('#downloadLink').attr('href', window.URL.createObjectURL(blobObject)).attr('download', res.fileName + '.json');
                                document.getElementById('downloadLink').click();
                            }

                        }
                        else {
                            alerting.addAlert('danger', res.errorMsg);
                        }
                    })
                }

            }

        }
        manageActivityGridsvm.fileNameChanged = function (e) {
            $('.file-error-container,.file-upload-error').addClass('collapse');
            $('#fileName').text('No File Choosen');
            if (e.target.files.length) {
                var fileType = e.target.files[0];
                fd = new FormData();
                $('#fileValue').val(fileType.name);
                fileType = fileType.name.split('.');
                if (fileType[fileType.length - 1] === 'xlsx' || fileType[fileType.length - 1] === 'xls') {
                    manageActivityGridsvm.showFileError = false;
                    fd.append('fileLocation', e.target.files[0]);
                    $('#fileName').text(e.target.files[0].name);
                    manageActivityGridsvm.fileChoosen = true;
                    $('#generateJsonBtn').removeAttr('disbaled');
                }
                else {
                    if ($('.file-error-container').hasClass('collapse')) {
                        $('.file-error-container').removeClass('collapse');


                        manageActivityGridsvm.fileChoosen = false;
                    }
                    $('#fileValue').val(null);
                    e.currentTarget.value = null;
                    e.stopPropagation();

                }
            }
        }

        manageActivityGridsvm.loadMethods = function (domainId) {
            if (!domainId) {
                manageActivityGridsvm.methods = [];
            }
            else {
                manageActivityGridsvm.methods = manageActivityGridsvm.domains.filter(function (domainObj) {
                    return domainObj.id === parseInt(domainId, 10);
                })
                manageActivityGridsvm.methods = manageActivityGridsvm.methods[0].methods;
                manageActivityGridsvm.gridObj.methodId = "";
            }
        }
        manageActivityGridsService.getComplexities().success(function (res) {
            manageActivityGridsvm.complexityList = res.projectComplexity;
        });
        manageActivityGridsvm.downloadExcel = function (obj) {

            $http.get(location.origin + '/api/CheckSiteRefreshing').success(function (response) {
                manageActivityGridsvm.formSubmitted = true;
                if (response.siteRefresh) {
                    alerting.addAlert('danger', 'We are making some content updates and the site is being refreshed. Please try again after 5 minutes');
                }
                else {
                    if (!manageActivityGridsvm.gridObj.domainId && !manageActivityGridsvm.gridObj.methodId && manageActivityGridsvm.gridObj.complexityId.length === 0) {
                        manageActivityGridsvm.formSubmitted = false;
                        window.open(URLS.adminDownloadExcel + encodeURI('?domainId=' + parseInt(obj.domainId ? obj.domainId : 0, 10) + '&methodId=' + parseInt(obj.methodId ? obj.methodId : 0, 10) + '&methodName=' + '&complexityId=' + 0 + ''));
                    }
                    if (manageActivityGridsvm.gridObj.domainId && manageActivityGridsvm.gridObj.methodId && manageActivityGridsvm.gridObj.complexityId.length > 0) {
                        window.open(URLS.adminDownloadExcel + encodeURI('?domainId=' + parseInt(obj.domainId ? obj.domainId : 0, 10) + '&methodId=' + parseInt(obj.methodId ? obj.methodId : 0, 10) + '&methodName='  + '&complexityId=' + manageActivityGridsvm.gridObj.complexityId + ''));
                    }
                }
            })


        }
        manageActivityGridsvm.submitForm = function (gridListObj) {
            var tempObj = null;
            tempObj = manageActivityGridsvm.phaseListObj.phases[gridListObj];
            manageActivityGridsvm.phaseListObj.phases = [];
            manageActivityGridsvm.phaseListObj.phases.push(tempObj);
            if ($scope.gridForm.$valid) {
                manageActivityGridsService.updateActvitiyGrid(new Object(manageActivityGridsvm.phaseListObj)).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_GRID_STATUS);
                        $state.go('AdminMain.administration');
                    }
                    else {
                        alerting.addAlert('danger', res.errorMsg);
                    }
                })
            }

        }

    }


    angular.module('sdmApp').controller('manageActivityGridsCtrl', manageActivityGridsCtrl);
})();
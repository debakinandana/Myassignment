﻿(function () {
    function adminTopicCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, adminTopicService, alerting, TOAST_MESSAGE, $scope) {
        var adminTopicvm = this, tempVersion = null;
        adminTopicvm.$state = $state;
        adminTopicvm.adminTopics = [];
        adminTopicvm.totalItems = 0;
        adminTopicvm.pageSize = 10;
        //$scope.selectedVersion = "1.00";
        adminTopicvm.pagination = {
            current: $state.params.page
        };
        adminTopicvm.searchFilter = {
            title: ''
        };
        adminTopicvm.tinymceOptions = {
            selector: "textarea",
            menubar: false,
            statusbar: false,
            content_css: 'components/common/commoncss/tinymce.css',
            plugins: ['advlist autolink lists link image charmap print preview hr anchor pagebreak',
                'searchreplace wordcount visualblocks visualchars code fullscreen',
                'insertdatetime media nonbreaking save table contextmenu directionality',
                'emoticons template paste textcolor colorpicker textpattern imagetools', 'codesample'],
            toolbar: 'undo redo | insert | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table | link image | code | codesample | forecolor | backcolor',
            custom_undo_redo_levels: 10,
            textcolor_rows: "4",
            browser_spellcheck: true,
            table_default_attributes: {
                'border': 1, 'width': 300, 'height': 100, 'cellspacing': 0
            },
            contextmenu: 'inserttable | cell row column deletetable',
            extended_valid_elements: ['script[src|type|language]', 'img[class|src|alt|title|width|height|style]', 'div[rel|class|id|style]', 'a[onclick|href|ng-click|class|target|style|title]'],
            codesample_languages: [
                { text: 'HTML/XML', value: 'markup' },
                { text: 'JavaScript', value: 'javascript' }
            ],
            allow_script_urls: true,
            convert_urls: false
        };
        function getResultsPage() {
            adminTopicService.getTopics({ pageNumber: adminTopicvm.pagination.current, searchValue: encodeURIComponent(adminTopicvm.searchFilter.title) }).success(function (res) {
                //adminTopicvm.topicObj = {};
                if ($state.current.name === 'AdminMain.administration.manageTopics.addTopic') {
                    adminTopicvm.topicObj = {};
                    adminTopicvm.topicObj.selectedVersion = "1.00";
                    $scope.selectedVersion = true;
                    $scope.disableSubmit = false;
                    $scope.disableTopicMajor = true;
                    $scope.disableTopicMinor = true;
                    adminTopicvm.topicObj.isVisible = true;
                    adminTopicvm.adminCategory = res.adminCategory;
                }
                else {
                    $scope.disableSubmit = false;
                    adminTopicvm.adminTopics = res.adminTopics;
                    adminTopicvm.totalItems = res.count;
                    adminTopicvm.adminCategory = res.adminCategory;
                }
                //else {
                //getTopicDetails();

                //$scope.selectedVersion = false;
                //tempVersion = adminTopicvm.topicObj.selectedVersion;
                // }
            });

        }
        getResultsPage();

        $rootScope.$on('updatedResults', function (e, data) {
            adminTopicvm.adminTopics = data;
        });

        adminTopicvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                adminTopicvm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        adminTopicvm.searchTopic = function (title) {
            adminTopicvm.searchFilter.title = title;
            getResultsPage();
        };


        function getAuditVersionRecord(data) {
            adminTopicvm.topicObj = {};

            adminTopicService.getTopicVersions(data).success(function (response) {

                adminTopicvm.topicObj = response.adminTopics;
                tempVersion = adminTopicvm.topicObj.selectedVersion;
                var versionList = new Array();
                for (var i = 0; i < adminTopicvm.topicObj.topicVersionList.topicVersions.length; i++) {
                    versionList.push(parseFloat(adminTopicvm.topicObj.topicVersionList.topicVersions[i].versionNumber));
                }

                var maxVersion = Math.max.apply(null, versionList);
                var latestVersion = parseFloat(maxVersion).toFixed(2);
                if (adminTopicvm.topicObj.selectedVersion != latestVersion) {
                    //adminTopicvm.topicObj.topicVersionList = response.topicVersions;
                    $scope.disableSubmit = true;
                    $scope.disableTopicMajor = true;
                    $scope.disableTopicMinor = true;
                }
                else {
                    $scope.disableSubmit = false;
                    $scope.disableTopicMajor = false;
                    $scope.disableTopicMinor = false;
                }
                //updateTopicDetails();
                //getResultsPage();
            })
        }

        adminTopicvm.updateVersion = function (versionType) {

            adminTopicvm.topicObj.topicVersion = adminTopicvm.topicObj.selectedVersion ? tempVersion : '1.00';


            if (versionType && versionType === 'major') {

                adminTopicvm.topicObj.topicVersion = parseInt(adminTopicvm.topicObj.topicVersion, 10);
                adminTopicvm.topicObj.topicVersion += 1;
                adminTopicvm.topicObj.topicVersion = adminTopicvm.topicObj.topicVersion.toFixed(2);
                //adminTopicvm.disableOnSelectPrveiousVersion = false;
                //adminTopicvm.disablePrveiousVersion = false;
            }
            else if (versionType && versionType === 'minor') {
                adminTopicvm.topicObj.topicVersion = parseFloat(adminTopicvm.topicObj.topicVersion) + 0.01;
                adminTopicvm.topicObj.topicVersion = adminTopicvm.topicObj.topicVersion.toFixed(2);
                //adminTopicvm.disableOnSelectPrveiousVersion = false;
                //adminTopicvm.disablePrveiousVersion = false;

            }

            if (versionType && versionType === 'nochange') {

            }
        }



        adminTopicvm.changeVersion = function (complexityId, artifactTypeId, artifactActualId, versionNumber) {
            if ($state.current.name === 'AdminMain.administration.manageTopics.editTopic') {
                getAuditVersionRecord({ artifactTypeId: 10, artifactActualId: adminTopicvm.topicObj.id, versionNumber: adminTopicvm.topicObj.selectedVersion, complexityId: 0 });
                //var versionList = new Array();
                //for (var i = 0; i < adminTopicvm.topicObj.topicVersionList.topicVersions.length; i++) {
                //    versionList.push(parseFloat(adminTopicvm.topicObj.topicVersionList.topicVersions[i].versionNumber));
                //}

                //var maxVersion = Math.max.apply(null, versionList);
                //var latestVersion = parseFloat(maxVersion).toFixed(2);
                //if (adminTopicvm.topicObj.selectedVersion != latestVersion) {
                //    adminTopicvm.topicObj.isNoChange = false;
                //    // adminTopicvm.disableSubmit = false;
                //    $scope.disableTopicMajor = true;
                //    $scope.disableTopicMinor = true;


                //}
                //else {
                //    // adminTopicvm.disableSubmit = true;
                //    $scope.disableTopicMajor = false;
                //    $scope.disableTopicMinor = false;
                //   // adminTopicvm.disableTopicNoChange = false;
                //    adminTopicvm.topicObj.isNoChange = true;
                //}

            }
        }


        function updateTopicDetails(response) {


            if ($state.current.name === 'AdminMain.administration.manageTopics.addTopic') {

                $scope.selectedVersion = true;

                adminTopicvm.disableTopicMajor = true;
                adminTopicvm.disableTopicMinor = true;
                adminTopicvm.disableTopicNoChange = true;
                adminTopicvm.topicObj.selectedVersion = "1.00";
            }

            else if ($state.current.name === 'AdminMain.administration.manageTopics.editTopic') {
                //adminTopicvm = response.adminTopics;
                adminTopicvm.adminTopics = response.adminTopics[0];
                adminTopicvm.name = response.adminTopics.name;
                tempVersion = adminTopicvm.topicObj.selectedVersion;
                //getTopicDetails();
                // getTopicDetails();
                // getResultsPage();
                adminTopicvm.id = parseInt($state.params.id);
                //tempVersion = adminTopicvm.topicObj.versionNumber;
                //getResultsPage();
                //getTopicDetails();
                //getTopicDetails($state.params.id)
                //adminTopicvm.topicObj = res.adminTopics[0];

                // adminTopicvm.topicObj = parseInt($state.params.id);

            }

        }


        adminTopicvm.DeleteConfirm = function (topic) {
            $ocLazyLoad.load('components/common/commoncss/modal.css');
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/delete-confirmation.html',
                controller: 'deleteTopicCtrl',
                resolve: {
                    selectedItem: function () {
                        return topic;
                    }
                }
            });
        };
        adminTopicvm.topicPreview = function () {
            adminTopicvm.topicObj.topicVersion = adminTopicvm.topicObj.topicVersion ? adminTopicvm.topicObj.topicVersion : adminTopicvm.topicObj.selectedVersion ? adminTopicvm.topicObj.selectedVersion : '1.00';
            if (adminTopicvm.topicObj) {
                $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css', 'components/common/filters/trustAsHtmlFilter.js']);

                var modalInstance = $uibModal.open({
                    templateUrl: 'components/AdminModule/addTopics/topic-preview.html',
                    controller: 'topicPreviewCtrl',
                    aria: 'topic preview',
                    size: 'lg',
                    resolve: {
                        previewObj: function () {

                            //adminTopicvm.topicObj.topicVersion = "1.00";

                            return adminTopicvm;
                        }

                    }
                });
            }

        }
        adminTopicvm.submitForm = function () {
            adminTopicvm.formSubmitted = true;
            adminTopicvm.topicObj.topicVersion = adminTopicvm.topicObj.topicVersion ? adminTopicvm.topicObj.topicVersion : adminTopicvm.topicObj.selectedVersion ? adminTopicvm.topicObj.selectedVersion : '1.00';
            console.log($scope, adminTopicvm.topicForm)
            if ($scope.topicForm.$valid) {
                adminTopicService.addTopic(adminTopicvm.topicObj).success(function (response) {
                    if (response.status) {

                        //adminTopicvm.topicObj.selectedVersion="1.00";
                        if ($state.current.name === "AdminMain.administration.manageTopics.editTopic") {
                            alerting.addAlert('success', TOAST_MESSAGE.TOPIC_UPDATED);
                        }
                        else {
                            alerting.addAlert('success', TOAST_MESSAGE.TOPIC_ADDED);
                        }
                        $state.go('AdminMain.administration.manageTopics', {}, { reload: true })
                    }
                })
            }
        }
        function getTopicDetails(topicId) {
            adminTopicvm.topicObj = {};
            adminTopicService.getTopic(topicId).success(function (res) {
                if (res) {
                    //if ($state.current.name === 'AdminMain.administration.manageTopics.addTopic') {
                    //    adminTopicvm.topicObj.selectedVersion = "1.00";
                    //    $scope.selectedVersion = true;
                    //}
                    // else if ($state.current.name === 'AdminMain.administration.manageTopics.editTopic') {
                    adminTopicvm.topicObj = res.adminTopics[0];
                    //getResultsPage();
                    adminTopicvm.adminCategory = res.adminCategory;
                    //}
                    // adminTopicvm.topicObj = res.adminTopics[0];
                    //adminTopicvm.adminCategory = res.adminCategory;
                    tempVersion = adminTopicvm.topicObj.selectedVersion;
                }
            })
        }
        if ($state.current.name === "AdminMain.administration.manageTopics.editTopic") {

            getTopicDetails($state.params.id)
        }
    }
    angular.module('sdmApp')
        .controller('adminTopicCtrl', adminTopicCtrl)
        .controller('deleteTopicCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminTopicService, alerting, TOAST_MESSAGE, selectedItem) {
            $scope.getResultsPage = function () {
                adminTopicService.getTopics().success(function (res) {
                    $scope.topics = res.adminTopics;
                });
            }

            $scope.selectedTopic = selectedItem;
            $scope.title = selectedItem.name;
            $scope.deleteItem = function (selectedItem) {

                adminTopicService.deleteTopic($scope.selectedTopic.id).success(function (res) {
                    alerting.addAlert('success', TOAST_MESSAGE.TOPIC_DELETED);
                    $rootScope.$emit("updatedResults", res.adminTopics);
                    $state.go('AdminMain.administration.manageTopics', {}, { reload: true });
                });
                $scope.cancel();
            }
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        }).controller('topicPreviewCtrl', function ($rootScope, $state, $scope, $uibModalInstance, adminTopicService, alerting, TOAST_MESSAGE, previewObj, $location, $anchorScroll) {
            adminTopicService.setTopicState(previewObj.topicObj);
            $scope.haveActivity = false;
            $scope.previewObjData = previewObj;
            $scope.previewObj = previewObj.topicObj;
            $scope.previewObj.hasVisio = false;
            if ($state.current.name === 'AdminMain.administration.manageTopics.addTopic') {
                previewObj.topicObj.topicVersion = "1.00";
                var date = new Date();
                var dd = date.getDate();
                var mm = date.getMonth() + 1;
                var yyyy = date.getFullYear();
                //if (dd < 10) {
                //    dd = '0' + dd;
                //}

                //if (mm < 10) {
                //    mm = '0' + mm;
                //}
                var newDate = mm + "/" + dd + "/" + yyyy;
                previewObj.topicObj.versionModifiedDate = newDate;
            }
            if ($state.current.name === 'AdminMain.administration.manageTopics.editTopic') {
                if (previewObj.topicObj.topicVersion !== previewObj.topicObj.selectedVersion) {
                    var date = new Date();
                    //var datePart = date.match(/\d+/g);
                    var dd = date.getDate();
                    var mm = date.getMonth() + 1;
                    var yyyy = date.getFullYear();
                    //if (dd < 10) {
                    //    dd = '0' + dd;
                    //}

                    //if (mm < 10) {
                    //    mm = '0' + mm;
                    //}
                    var newDate = mm + "/" + dd + "/" + yyyy;
                    previewObj.topicObj.versionModifiedDate = newDate;
                } else if (previewObj.topicObj.topicVersion === previewObj.topicObj.selectedVersion) {
                    var date = previewObj.topicObj.modifiedDate;
                    var datepart = date.match(/\d+/g);
                    var year = datepart[0].substring();
                    var month = datepart[1];
                    var day = datepart[2];
                    var newdate = month + "/" + day + "/" + year;

                    previewObj.topicObj.versionModifiedDate = newdate;
                }
            }
            //$scope.previewObj.topicVersion = "1.00";
            if ((previewObj.topicObj.topicType === "1" || previewObj.topicObj.topicType === 1) && previewObj.topicObj.diagramName.search('Topic:') >= 0) {
                previewObj.topicObj.diagramName = previewObj.topicObj.diagramName.replace(/<p>/, '').trim();
                previewObj.topicObj.diagramName = previewObj.topicObj.diagramName.replace(/<\/p>/, '').trim();
                adminTopicService.getTopics({ pageNumber: 1, searchValue: encodeURIComponent(previewObj.topicObj.diagramName) }).success(function (res) {
                    previewObj.topicObj = res.adminTopics[0];
                    //previewObj.topicObj.topicVersion = "1.00";
                    if (res.adminTopics.length > 0) {
                        if (previewObj.topicObj.visioFilePath.search(location.protocol) <= 0) {
                            if (previewObj.topicObj.visioFilePath.search('.svg') > 0) {
                                $scope.previewObj.visioFilePath = location.protocol + '//' + location.host + previewObj.topicObj.visioFilePath;
                                $scope.previewObj.hasVisio = true;
                                //$scope.previewObj.selectedVersion = "1.00";
                            }
                            else if (previewObj.topicObj.diagramName.search('<img') > 0) {
                                $scope.previewObj.topicObj.diagramName = previewObj.topicObj.diagramName.replace(/images/, '/sdm/images');
                            }

                        }
                    }
                    else {
                        $scope.previewObj.hasVisio = false;
                    }
                });
            }
            else {
                $scope.previewObj.hasVisio = false;
            }


            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
                //previewObj.topicObj.selectedVersion = "1.00";
                //previewObj.topicObj.topicType = previewObj.topicObj ? previewObj.topicObj.topicType ? previewObj.topicObj.topicType.toString():"" : "";
                //previewObj.topicObj = adminTopicService.getTopicState();


            };
            $uibModalInstance.result.then(function () {

            }, function () {
                previewObj.topicObj = adminTopicService.getTopicState();
            });
        });
})();
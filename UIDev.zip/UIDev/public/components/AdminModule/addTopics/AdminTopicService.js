﻿(function () {
    angular.module('sdmApp')
        .service('adminTopicService', function ($http, URLS) {
            var tempObj;
            this.getTopics = function (searchSortPaginateConfig) {
                if (searchSortPaginateConfig) {
                    var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                        serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '';
                    return $http.get(URLS.adminTopics + pageNumber + '&pageSize=10' + serachQuery);
                } else {
                    return $http.get(URLS.adminTopics + '?pageNumber=1&pageSize=10');
                }

            };
            this.addTopic = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.post(URLS.adminTopics, data, config);
            };
            this.getTopic = function (data) {
                return $http.get(URLS.adminTopics+data);
            };
            this.editTopic = function (data) {
                var config = URLS.AntiforgeryConfig;
                return $http.patch(URLS.adminTopics, data, config);
            };
            this.deleteTopic = function (itemId) {
                var config = URLS.AntiforgeryConfig;
                return $http.delete(URLS.adminTopics + itemId, config);
            };
            this.setTopicState = function (param) {
                tempObj = new Object(param);
            }
            this.getTopicState = function () {
                return tempObj;
            }
            this.getTopicVersions = function (data) {

                
                return $http.get(URLS.adminActivityAllVersionsJson + '?complexityId=' + data.complexityId + '&artifactTypeId=' + data.artifactTypeId + '&artifactActualId=' + data.artifactActualId + '&versionNumber=' + data.versionNumber);

            };
        });
})();
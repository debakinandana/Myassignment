﻿(function () {
    function managePlayBooksCtrl( $state, $document, $stateParams, $timeout, managePlayBooksService, alerting, TOAST_MESSAGE) {
        var managePlayBooksvm = this;
        managePlayBooksvm.$state = $state;
        managePlayBooksService.getPlayBooks().success(function (res) {
            managePlayBooksvm.playBookslist = res;
        })
        managePlayBooksvm.addItem = function () {
            managePlayBooksvm.playBookslist.push(new Object({
                title: null,
                fileLocation: null
            }));
        }
        managePlayBooksvm.deleteItem = function (index) {
            managePlayBooksvm.playBookslist.splice(index, 1)
        }
        managePlayBooksvm.submitForm = function () {
            managePlayBooksvm.formSubmitted = true;
            if ($scope.playBookForm.$valid) {
                managePlayBooksService.addPlayBook(managePlayBooksvm.playBookslist).success(function (res) {
                    if (res.status) {
                        alerting.addAlert('success', TOAST_MESSAGE.PLAYBOOK_UPDATE);
                        $state.go('AdminMain.administration');
                    }
                })
            }
            
        }
    }
    
    
    angular.module('sdmApp').controller('managePlayBooksCtrl', managePlayBooksCtrl);
})();
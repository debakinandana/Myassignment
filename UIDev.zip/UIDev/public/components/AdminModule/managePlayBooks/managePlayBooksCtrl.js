﻿(function () {
    function adminWhatsNewCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, managePlayBooksService, alerting, TOAST_MESSAGE, $scope) {
        var managePlayBooksvm = this;
        managePlayBooksvm.$state = $state;
        managePlayBooksvm.playBookslist = [];
        managePlayBooksService.getPlayBooks().success(function (res) {
            managePlayBooksvm.playBookslist = res ? res : [];
        })
        managePlayBooksvm.addItem = function () {
            managePlayBooksvm.playBookslist.push(new Object({
                title: null,
                fileLocation: null
            }));
        }
        managePlayBooksvm.deleteItem = function (index) {
            managePlayBooksvm.playBookslist.splice(index, 1)
        }
        managePlayBooksvm.submitForm = function () {
            managePlayBooksvm.formSubmitted = true;
            var urlIndex = -1;
            var exp = new RegExp('^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$');
            var exp1 = new RegExp('^[^\/]+\/[^\/].*$|^\/[^\/].*$');
            managePlayBooksvm.validUrl = managePlayBooksvm.playBookslist.forEach(function (playbookObj, index) {
                if (!exp.test(playbookObj.fileLocation) && !exp1.test(playbookObj.fileLocation)) {
                    urlIndex = index;
                    return;
                }
            });

            if ($scope.playBookForm.$valid && urlIndex < 0) {
                managePlayBooksService.addPlayBook(managePlayBooksvm.playBookslist).success(function (res) {
                    if (managePlayBooksvm.playBookslist.length >= 0) {
                        alerting.addAlert('success', TOAST_MESSAGE.PLAYBOOK_UPDATE);
                        $state.go('AdminMain.administration')
                    }
                    else {
                        alerting.addAlert('success', res.errorMsg);
                    }
                })
            }
            else {
                if (managePlayBooksvm.playBookslist[urlIndex].title && managePlayBooksvm.playBookslist[urlIndex].fileLocation) {
                    alerting.addAlert('danger', 'Playbook "' + managePlayBooksvm.playBookslist[urlIndex].title + '" url is invalid');
                }

            }

        }
    }


    angular.module('sdmApp').controller('managePlayBooksCtrl', adminWhatsNewCtrl);
})();
(function () {
    function manageRACIGridsCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, manageRACIGridsService, alerting, TOAST_MESSAGE, $scope, URLS, $http) {
        var manageRACIGridsvm = this;
        manageRACIGridsvm.$state = $state;
        manageRACIGridsvm.fileChoosen = false;
        manageRACIGridsvm.gridObj = {};

        manageRACIGridsvm.phaseListObj = {
            phases: []
        };
        manageRACIGridsvm.status = {
            isopen: false
        };

        // manageRACIGridsvm.complexity = function () {
        // if (complexcityName === "Type 1[ High]") {
        // manageRACIGridsvm.onComplexityType = true;
        // }
        // }
        manageRACIGridsvm.getPhases = function () {
            manageRACIGridsvm.formSubmitted = true;
            if ($scope.gridForm.$valid && manageRACIGridsvm.gridObj.complexityId.length > 0) {
                manageRACIGridsService.getActivities({ solutionMethodId: manageRACIGridsvm.gridObj.solutionMethodId, complexityId: manageRACIGridsvm.gridObj.complexityId }).success(function (res) {
                    manageRACIGridsvm.phaseListObj = res;
                    if (res.phases.length === 0) {
                        alerting.addAlert('info', 'No Data Found');
                    }
                })
            }
        }
        //manageActivityGridsService.getDomains().success(function (res) {
        //    if (res) {
        //        manageActivityGridsvm.domains = res;
        //    }
        //})
        manageRACIGridsService.getMethods().success(function (res) {
            if (res) {
                manageRACIGridsvm.methods = res.solutionMethods;
            }
        })
        function getBrowserType() {
            var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
            var isFirefox = typeof InstallTrigger !== 'undefined';
            var isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);
            var isIE = /*@cc_on!@*/false || !!document.documentMode;
            var isEdge = !isIE && !!window.StyleMedia;
            var isChrome = !!window.chrome && !!window.chrome.webstore;
            var isBlink = (isChrome || isOpera) && !!window.CSS;
            return { isIE: isIE, isChrome: isChrome, isEdge: isEdge }
        }
        manageRACIGridsvm.hideError = function () {
            $('.file-error-container').addClass('collapse');
            $('.file-upload-error').addClass('collapse');
            manageRACIGridsvm.formSubmitted = false;
            $('#exampleFormControlFile1').val(null);
            $('#fileName').text('No File Choosen');
            manageRACIGridsvm.fileChoosen = false;
        }

        //manageRACIGridsvm.loadMethods = function (domainId) {
        //    if (!domainId) {
        //        manageRACIGridsvm.methods = [];
        //    }
        //    else {
        //        manageRACIGridsvm.methods = manageRACIGridsvm.domains.filter(function (domainObj) {
        //            return domainObj.id === parseInt(domainId, 10);
        //        })
        //        manageRACIGridsvm.methods = manageRACIGridsvm.methods[0].methods;
        //        manageRACIGridsvm.gridObj.methodId = "";
        //    }
        //}
        manageRACIGridsService.getComplexities().success(function (res) {
            manageRACIGridsvm.complexityList = res.projectComplexity;
        });
        manageRACIGridsvm.downloadExcel = function (obj) {

            $http.get(location.origin + '/api/CheckSiteRefreshing').success(function (response) {
                manageRACIGridsvm.formSubmitted = true;
                if (response.siteRefresh) {
                    alerting.addAlert('danger', 'We are making some content updates and the site is being refreshed. Please try again after 5 minutes');
                }
                else {
                    if (!manageRACIGridsvm.gridObj.solutionMethodId.id && manageRACIGridsvm.gridObj.complexityId.length === 0) {
                        manageRACIGridsvm.formSubmitted = false;
                        window.open(URLS.adminRACIDownloadExcel + encodeURI('?solutionMethodId=' + parseInt(obj.solutionMethodId.id ? obj.solutionMethodId.id : 0, 10) + '&complexityId=' + 0 + ''));
                    }
                    if (manageRACIGridsvm.gridObj.solutionMethodId.id && manageRACIGridsvm.gridObj.complexityId.length > 0) {
                        window.open(URLS.adminRACIDownloadExcel + encodeURI('?solutionMethodId=' + parseInt(obj.solutionMethodId.id ? obj.solutionMethodId.id : 0, 10) + '&complexityId=' + manageRACIGridsvm.gridObj.complexityId + ''));
                    }
                }
            })


        }
        manageRACIGridsvm.submitForm = function (gridListObj) {
            $.each(gridListObj.activities, function (index, value) {
                gridListObj.activities[index].accountablesList = [];
                gridListObj.activities[index].accountable = gridListObj.activities[index].accountableIds;
                gridListObj.activities[index].consultedList = [];
                gridListObj.activities[index].consulted = gridListObj.activities[index].consultedIds;
                gridListObj.activities[index].informedList = [];
                gridListObj.activities[index].informed = gridListObj.activities[index].informedIds;
                gridListObj.activities[index].responsiblesList = [];
                gridListObj.activities[index].responsible = gridListObj.activities[index].responsibleIds;
            });
            manageRACIGridsvm.phaseListObj.phases = [];
            manageRACIGridsvm.phaseListObj.phases.push(gridListObj);
            if ($scope.gridForm.$valid) {
                manageRACIGridsService.updateActvitiyGrid(new Object(manageRACIGridsvm.phaseListObj)).success(function (res) {
                    if (res.status) {

                        alerting.addAlert('success', TOAST_MESSAGE.ACTIVITY_GRID_STATUS);
                        $state.go('AdminMain.administration');
                    }
                    else {
                        alerting.addAlert('danger', res.errorMsg);
                    }
                })
            }

        }

    }


    angular.module('sdmApp').controller('manageRACIGridsCtrl', manageRACIGridsCtrl);
})();
(function () {
    angular.module('sdmApp')
        .service('manageRACIGridsService', function ($http, URLS) {
            this.getDomains = function () {
                return $http.get(URLS.adminActivityDomain);
            };
            this.getMethods = function (data) {

                return $http.get(URLS.getMethodologies);
            };
            this.getActivities = function (data) {
                //return $http.get(URLS.admindActivityRACIGrid + '?solutionMethodId=' + data.solutionMethodId + '&complexityId=' + data.complexityId + '');
                return data.pageNumber ? $http.get(URLS.admindActivityRACIGrid + '?solutionMethodId=' + data.solutionMethodId + '&complexityId=' + data.complexityId + '&pageNumber=' + data.pageNumber + '&phaseId=' + data.phaseId + '') : $http.get(URLS.admindActivityRACIGrid + '?solutionMethodId=' + data.solutionMethodId.id + '&complexityId=' + data.complexityId + '');
            };
            this.updateActvitiyGrid = function (data) {
                return $http.patch(URLS.admindActivityRACIGrid, data);
            };
            this.getComplexities = function () {
                return $http.get(URLS.adminComplexity);
            }
            this.downloadExcel = function () {
                return $http.get(URLS.adminRACIDownloadExcel);
            }

        });
})();
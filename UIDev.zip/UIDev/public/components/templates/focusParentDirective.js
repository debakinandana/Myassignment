﻿(function () {
    angular.module('sdmApp').directive('focusParent', function ($timeout) {
        return {
            restrict: 'A',
            scope: {
                focusEnabled: '=',
                currentChild:'='
            },
            link: function (scope, elem, attr) {
                elem.on('blur', function (e) {
                    console.log(scope.currentChild)
                    if (scope.currentChild === undefined) {
                        if ($(e.currentTarget.parentElement.parentElement).is(':last-child')) {
                            angular.element('.mCustomScrollBox').find('a').focus();
                        }
                    }
                    
                    else if(scope.currentChild === true) {
                        angular.element('.mCustomScrollBox').find('a').focus();
                    }

                })

            }
        }
    })
})();
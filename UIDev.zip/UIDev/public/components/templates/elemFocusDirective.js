﻿(function () {
    angular.module('sdmApp').directive('elemFocus', function ($timeout) {
        return {
            restrict: 'A',
            scope: {
                focusEnabled: '=',
                sourceElem:'='
            },
            link: function (scope, elem, attr) {
                $timeout(function () {
                    if (elem) {
                        elem.focus();
                    }
                    elem.on('keyup', function (e) {
                        if (e.keyCode === 27) {
                            scope.sourceElem.focus();
                        }
                    })
                }, 50);

            }
        }
    })
})();
(function () {
    function TemplatesCtrl($rootScope, $state, $document, $stateParams, $timeout, $ocLazyLoad, $uibModal, TemplateService, alerting, TOAST_MESSAGE, SharedService, sdmSiteRefresh, $http) {
        var templatevm = this;

        templatevm.$state = $state;
        templatevm.isListMode = true;
        templatevm.selection = [];
        templatevm.selectedCard = null;
        templatevm.selectedSubTemplate = null;
        var subSelection = [];
        var subSelectionCounter = 0;

        // pagination
        templatevm.language = '';
        templatevm.templates = [];
        templatevm.totalItems = 0;
        templatevm.pageSize = 12;
        templatevm.pagination = {
            current: $state.params.page
        };
        templatevm.sortType = $state.params.sort;
        templatevm.searchFilter = {
            title: ''
        };
        templatevm.filterIds = [];
        SharedService.getComplexities().success(function (res) {
            if (res);
            templatevm.complexityList = res;
            //templatevm.complexityType = 1;
        });
        $rootScope.$emit('updateUserView');

        function getSearchResults() {
            if ($rootScope.userDomainId === undefined && $rootScope.userMethodologyId === undefined) {

                TemplateService.getUserDetail().success(function (res) {
                    TemplateService.getSearchResult({ pageNumber: templatevm.pagination.current, searchValue: encodeURIComponent(templatevm.searchFilter.title), sort: templatevm.sortType, filterIds: templatevm.filterIds, language: templatevm.language, domainId: res.selectedDomainId, methodId: res.selectedMethodologyId, complexityId: templatevm.complexityType ? templatevm.complexityType : 0 }).success(function (res) {
                        templatevm.templates = res.records;
                        templatevm.totalItems = res.count;
                        templatevm.selection = [];
                        templatevm.selectedAll = false;
                    });
                })
            }
            else {
                TemplateService.getSearchResult({ pageNumber: templatevm.pagination.current, searchValue: encodeURIComponent(templatevm.searchFilter.title), sort: templatevm.sortType, filterIds: templatevm.filterIds, language: templatevm.language, domainId: $rootScope.userDomainId, methodId: $rootScope.userMethodologyId, complexityId: templatevm.complexityType ? templatevm.complexityType : 0 }).success(function (res) {
                    templatevm.templates = res.records;
                    templatevm.totalItems = res.count;
                    templatevm.selection = [];
                    templatevm.selectedAll = false;
                });
            }


        }

        function getResultsPage() {
            if ($rootScope.userDomainId === undefined && $rootScope.userMethodologyId === undefined) {

                TemplateService.getUserDetail().success(function (res) {
                    TemplateService.getTemplates({ pageNumber: templatevm.pagination.current, searchValue: encodeURIComponent(templatevm.searchFilter.title), sort: templatevm.sortType, filterIds: templatevm.filterIds, language: templatevm.language, domainId: res.selectedDomainId, methodId: res.selectedMethodologyId, complexityId: templatevm.complexityType ? templatevm.complexityType : 0 }).success(function (res) {
                        templatevm.templates = res.templates;
                        templatevm.totalItems = res.count;
                        templatevm.selection = [];
                        templatevm.selectedAll = false;
                    });
                })
            }
            else {
                TemplateService.getTemplates({ pageNumber: templatevm.pagination.current, searchValue: encodeURIComponent(templatevm.searchFilter.title), sort: templatevm.sortType, filterIds: templatevm.filterIds, language: templatevm.language, domainId: $rootScope.userDomainId, methodId: $rootScope.userMethodologyId, complexityId: templatevm.complexityType ? templatevm.complexityType : 0 }).success(function (res) {
                    templatevm.templates = res.templates;
                    templatevm.totalItems = res.count;
                    templatevm.selection = [];
                    templatevm.selectedAll = false;
                });
            }


        }

        getResultsPage();
        // get languages
        TemplateService.getLanguages().success(function (res) {
            templatevm.languages = res;
        });
        templatevm.openPopup = function (title, e) {

            window.open('https://microsoft.sharepoint.com/sites/campus/Pages/CampusSearch.aspx?k=' + title + '')
            e.preventDefault();
        }
        templatevm.handleComplexityFilter = function (complexityType, searchText) {
            //templatevm.complexityType = complexityType;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
        }
        templatevm.pageChangeHandler = function (newPageNumber, oldPageNumber, searchText) {
            if (newPageNumber !== oldPageNumber) {
                templatevm.pagination.current = newPageNumber;
                if (searchText == '')
                    getResultsPage();
                else
                    getSearchResults();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});

        templatevm.searchTemplate = function (searchText) {
            templatevm.searchFilter.title = searchText;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
            SharedService.logEvent('LocalSearch', { title: searchText, itemTypeId: 1, url: window.location.href });
        };

        templatevm.sortBy = function (sortItem, searchText) {
            templatevm.sortType = sortItem;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
            $state.go('.', { sort: sortItem }, { notify: false });
        };

        // filter by language
        templatevm.filterByLanguage = function (selectedLanguage, searchText) {
            templatevm.language = selectedLanguage;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
        };

        // filter templates by phaseId
        $rootScope.$on('phaseFilterChanged', function (event, filterIds, searchText) {
            templatevm.filterIds = filterIds;
            if (searchText == '')
                getResultsPage();
            else
                getSearchResults();
        });
        templatevm.togglePreview = function (template) {
            template.isPreviewing = !template.isPreviewing;
        };

        templatevm.dynamicPopover = {
            templateUrl: 'views/partials/preview-template.html',
            appendToBody: true
        };
        templatevm.showCardDetailSection = function (e, template, appvm) {

            if (e.keyCode === 27) {
                template.templateExpanded = !template.templateExpanded;
                appvm.screenMask = !appvm.screenMask;
                template.localizedActive = false;
                template.sampleActive = false;

            }
        }
        // copy to clipboard
        templatevm.copyLinkFn = function (template) {
            if (template.inProgress == false) {

                template.copyLinkText = 'Copied!';
                $timeout(function () {
                    delete template.copyLinkText;
                }, 1000);
                return false;
            }

        };

        templatevm.checkAll = function (isSelectedAll, selectedTemplates, searchText) {
            templatevm.selection = [];
            angular.forEach(selectedTemplates, function (template) {
                template.Selected = isSelectedAll;
                if (isSelectedAll) {
                    templatevm.selection.push(template);
                }
            });
        };

        templatevm.toggleSingleSelection = function (template, isSubTemplate) {
            if (isSubTemplate) {
                !subSelectionCounter && (templatevm.selection = []);
                subSelectionCounter++;
            } else {
                subSelectionCounter = 0;
            }

            if (templatevm.selection.indexOf(template) > -1) {
                templatevm.selection.pop(template, 1);
            } else {
                templatevm.selection.push(template);
            }
        };

        templatevm.toggleFavourite = function (template) {
            template.isFavourite = !template.isFavourite;
            var data = [{
                id: template.id,
                isFavourite: template.isFavourite,
                title: template.title,
                complexityId: template.complexityId
            }];
            TemplateService.updateFavourite(data).success(function (res) {
                if (template.isFavourite) {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                }
                else {
                    alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                }

            });
        };


        templatevm.addToFavorite = function (id) {
            if (templatevm.selection.length > 0) {
                var data = [];
                for (var i = 0; i < templatevm.selection.length; i++) {
                    templatevm.selection[i].isFavourite = true;
                    data.push({
                        id: templatevm.selection[i].id,
                        title: templatevm.selection[i].title,
                        isFavourite: true,
                        complexityId: templatevm.selection[i].complexityId
                    });
                }
                TemplateService.updateFavourite(data).success(function () {
                    if (templatevm.selection.length == 1) {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                    }
                    else {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITES_ADDED);
                    }
                });

            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_TEMPLATE_SELECTED);
            }
        };

        // templatevm.trackDownload = function (url) {
        //     console.log(url);
        // };

        templatevm.mailToFunctionality = function () {
            if (templatevm.selection.length > 0) {
                var body_message = '',
                    win = '',
                    email = '',
                    subject = 'List of Templates',
                    mailto_link, count = 1;

                for (var i = 0; i < templatevm.selection.length; i++) {
                    if (!templatevm.selection[i].inProgress) {
                        var templateName = templatevm.selection[i].title;
                        var templateUrl = templatevm.selection[i].fileLocation;
                        body_message = body_message + (count) + '. ' + encodeURIComponent(templateUrl) + '%0D%0A';
                        count++;
                    }
                }


                mailto_link = 'mailto:' + email + '?subject=' + subject + '&body=' + body_message;

                win = window.open(mailto_link, 'emailWindow');
                if (win && win.open && !win.closed) {
                    $timeout(function () {
                        win.close()
                    }, 1000);
                    // win.close()
                };
            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_TEMPLATE_SELECTED);
            }
        };

        templatevm.toggleTemplates = function (template, tmplName, index, e) {
            e.preventDefault();
            template.templateExpanded = !template.templateExpanded;
            template.isComplexityList = tmplName === 'projectComplexityDetails';
            templatevm.selectedTemplateIndex = index;
            templatevm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? tmplName : tmplName + 'Templates'];
            template.subtemplateslength = templatevm.selectedSubTemplate.length;
            template[tmplName + 'Active'] = !template[tmplName === 'projectComplexity' ? tmplName : tmplName + 'Active'];
            templatevm.templateType = tmplName;
            clearSubSelection(templatevm.selectedTemplateIndex);
            console.log(angular.element('.card-detail'))
            templatevm.sourceElem = e.currentTarget;
        };

        $rootScope.$on('maskHidden', function () {
            if (templatevm.selectedTemplateIndex !== undefined && templatevm.selectedTemplateIndex !== null) {
                templatevm.templates[templatevm.selectedTemplateIndex].templateExpanded = false;
                templatevm.templates[templatevm.selectedTemplateIndex].sampleActive = false;
                templatevm.templates[templatevm.selectedTemplateIndex].localizedActive = false;
                clearSubSelection(templatevm.selectedTemplateIndex);
                angular.element(templatevm.sourceElem).focus();
            }
        });

        function clearSubSelection(selectedIndex) {
            subSelection = [];
            templatevm.subSelectAll = false;
            var property;

            if (templatevm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else {
                property = 'sampleTemplates';
            }
            angular.forEach(templatevm.templates[selectedIndex][property],
                function (subTemplate) {
                    subTemplate.Selected = false;
                });
        }

        templatevm.openReadMore = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/read-more.html',
                controller: 'ReadMoreCtrl',
                aria: 'read more',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
        };
        templatevm.openRating = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                aria: 'rating',
                size: 'sm',
                aria1: 'rating',
                resolve: {
                    selectedItem: function () {
                        return template;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                template.title = selectedItem.title;
                template.fileLocation = selectedItem.fileLocation;
                template.version = selectedItem.version;
                template.comment = selectedItem.comment;
                template.rating = selectedItem.rating;

            });
        };
    }
    angular.module('sdmApp')
		.controller('TemplatesCtrl', TemplatesCtrl)
        .controller('ReadMoreCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
    .controller('RatingCtrl', function ($scope, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem) {
        $scope.ratingData = angular.copy(selectedItem);
        $scope.originalData = selectedItem;
        $scope.placeholder = "Tell us why? (optional)";
        $scope.title = selectedItem.title;
        $scope.ratingYes = function (e) {
            $scope.ratingData.rating = true;
            $scope.placeholder = "Tell us why? (optional)";
        };

        $scope.ratingNo = function (e) {
            $scope.ratingData.rating = false;
            $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.trackRating = function (ratingData, event) {
            ratingData.isSubmit = true;
            var data = {
                itemTypeId: 1,
                title: ratingData.title,
                url: ratingData.fileLocation,
                version: ratingData.version,
                rating: ratingData.rating,
                comment: ratingData.comment,
                MethodName: localStorage.getItem('userMethodologyName') ? localStorage.getItem('userMethodologyName') : null,
                complexityType: ratingData.complexityName,
                itemId: ratingData.id,
                phaseName: ratingData.phaseName,
                phaseId: ratingData.phaseIds.length ? ratingData.phaseIds[0] : null,
                solutionMethodId: null

            };
            if (ratingData.rating == null) {
                alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
            } else {
                SharedService.logEvent('Rating', data);
                $scope.cancel();
                alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
            }

        };


    });

})();
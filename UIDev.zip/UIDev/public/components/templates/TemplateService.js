angular.module('sdmApp')
    .service('TemplateService', function ($http, URLS) {
        this.getTemplates = function (searchSortPaginateConfig) {
            if (searchSortPaginateConfig) {
                var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                    serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '',
                    sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
                    phaseId = searchSortPaginateConfig.phaseId ? '&phaseIds=' + JSON.stringify([searchSortPaginateConfig.phaseId]) : '',
                    language = searchSortPaginateConfig.language ? '&language=' + searchSortPaginateConfig.language : '',
                    filterIds = (searchSortPaginateConfig.filterIds && searchSortPaginateConfig.filterIds.length) ? '&phaseIds=' + JSON.stringify(searchSortPaginateConfig.filterIds) : '',
                    domainId = '&domainId=' + searchSortPaginateConfig.domainId,
                    methodId = '&methodId=' + searchSortPaginateConfig.methodId,
                    complexityId = '&complexityId=' + searchSortPaginateConfig.complexityId;
                return $http.get(URLS.templates + pageNumber + '&pageSize=12' + serachQuery + sort + filterIds + language + phaseId + domainId + methodId + complexityId);
            } else {
                return $http.get(URLS.templates + '?pageNumber=1&pageSize=12&domainId=' + searchSortPaginateConfig.domainId + '&methodId=' + searchSortPaginateConfig.methodId);
            }

        };


        this.getSearchResult = function (searchSortPaginateConfig) {
            var pageNumber = '?pageNumber=' + searchSortPaginateConfig.pageNumber,
                sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
                searchQ = searchSortPaginateConfig.searchValue ? '&q=' + searchSortPaginateConfig.searchValue : '', sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
                phaseId = searchSortPaginateConfig.phaseId ? '&phaseIds=' + JSON.stringify([searchSortPaginateConfig.phaseId]) : '',
                language = searchSortPaginateConfig.language ? '&language=' + searchSortPaginateConfig.language : '',
                filterIds = (searchSortPaginateConfig.filterIds && searchSortPaginateConfig.filterIds.length) ? '&phaseIds=' + JSON.stringify(searchSortPaginateConfig.filterIds) : '',
                roles = (searchSortPaginateConfig.roles && searchSortPaginateConfig.roles.length) ? '&roleIds=' + JSON.stringify(searchSortPaginateConfig.roles) : '',
                domainId = '&domainId=' + searchSortPaginateConfig.domainId,
                methodId = '&methodId=' + searchSortPaginateConfig.methodId,
                complexityId = '&complexityId=' + searchSortPaginateConfig.complexityId;
            return $http.get(URLS.search + pageNumber + searchQ + sort + filterIds + roles + language + phaseId + domainId + methodId + complexityId + '&pageSize=12&idrSearchArtifactType=Template');
        };

        //this.updateFavourite = function (data) {
        //    return $http.post(URLS.favorites, data);
        //};

        this.updateFavourite = function (data) {
            var config = URLS.AntiforgeryConfig;
            return $http.patch(URLS.templates, data, config);
        };
        this.updateRating = function (data) {
            var config = URLS.AntiforgeryConfig;
            return $http.patch(URLS.templates, data, config);
        };

        this.getLanguages = function () {
            return $http.get(URLS.languages);
        };

        function downloadFile(url) {
            window.open(url, '_blank', '', false);
        }

        this.downloadTemplates = function (ids) {
            downloadFile(URLS.downloads + '?templateIds=' + JSON.stringify(ids));
        };
        this.getUserDetail = function () {
            return $http.get(URLS.profileUrl);
        }
    });
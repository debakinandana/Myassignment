﻿angular.module('sdmApp')
	.service('FilterService', function ($http, URLS) {
	    this.getPhases = function (methodId) {
	        return $http.get(URLS.phases+'?methodId='+methodId);
	    };
	    this.getRoles = function () {
	        return $http.get(URLS.roles);
	    };
	    this.getUserDetail = function () {
	        return $http.get(URLS.profileUrl);
	    }

	});
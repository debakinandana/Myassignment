﻿(function () {
    angular.module("sdmApp")
		.controller('MethodologyCtrl', function ($window, $state, $stateParams, $scope, $rootScope, $timeout, alerting, UserService, TemplateService, MethodologyService, VisioDetail, TOAST_MESSAGE, VisioDetailService, SharedService, $http) {
		    var mthodvm = this,
                $visioContainer = $('#visioContainer');

		    mthodvm.openedSidebar = '';
		    mthodvm.totalItems = 0;
		    mthodvm.pageSize = 12;
		    mthodvm.pagination = {
		        current: 1
		    };
		    mthodvm.haveActivity = false;
		    mthodvm.isFavourite = false;

		    mthodvm.phaseId = null;
		    mthodvm.visioDetail = VisioDetail ? VisioDetail.data : null;
		    $rootScope.complexityId = 0;
		    mthodvm.selectedMethodologyVisio = decodeURIComponent($stateParams.selectedMethodologyVisio);
		    SharedService.getComplexities().success(function (res) {
		        if (res) {
		            mthodvm.complexityList = res;
		            // mthodvm.complexityType = 3;
		            //var dflt= mthodvm.complexityType;

		            $rootScope.complexityIdList = res;
		            //$rootScope.$emit("roleFilterChanged", $rootScope.roleIds, mthodvm.complexityType);
		            //getResultsPage();
		        }
		    });
		    $rootScope.$emit('updateVisioDetail', {
		        visioFilePath: mthodvm.selectedMethodologyVisio
		    });
		    $rootScope.$on('methodologyVisio', function (resultObj) {
		        mthodvm.visioDetail = resultObj;
		    });
		    $('.ti-close').on('keydown', function (e) {
		        if (e.keyCode === 9 && event.shiftKey) {
		            $('.ti-close').focus();
		            e.stopImmediatePropagation();
		        }
		    })

		    //var gotVisio = $rootScope.$on('updateVisio', function(e, data){
		    //    mthodvm.visioDetail = data;
		    //    console.log(data);
		    //});

		    //$scope.$on('$destroy', function () {
		    //    gotVisio(); // remove listener.
		    //});
		    //test
		    //if (mthodvm.complexityType === 3) {
		    // mthodvm.handleComplexityFilterDflt = function () {
		    //$rootScope.$emit("roleFilterChanged", $rootScope.roleIds, complexityType);
		    // getResultsPage();
		    // }
		    //  }
		    mthodvm.handleComplexityFilter = function (complexityType) {
		        //complexityType = mthodvm.complexityList[2];
		        $rootScope.$emit("roleFilterChanged", $rootScope.roleIds, complexityType);
		        getResultsPage();
		    }
		    if (mthodvm.visioDetail) {
		        $rootScope.$emit('gotVisioDetail', mthodvm.visioDetail);
		    }

		    mthodvm.getEventsOfVisioFile = function () {

		        UserService.SDMRefreshService()
                  .success(function (event) {
                      //alert("Site Refresh Is running please wait for 5 mins.");
                      $scope.events = event;
                  })
                  .error(function (error) {
                      $scope.status = "Unable to load event data: ";
                  })
                  .finally(function () {
                      console.timeEnd('refresh');
                  });
		    }

		    //$(document).on("click", function (e) {
		    //    var operationId = e.target.id;

		    //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
		    //});

		    VisioDetailService.getVisioDetail(mthodvm.selectedMethodologyVisio).success(function (userInfo) {
		        console.log(userInfo);
		        if (userInfo.isComplexity === true) {
		            window.localStorage.setItem('userMethodologyId', userInfo ? userInfo.methodId : 0);
		            window.localStorage.setItem('userMethodologyName', userInfo ? userInfo.methodName : "");
		            window.localStorage.setItem('userPhasName', userInfo ? userInfo.phaseName : "");
		            window.localStorage.setItem('userPhasId', userInfo ? userInfo.phaseId : 0);
		            $rootScope.phaseId = userInfo ? userInfo.phaseId : 0;

		            if ($rootScope.phaseId) {
		                SharedService.getComplexities().success(function (res) {
		                    if (res) {
		                        $rootScope.complexityList = res;
		                        mthodvm.complexityType = 3;
		                        $scope.complexityType = false;

		                        var dflt = mthodvm.complexityType;
		                        $rootScope.$emit("roleFilterChanged", $rootScope.roleIds, dflt);
		                        mthodvm.disbalecomplexityType = false;
		                        //getResultsPage();
		                    }
		                    mthodvm.getEventsOfVisioFile();
		                });
		            }
		        }
		        else {

		            window.localStorage.setItem('userMethodologyId', userInfo ? userInfo.methodId : 0);
		            window.localStorage.setItem('userMethodologyName', userInfo ? userInfo.methodName : "");
		            window.localStorage.setItem('userPhasName', userInfo ? userInfo.phaseName : "");
		            window.localStorage.setItem('userPhasId', userInfo ? userInfo.phaseId : 0);
		            $rootScope.phaseId = userInfo ? userInfo.phaseId : 0;
		            if ($rootScope.phaseId) {
		                SharedService.getComplexities().success(function (res) {
		                    if (res) {
		                        mthodvm.disbalecomplexityType = true;
		                        $rootScope.complexityList = res;
		                        mthodvm.complexityType = 3;
		                        //mthodvm.complexityType = 3;

		                        //var dflt = mthodvm.complexityType;
		                        //$rootScope.complexityId = 3;
		                        //$rootScope.$emit($rootScope.complexityId, dflt);

		                        //getResultsPage();
		                    }

		                });
		            }


		        }
		    })
		    if (!$stateParams.solutionMethodName) {
		        UserService.success(function (userInfo) {
		            mthodvm.solutionMethodName = userInfo.selectedMethodologyName;
		            mthodvm.selectedMethodologyId = userInfo.selectedMethodologyId;
		            mthodvm.phaseDescription = userInfo.phaseDescription;
		            //$rootScope.phaseName = userInfo.phaseName;
		            //$visioContainer[0].style.display = 'none';
		            //$visioContainer[0].style.display = 'block';
		        });
		    } else {
		        mthodvm.solutionMethodName = $stateParams.solutionMethodName;
		        mthodvm.selectedMethodologyId = $stateParams.selectedMethodologyId;

		        mthodvm.phaseDescription = $stateParams.phaseDescription;

		        //$visioContainer[0].style.display = 'none';
		        //$visioContainer[0].style.display = 'block';
		    }

		    function getResultsPage() {
		        //mthodvm.complexityType = mthodvm.complexityList[3];
		        MethodologyService.getTemplatesByPhase({
		            pageNumber: mthodvm.pagination.current,
		            phaseId: mthodvm.visioDetail.phaseId,
		            complexityId: mthodvm.complexityType ? mthodvm.complexityType : 3
		            //complexityType: mthodvm.complexityList ? mthodvm.complexityList : "Type 3 [Medium]"
		        })
                    .success(function (res) {
                        if (res) {

                            //mthodvm.complexityType = mthodvm.complexityList[2];

                            mthodvm.templates = res.templates;
                            mthodvm.totalItems = res.count;
                        }
                    });
		    }

		    //var gotVisio = $rootScope.$on('gotVisioDetail', function (e, visioDetail) {
		    //    mthodvm.visioDetail = visioDetail;
		    //    console.log("gegegegg HHHHHHHHHHHHh")
		    //    //mthodvm.phaseId = visioDetail.phaseId;
		    //    getResultsPage();
		    //});
		    if (mthodvm.visioDetail) {
		        SharedService.logEvent(mthodvm.visioDetail.phaseId ? 'Phase' : 'Solution Method', {
		            itemTypeId: mthodvm.visioDetail.phaseId ? 15 : 11,
		            title: mthodvm.visioDetail.phaseId ? mthodvm.visioDetail.phaseName : mthodvm.visioDetail.methodName,
		            url: location.protocol + '//' + location.hostname + mthodvm.visioDetail.visioFilePath,
		            version: null,
		            MethodName: mthodvm.visioDetail.methodName,
		            PhaseName: mthodvm.visioDetail.phaseName,
		            ComplexityType: null
		        });
		    }

		    mthodvm.visioDetail && getResultsPage();
		    mthodvm.closeSideBar = function (status, elem) {
		        mthodvm.openedSidebar = status;
		        if (elem) {
		            angular.element(elem).focus();
		        }
		    }
		    mthodvm.closeOnEscape = function (e, status, elem) {
		        if (e.keyCode === 27) {
		            mthodvm.openedSidebar = status;
		            if (elem) {
		                angular.element(elem).focus();
		            }
		        }
		    }

		    mthodvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
		        if (newPageNumber !== oldPageNumber) {
		            mthodvm.pagination.current = newPageNumber;
		            getResultsPage();
		            $state.go('.', { page: newPageNumber }, { notify: false });
		        }
		    };

		    mthodvm.toggleFavourite = function (template) {
		        template.isFavourite = !template.isFavourite;
		        var data = [{
		            id: template.id,
		            isFavourite: template.isFavourite,
		            title: template.title,
		            complexityId: template.complexityId
		        }];

		        TemplateService.updateFavourite(data).success(function (res) {
		            if (template.isFavourite) {
		                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
		            }
		            else {
		                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
		            }

		        });
		    };
		    mthodvm.emailFeedBack = function (template, data) {
		        var trackingData = {
		            itemTypeId: 2,
		            title: localStorage.getItem('activityName'),
		            url: localStorage.getItem('activityUrl'),
		            version: null,
		            rating: localStorage.getItem('commentsStatus'),
		            comment: localStorage.getItem('comment'),
		            MethodName: localStorage.getItem('userMethodologyName') === "null" ? null : localStorage.getItem('userMethodologyName'),
		            PhaseName: localStorage.getItem('phaseName') === "null" ? null : localStorage.getItem('phaseName'),
		            Domain: localStorage.getItem('userDomainName'),
		            Methodology: localStorage.getItem('userMethodologyName'),
		        };
		        SharedService.logEvent('Rating', trackingData);
		    }

		    mthodvm.copyLinkFn = function (template) {
		        template.copyLinkText = 'Copied!';
		        $timeout(function () {
		            delete template.copyLinkText;
		        }, 1000);
		    };

		    mthodvm.visioactivities = [];

		    //function resetOtherRolesVisibility(activityId) {
		    //    mthodvm.visioactivities.forEach(function (item) {
		    //        if (item.activityId !== activityId) {
		    //            item['participant_' + item.activityId] = false;
		    //            item['responsible_' + item.activityId] = false;
		    //            item['accountable_' + item.activityId] = false;
		    //        }
		    //    })
		    //}

		    //mthodvm.toggleRolesPopover = function (action, va) {
		    //    resetOtherRolesVisibility(va.activityId);
		    //    va[action + va.activityId] = !va[action + va.activityId]
		    //};

		    mthodvm.openActivityModal = function (activityPageId) {
		        //$ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
		        //MethodologyService.getActivityDescription(activityPageId).success(function (res) {
		        //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
		        //                    .then(function () {
		        //                        var modalInstance = $uibModal.open({
		        //                            templateUrl: 'components/activities/activityDescription.html',
		        //                            controller: 'ActivityDescCtrl',
		        //                            size: 'lg',
		        //                            aria: 'Activity Content',
		        //                            resolve: {
		        //                                selectedItem: function () {
		        //                                    return res;
		        //                                }
		        //                            }
		        //                        });
		        //                    });
		        //});
		        var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
		        var mywindow = window.open(location.protocol + '//' + location.host + '/sdm/activityContent/activityDetail.html?id=' + activityPageId + '', "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
		        mywindow.focus();
		    };

		})
            .controller('ActivityDescCtrl', function ($scope, $uibModalInstance, selectedItem) {
                $scope.selectedTemplate = selectedItem;

                $scope.cancel = function () {
                    $uibModalInstance.dismiss('cancel');
                };
            });
})();

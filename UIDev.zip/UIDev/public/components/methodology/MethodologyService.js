﻿(function () {
    angular.module('sdmApp')
	    .service('MethodologyService', function ($http, URLS) {
	        this.getVisioaAtivities = function (roleIds,complexityId, path) {
	            return $http.get(URLS.visioactivities, { params: { roleIds: JSON.stringify(roleIds), path: path, complexityId: complexityId } });
	        };

	        this.getTemplatesByPhase = function (searchSortPaginateConfig) {
	            var pageNumber = searchSortPaginateConfig.pageNumber ? '?pageNumber=' + searchSortPaginateConfig.pageNumber : '',
                    phaseId = searchSortPaginateConfig.phaseId ? '&phaseid=' + searchSortPaginateConfig.phaseId : '',
	                complexityId = '&complexityId='+searchSortPaginateConfig.complexityId;

	            return $http.get(URLS.templatesbyphase + pageNumber + '&pageSize=12' + phaseId + complexityId);
	        };
	        this.getActivityDescription = function (id) {
	            return $http.get(URLS.GetDynamicActivityContent, { params: { activityIdentifier: id } });
	        };
	    });
})();
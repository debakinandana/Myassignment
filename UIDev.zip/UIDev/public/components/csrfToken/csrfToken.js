﻿(function (sdmApp) {
    var addToken = function () {

        return {
            request: function (config) {
                var csrfToken = angular.element("input[name='__RequestVerificationToken']").val();
                config.headers['__RequestVerificationToken'] = csrfToken;
                return config;
            }
        };
    };

    sdmApp
        .factory("addToken", addToken)
        .config(['$httpProvider', '$provide', function ($httpProvider, $provide) {
            $httpProvider.interceptors.push("addToken");
        }]);

}(angular.module('sdmApp')));
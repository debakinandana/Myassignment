﻿angular.module('sdmApp')
	.service('SearchService', function ($http, URLS) {
	    this.getSearchResult = function (searchSortPaginateConfig) {
	        var pageNumber = '?pageNumber=' + searchSortPaginateConfig.pageNumber,
	            //serachQuery = searchSortPaginateConfig.searchValue ? '&searchValue=' + searchSortPaginateConfig.searchValue : '',
	            sort = searchSortPaginateConfig.sort ? '&sort=' + searchSortPaginateConfig.sort : '',
	            searchQ = searchSortPaginateConfig.q ? '&q=' + searchSortPaginateConfig.q : '';
	        //language = searchSortPaginateConfig.language ? '&language=' + searchSortPaginateConfig.language : '',
	        //filterIds = searchSortPaginateConfig.filterIds.length ? '&pIds=' + JSON.stringify(searchSortPaginateConfig.filterIds) : '';
	        return $http.get(URLS.search + pageNumber + searchQ + sort + '&pageSize=12');
	    };
	});
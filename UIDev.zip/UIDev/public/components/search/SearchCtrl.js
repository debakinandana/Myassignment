﻿(function () {
    function SearchCtrl($rootScope,$scope, $state, $location, $timeout, $ocLazyLoad, $uibModal, SearchService, alerting, FavoriteService, TOAST_MESSAGE, ActivitiesService, SharedService) {
        var searchvm = this;

        searchvm.$state = $state;
        searchvm.isListMode = true;
        //searchvm.copyLink = 'Copy Link';
        searchvm.selection = [];
        searchvm.selectedCard = null;
        searchvm.selectedSubTemplate = null;
        var subSelection = [];

        // pagination
        searchvm.language = '';
        searchvm.favorites = [];
        searchvm.totalItems = 0;
        searchvm.pageSize = 12;
        searchvm.pagination = {
            current: 1
        };
        searchvm.sortType = '0';
        searchvm.searchFilter = {
            title: ''
        };
        searchvm.changeFilter = false;
        searchvm.filterIds = [];
        searchvm.q = $state.params.searchText;
        $rootScope.$emit('updateUserView');
        function getResultsPage() {
            SearchService.getSearchResult({ pageNumber: searchvm.pagination.current, searchValue: searchvm.searchFilter.title, sort: searchvm.changeFilter ? searchvm.sortType : $state.params.sort.trim(), q: searchvm.q, complexityId: searchvm.complexityType ? searchvm.complexityType : 0 }).success(function (res) {
                searchvm.searchResults = res.records;
                searchvm.totalItems = res.count;
                searchvm.selection = [];
                searchvm.selectedAll = false;
                searchvm.activityDetail = res;

                $scope.searchvm.isComplexity = [];
                for (var i = 0; i < res.records.length; i++) {
                    $scope.searchvm.isComplexity.push(res.records[i].isComplexity)

                }

                //if (res.records[0].isComplexity === true) {
                //    searchvm.hideComplexity = false;
                //}
                //if (res.records[0].isComplexity === false ) {
                //    searchvm.hideComplexity = true;
                //}
                
                searchvm.sortType = searchvm.changeFilter ? searchvm.sortType : $state.params.sort.trim();
            });
        }
        getResultsPage();

        //searchvm.hideshow = function (res) {
        //    if (res.records[0].isComplexity === true) {
        //        searchvm.hideComplexity = false;
        //    }
        //    if (res.records[0].isComplexity === false) {
        //        searchvm.hideComplexity = true;
        //    }
        //}

        searchvm.pageChangeHandler = function (newPageNumber, oldPageNumber) {
            if (newPageNumber !== oldPageNumber) {
                searchvm.pagination.current = newPageNumber;
                getResultsPage();
                $state.go('.', { page: newPageNumber }, { notify: false });
            }
        };
        SharedService.getComplexities().success(function (res) {
            if (res) {
                searchvm.complexityList = res;
                //searchvm.complexityType = 1;
            }
        });
        searchvm.openPopup = function (title) {
            window.open('https://microsoft.sharepoint.com/sites/campus/Pages/CampusSearch.aspx?k=' + title + '')
        }
        searchvm.complexityFilter = function (complexityType) {
            console.log(complexityType)
            getResultsPage();
        }
        searchvm.emailFeedBack = function (template) {
            var data = {
                itemTypeId: template.itemTypeId,
                title: template.title,
                url: template.itemTypeId === 2 ? template.isExternal ? template.fileLocation : location.protocol + "//" + location.host + "/sdm/activityContent/activityDetail.html?id=" + template.id + "" : template.itemTypeId === 15 ? location.protocol + "//" + location.host + '/sdm/Index#/methodology/' + text : template.fileLocation,
                version: template.version,
                rating: localStorage.getItem('commentsStatus'),
                comment: localStorage.getItem('comment'),
                MethodName: localStorage.getItem('userMethodologyName') === "null" ? null : localStorage.getItem('userMethodologyName'),
                PhaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'),
                Domain: localStorage.getItem('userDomainName'),
                Methodology: localStorage.getItem('userMethodologyName'),
                complexityType: template.complexityName ? template.complexityName : null,
                phaseId: template.phaseId,
                itemId: template.id,
                solutionMethodId: template.solutionMethodId
            };
            SharedService.logEvent('Rating', data);
        }
        searchvm.searchTemplate = function (title, SearchText) {
            searchvm.searchFilter.title = title;
            getResultsPage();
            SharedService.logEvent('GlobalSearch', { SearchText: title, ItemTitle: title, url: window.location.href });
        };

        searchvm.sortBy = function (sortItem) {
            searchvm.changeFilter = true;
            searchvm.sortType = sortItem;
            $state.go('.', { sort: sortItem }, { notify: false });
            getResultsPage();


        };

        //$(document).on("click", function (e) {
        //    var operationId = e.target.id;

        //    SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });
        //});

        searchvm.filterByLanguage = function (selectedLanguage) {
            searchvm.language = selectedLanguage;
            getResultsPage();
        };
        searchvm.dynamicPopover = {
            templateUrl: 'views/partials/preview-template.html',
            appendToBody: true
        };
        searchvm.openModal = function (sItem) {
            //if (!sItem.isExternal) {
            //    $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/activities/activity-desc.css']);
            //    //ActivitiesService.getActivityDescription(sItem.id).success(function (res) {
            //    //    $ocLazyLoad.load(['components/common/filters/trustAsHtmlFilter.js'])
            //    //                    .then(function () {
            //    //                        var modalInstance = $uibModal.open({
            //    //                            templateUrl: 'components/activities/activityDescription.html',
            //    //                            controller: 'ReadMoreCtrl',
            //    //                            size: 'lg',
            //    //                            aria: 'Activity Content',
            //    //                            resolve: {
            //    //                                selectedItem: function () {
            //    //                                    return res;
            //    //                                }
            //    //                            }
            //    //                        });
            //    //                    });
            //    //});
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(sItem.fileLocation, "Activity", "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            //else {
            //    //SharedService.openModal(sItem.type, sItem.title, sItem.fileLocation);
            //    var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            //    var mywindow = window.open(sItem.fileLocation, sItem.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            //    mywindow.focus();
            //}
            if (sItem.isExternal) {
                SharedService.logEvent('Activity', {
                    itemTypeId: 2,
                    title: sItem.title,
                    url: sItem.fileLocation,
                    version: sItem.version,
                    MethodName: sItem.solutionMethodName,
                    phaseName: sItem.phaseTitle,
                    rating: null,
                    phaseId: sItem.phaseIds,
                    itemId: sItem.id,
                    solutionMethodId: sItem.solutionMethodId,
                    complexityType: sItem.complexityName
                });
            }
            var w = screen.width > 1600 ? screen.width - 400 : screen.width, h = screen.height > 912 ? screen.height - 260 : screen.height - 100, left = screen.width / 2 - w / 2, top = 0;
            var mywindow = window.open(sItem.fileLocation, sItem.title, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ",left=" + left + ",", true);
            mywindow.focus();
        }
        searchvm.copyLinkFn = function (template) {
            template.copyLinkText = 'Copied!';
            $timeout(function () {
                delete template.copyLinkText;
            }, 1000);
        };

        searchvm.getTopicUrl = function (topicName) {
            var absUrl = $location.absUrl().split('#')[0];
            return absUrl + $state.href('topics.detail', { topicName: topicName });
        };
        searchvm.getVisioUrl = function (visioFilePath) {
            var text = ""; filePath = visioFilePath.split('/');
            for (var i = 1; i < filePath.length; i++) {
                text += "%252F" + filePath[i];
            }
            return location.origin + location.pathname + "#/methodology/" + text;
        };
        searchvm.checkAll = function (isSelectedAll, selectedTemplates) {
            searchvm.selection = [];
            angular.forEach(selectedTemplates, function (template) {
                template.Selected = isSelectedAll;
                if (isSelectedAll) {
                    searchvm.selection.push(template);
                }
            });
        };

        //searchvm.checkAll = function () {

        //    angular.forEach(searchvm.searchResults, function (item) {
        //        item.Selected = searchvm.selectedAll;
        //        if (searchvm.selectedAll) {
        //            searchvm.selection.push(item);
        //        } else {
        //            searchvm.selection = [];
        //            return;
        //        }

        //    });
        //};

        searchvm.toggleSingleSelection = function (template) {
            if (searchvm.selection.indexOf(template) > -1) {
                searchvm.selection.splice(template, 1);
            } else {
                searchvm.selection.push(template);
            }
        };

        function alertFavorite(status) {
            if (status) {
                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
            }
            else {
                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
            }
        }

        searchvm.toggleFavourite = function (template) {
            template.isFavourite = !template.isFavourite;

            var data = [{
                favouriteTypeId: template.itemTypeId,
                favouriteTypeDataId: template.id,
                displayValue: template.title,
                isFavourite: template.isFavourite,
                complexityId: template.complexityId
            }];

            //if (template.itemTypeId === 1) {
            //    TemplateService.updateFavourite(data).success(function (res) {
            //        alertFavorite(template.isFavourite);
            //    });
            //} else if (template.itemTypeId === 2) {
            //    ActivitiesService.updateFavourite(data).success(function (res) {
            //        alertFavorite(template.isFavourite);
            //    });
            //}

            FavoriteService.updateFavourite(data)
                .success(function (res) {
                    alertFavorite(template.isFavourite);
                });
        };

        searchvm.addToFavorite = function (id) {
            if (searchvm.selection.length > 0) {
                var data = [];
                for (var i = 0; i < searchvm.selection.length; i++) {
                    data.push({
                        favouriteTypeId: searchvm.selection[i].itemTypeId,
                        favouriteTypeDataId: searchvm.selection[i].id,
                        displayValue: searchvm.selection[i].title,
                        isFavourite: true
                    });
                }
                FavoriteService.updateFavourite(data).success(function () {
                    if (searchvm.selection.length == 1) {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                    }
                    else {
                        alerting.addAlert('success', TOAST_MESSAGE.FAVORITES_ADDED);
                    }

                    angular.forEach(searchvm.searchResults, function (template) {
                        for (var j = 0; j < searchvm.selection.length; j++) {
                            if (template.id === searchvm.selection[j].id) {
                                template.isFavourite = true;
                            }
                        }
                    })
                });

            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_ITEM_SELECTED);
            }

        };


        searchvm.mailToFunctionality = function () {
            if (searchvm.selection.length > 0) {
                var body_message = '',
                    win = '',
                    email = '',
                    subject = 'List of Search Results',
                    mailto_link, count = 1;

                for (var i = 0; i < searchvm.selection.length; i++) {
                    var url;
                    if (!searchvm.selection[i].inProgress) {
                        if (searchvm.selection[i].itemTypeId === 15) {
                            url = searchvm.getVisioUrl(searchvm.selection[i].fileLocation);
                        }
                        else {
                            if (searchvm.selection[i].fileLocation) {
                                url = searchvm.selection[i].fileLocation;
                            } else {
                                url = searchvm.getTopicUrl(searchvm.selection[i].title);
                            }
                        }
                        body_message = body_message + (count) + '. ' + encodeURIComponent(url) + '%0D%0A';
                        count++;
                    }




                }

                mailto_link = 'mailto:' + email + '?subject=' + subject + '&body=' + body_message;

                win = window.open(mailto_link, 'emailWindow');
                if (win && win.open && !win.closed) {
                    $timeout(function () {
                        win.close()
                    }, 1000);
                    // win.close()
                };
            } else {
                alerting.addAlert('info', TOAST_MESSAGE.NO_ITEM_SELECTED);
            }
        };

        function clearSubSelection(selectedIndex) {
            subSelection = [];
            searchvm.subSelectAll = false;
            var property;

            if (searchvm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else {
                property = 'sampleTemplates';
            }
            angular.forEach(searchvm.searchResults[selectedIndex][property],
                function (subTemplate) {
                    subTemplate.Selected = false;
                });
        }


        searchvm.toggleTemplates = function (template, tmplName, index, e, sItem) {
            // resetCollapsed(template.id, tmplName);

            if (sItem.isComplexity) {
                template.templateExpanded = !template.templateExpanded;
                searchvm.selectedFileType = template.itemTypeId;
                template.isComplexitySelected = tmplName === 'projectComplexityDetails';
                searchvm.selectedTemplateIndex = index;
                searchvm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? tmplName : tmplName + 'Templates'];
                searchvm.selectedSubTemplate = template[tmplName + 'Templates'];
                template.subtemplateslength = searchvm.selectedSubTemplate.length;
                template[tmplName + 'Active'] = !template[tmplName + 'Active'];
                searchvm.templateType = tmplName;
                searchvm.sourceElem = e.currentTarget;
                clearSubSelection(searchvm.selectedTemplateIndex);
            }
        };

        $rootScope.$on('maskHidden', function () {
            if (searchvm.selectedTemplateIndex !== undefined && searchvm.selectedTemplateIndex !== null) {
                searchvm.searchResults[searchvm.selectedTemplateIndex].templateExpanded = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].sampleActive = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].localizedActive = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
                clearSubSelection(searchvm.selectedTemplateIndex);
                angular.element(searchvm.sourceElem).focus();
            }
        });


        searchvm.toggleTemplates = function (template, tmplName, index, e) {
            // resetCollapsed(template.id, tmplName);
            searchvm.selectedFileType = template.itemTypeId;
            template.templateExpanded = !template.templateExpanded;
            template.isComplexitySelected = tmplName === 'projectComplexityDetails';
            searchvm.selectedTemplateIndex = index;
            searchvm.selectedSubTemplate = template[tmplName === 'projectComplexityDetails' ? tmplName : tmplName + 'Templates'];
            template.subtemplateslength = searchvm.selectedSubTemplate.length;
            template[tmplName + 'Active'] = !template[tmplName + 'Active'];
            searchvm.templateType = tmplName;
            searchvm.sourceElem = e.currentTarget;
            clearSubSelection(searchvm.selectedTemplateIndex);

        };

        $rootScope.$on('maskHidden', function () {
            if (searchvm.selectedTemplateIndex !== undefined && searchvm.selectedTemplateIndex !== null) {
                searchvm.searchResults[searchvm.selectedTemplateIndex].templateExpanded = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].sampleActive = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].localizedActive = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].projectComplexityDetailsActive = false;
                clearSubSelection(searchvm.selectedTemplateIndex);
            }
        });

        searchvm.checkAllSubTemplate = function () {
            subSelection = [];
            favvm.subSelectAll = false;
            var property;
            if (favvm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else if (searchvm.templateType === 'sample') {
                property = 'sampleTemplates';
            }
            else {
                property = "projectComplexityDetails";
            }
            angular.forEach(searchvm.searchResults[searchvm.selectedTemplateIndex][property],
                function (subTemplate) {
                    subTemplate.Selected = searchvm.subSelectAll;
                    if (searchvm.subSelectAll) {
                        subSelection.push(subTemplate);
                    } else {
                        subSelection = [];
                        return;
                    }

                });
        }
        function clearSubSelection(selectedIndex) {
            subSelection = [];
            searchvm.subSelectAll = false;
            var property;

            if (searchvm.templateType === 'localized') {
                property = 'localizedTemplates';
            } else if (searchvm.templateType === 'sample') {
                property = 'sampleTemplates';
            }
            else {
                property = "projectComplexityDetails";
            }
            angular.forEach(searchvm.searchResults[selectedIndex][property],
                function (subTemplate) {
                    subTemplate.Selected = false;
                });
        }
        searchvm.showCardDetailSection = function (e, template, appvm) {

            if (e.keyCode === 27) {
                searchvm.searchResults[searchvm.selectedTemplateIndex].templateExpanded = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].sampleActive = false;
                searchvm.searchResults[searchvm.selectedTemplateIndex].localizedActive = false;
                clearSubSelection(searchvm.selectedTemplateIndex);
                appvm.screenMask = !appvm.screenMask;
            }
        }
        searchvm.openReadMore = function (template) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css', 'components/common/filters/trustAsHtmlFilter.js'])
                .then(function () {
                    var modalInstance = $uibModal.open({
                        templateUrl: 'components/common/modals/read-more.html',
                        controller: 'ReadMoreCtrl',
                        aria: 'read more',
                        resolve: {
                            selectedItem: function () {
                                return template;
                            }
                        }
                    });
                });
            //SharedService.openModal(sItem.type, sItem.title, sItem.fileLocation);
        };
        searchvm.openRating = function (searchTemplate) {
            $ocLazyLoad.load(['components/common/commoncss/modal.css']);
            var modalInstance = $uibModal.open({
                templateUrl: 'components/common/modals/rating.html',
                controller: 'RatingCtrl',
                size: 'sm',
                aria: 'rating',
                resolve: {
                    selectedItem: function () {
                        return searchTemplate;
                    }
                }
            });
            modalInstance.result.then(function (selectedItem) {
                searchTemplate.title = selectedItem.title;
                searchTemplate.fileLocation = selectedItem.fileLocation;
                searchTemplate.version = selectedItem.version;
                searchTemplate.comment = selectedItem.comment;
                searchTemplate.rating = selectedItem.rating;

            });
        };

    }
    angular.module('sdmApp')
        .controller('SearchCtrl', SearchCtrl)
        .controller('ReadMoreCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('RatingCtrl', function ($scope, $location, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem, $state) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.title = selectedItem.title;
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };
            $scope.getTopicUrl = function (topicName) {
                var absUrl = $location.absUrl().split('#')[0];
                return absUrl + $state.href('topics.detail', { topicName: topicName });
            };
            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I’m changing my previous opinion. Document is no longer relevant as it doesn’t reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                var url;
                if ($scope.originalData.favouriteTypeId == 10 || $scope.originalData.favouriteTypeId == 11) {
                    url = $location.host() + $scope.originalData.visioFilePath;
                }
                else {
                    url = $scope.originalData.fileLocation;
                }
                var data = {
                    itemTypeId: $scope.originalData.itemTypeId,
                    title: $scope.originalData.title,
                    url: url,
                    version: $scope.originalData.version,
                    rating: ratingData.rating,
                    comment: ratingData.comment
                };
                if (ratingData.rating == null) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    if (ratingData.itemTypeId === 15) {
                        var text = ""; filePath = ratingData.fileLocation.split('/');
                        for (var i = 1; i < filePath.length; i++) {
                            text += "%252F" + filePath[i];
                        }
                    }
                    var data = {
                        itemTypeId: ratingData.itemTypeId,
                        title: ratingData.title,
                        url: ratingData.itemTypeId === 2 ? ratingData.fileLocation : ratingData.itemTypeId === 15 ? location.protocol + "//" + location.host + '/sdm/Index#/methodology/' + text : ratingData.itemTypeId === 10 ? $scope.getTopicUrl(ratingData.diagramName) : ratingData.fileLocation,
                        version: ratingData.version,
                        rating: ratingData.rating,
                        comment: ratingData.comment,
                        MethodName: ratingData.solutionMethodName ? ratingData.solutionMethodName : null,
                        PhaseName: ratingData.itemTypeId === 2 || ratingData.itemTypeId === 15 ? ratingData.phaseTitle ? ratingData.phaseTitle : null : null,
                        ComplexityType: ratingData.complexityName ? ratingData.complexityName : null,
                        phaseId: ratingData.phaseId,
                        itemId: ratingData.id,
                        solutionMethodId: ratingData.solutionMethodId
                    };


                    if (ratingData.itemTypeId === 2 || ratingData.itemTypeId === 15 && ratingData.solutionMethodName !== null) {
                        SharedService.logEvent('Rating', data);

                        if (ratingData.solutionMethodId > 0) {
                            SharedService.sendUserFeedback({ methodId: ratingData.solutionMethodId, methodName: ratingData.solutionMethodName, phaseName: ratingData.phaseTitle, phaseId: ratingData.phaseIds ? ratingData.phaseIds : 0, emailType: ratingData.itemTypeId === 2 ? 3 : 1, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: ratingData.title, activitId: ratingData.id, url: !ratingData.isExternal ? ratingData.itemTypeId === 2 ? ratingData.fileLocation : location.protocol + "//" + location.host + '/sdm/Index#/methodology/' + text : ratingData.fileLocation }).success(function (res) {
                                if (res.status) {
                                    alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                                }
                                else {
                                    alerting.alert('danger', res.errorMessage)
                                }
                                $scope.cancel();
                            })
                        }
                        else {
                            alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                            $scope.cancel();
                        }
                    }
                    else {
                        SharedService.logEvent('Rating', data);
                        alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                        $scope.cancel();
                    }

                }

            };


        });
})();
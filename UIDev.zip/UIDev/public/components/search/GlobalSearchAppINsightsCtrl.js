﻿$(document).ready(function () {

    var params = location.search.substring(1).search('&') > 0 ? location.search.substring(1).split('&') : location.search.substring(1);
    var userDetails;
    var userSearchDetails;
    //var isuserRefreshed = false;



    var instrumentationKeyList = [{
        hostName: 'sdmplus-dev.azurewebsites.net',
        instrumentationKey: 'cc03d068-3d54-4e9e-a637-4b2f872bd0ae'
    }, {
        hostName: 'sdmplus-test.azurewebsites.net',
        instrumentationKey: '4757f7dd-ca68-4df8-8a9d-809f9e9c6146'
    }, {
        hostName: 'sdmplus-uat.azurewebsites.net',
        instrumentationKey: '7de5309f-2195-46bd-a614-160d60f50204'
    }, {
        hostName: 'sdmplus.azurewebsites.net',
        instrumentationKey: '872736d4-8dec-4b64-a447-9d63e370ccf0'
    }, {
        hostName: 'sdmplusdigi-dev.azurewebsites.net',
        instrumentationKey: 'b30b267f-045a-4961-ba9f-ae7e0a664877'
    }, {
        hostName: 'sdmplusdigi-test.azurewebsites.net',
        instrumentationKey: 'df48b277-4b80-417d-b67f-2167969d3bff'
    }, {
        hostName: 'sdmplusdigi-uat.azurewebsites.net',
        instrumentationKey: '8ade9937-b2b7-47b4-8103-77134536a4c6'
    }, {
        hostName: 'sdmplusdigi.azurewebsites.net',
        instrumentationKey: '757dd375-bb4b-4fc5-b457-584723cdd54f'
    }, {
        hostName: 'localhost',
        instrumentationKey: '1f894d03-9e08-4db3-9ff8-41b1ab85a1ab'
    }, {
        hostName: 'sdmplusdev.azurewebsites.net',
        instrumentationKey: 'f561c415-c692-4c21-a71d-8558ce50401a'
    }, {
        hostName: 'sdmplustest.azurewebsites.net',
        instrumentationKey: '4091743e-60c1-435f-9c56-b0807c4275b4'
    }, {
        hostName: "sdmplusuat.azurewebsites.net",
        instrumentationKey: "71d3be0f-b9de-49a5-aabb-f407251336da"
    }, {
        hostName: "sdmplusbackup.azurewebsites.net",
        instrumentationKey: "692ab400-493b-400d-8fc2-61289d59d289"
    }, {
        hostName: "devsdmplus.azurewebsites.net",
        instrumentationKey: "b51f7e05-2582-4cfc-aa21-9853a5b8021a",
    }, {
        hostName: "testsdmplus.azurewebsites.net",
        instrumentationKey: "192cfb0b-f90d-4ecf-a456-4a019e4c537e",
    }, {
        hostName: "uatsdmplus.azurewebsites.net",
        instrumentationKey: "564d17fc-dd64-43d1-88ff-9df3dd746ccf",
    }];
    function getInstrumentationKey(currentHost) {
        for (var i in instrumentationKeyList) {
            if (instrumentationKeyList[i].hostName === currentHost) {
                return instrumentationKeyList[i].instrumentationKey;
            }
        }
    }

    var iKey = getInstrumentationKey(window.location.hostname);
    var eventKey = numberNoHyphens = iKey.replace(/-/g, "");
    console.log(eventKey)
    var siteRefresh = false;
    $.ajax({
        type: 'GET',
        url: '/api/CheckSiteRefreshing',
        async: false,
        success: function (res) {
            siteRefresh = res.siteRefresh;
            if (res.siteRefresh) {
                $('#mainWrapper').html('<h2 class="page-heading" style="color:#cc0000">we are making some content updates and the site is being refreshed. Please try again after 5 minutes</h2>');
            }
            else {

            }
        }
    });


    $.ajax({
        url: location.protocol + '//' + location.host + '/api/autocomplete',
        type: 'GET',
        async: false,
        params: titleVal,
        success: function (res) {
            userSearchDetails = res;
        }
    });


    $.ajax({
        url: location.protocol + '//' + location.host + '/api/user/profile',
        type: 'GET',
        async: false,
        
        success: function (res) {
            userDetails = res;
        }
    });
    if (userDetails == null || userDetails == undefined) {
        
        var wnd = window.location.replace(location.protocol + '//' + location.host, '_blank', 'width=400,height=400,scrollbars=1', '_self');
       
        $.ajax({
            url: location.protocol + '//' + location.host + '/api/user/profile',
            type: 'GET',
            
            async: false,
            success: function (res) {
                userDetails = res;
            }
        });
    }
    var appInsightsObject = [{
        "time": new Date(),
        "name": "Microsoft.ApplicationInsights." + getInstrumentationKey(window.location.hostname).replace(/-/g, "") + ".Event",
        "iKey": iKey,
        "data": {
            "baseData": {
                "name": 'GlobalSearch',
                "properties": {
                    "Alias": userDetails.alias ? userDetails.alias : null,
                    "Domain": userDetails.selectedDomainName ? userDetails.selectedDomainName : null,
                    "Methodology": userDetails.selectedMethodName ? userDetails.selectedMethodName : null,
                    "Location": userDetails.location ? userDetails.location : null,
                    "ItemTypeId": 17,
                    "searchText": userDetails.searchText,
                    "buttonClicked": userDetails.buttonClicked,
                    "ItemVersion": userDetails.version,
                    "PhaseName": userDetails.phaseName ? userDetails.phaseName : null,
                    "SolutionMethodName": userDetails.methodName ? userDetails.methodName : null,
                    "ActivityName": userDetails.ActivityName ? userDetails.ActivityName : null,
                    "TemplateName": userDetails.TemplateName ? userDetails.TemplateName : null,
                    "Auth User Id": userDetails.alias ? userDetails.alias : null,
                    "Telemtry Type": "customEvent",
                    "titleVal": userSearchDetails.titleVal ? userSearchDetails.titleVal : null,
                    "titleVal": userDetails.alias ? userDetails.alias : null,
                    "focus" : userDetails.focus ? userDetails.focus: null,
                    "PhaseId": userDetails.phaseIds,
                    "MethoId": userDetails.methodId,
                    "DomainId": userDetails.selectedDomainId,
                    "SolutionMethodId": t.solutionMethodId,
                    "ActivityId": userDetails.id,
                    "Auth User Id": userDetails.alias ? userDetails.alias : null,
                    "DomainId": userDetails.selectedDomainId,
                    "Referrer": window.location.toString().indexOf('ref') > 0 ? window.location.toString().substring(window.location.toString().indexOf('ref') + 4, window.location.toString().indexOf('&name')) : 'sdmplus'
                },
                "ver": 2
            },
            "baseType": 'EventData'

        }
    }];

    $.ajax({
        url: 'https://dc.services.visualstudio.com/v2/track',
        type: 'POST',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        jsonpCallback: function (alert) {
            console.log(alert)
        },
        jsonp: true,
        data: JSON.stringify(appInsightsObject),
        success: function (res) {}

      
    });
    
});
﻿(function () {
    angular.module('sdmApp')
        .controller('UserPreferenceCtrl', function ($rootScope, $scope, $state, $filter, DomainService, UserService, alerting, $ocLazyLoad, $injector, TOAST_MESSAGE, $window, VisioDetailService, SharedService, sdmSiteRefresh, $http) {
            $scope.data = {};
            $scope.methodData = [];
            $scope.domain = null;
            $scope.methodology = null;
            $rootScope.resetProfile = true;
            function filterByDomain(obj) {
                if ('domainId' in obj && obj.domainId === $scope.domain) {
                    return true;
                } else {
                    return false;
                }
            }
            $rootScope.$on('resetDomainAndMetholody', function (e) {
                DomainService.getUserDetail().success(function (userInfo) {
                    
                    $scope.domain = $rootScope.loadDefaultView ? $rootScope.userDomainId : userInfo.selectedDomainId;
                    $scope.methodology = $rootScope.loadDefaultView ? $rootScope.userMethodologyId : userInfo.selectedMethodologyId;
                    $rootScope.userDomainId = $scope.domain;
                    $rootScope.userMethodologyId = $scope.methodology;

                })

            })
            $rootScope.$on('updateUserView', function (e) {
                DomainService.getUserDetail().success(function (userInfo) {
                    $scope.domain = $rootScope.loadDefaultView ? $rootScope.userDomainId : userInfo.selectedDomainId;
                    $scope.methodology = $rootScope.loadDefaultView ? $rootScope.userMethodologyId : userInfo.selectedMethodologyId;
                    $rootScope.userDomainId = $scope.domain;
                    $rootScope.userMethodologyId = $scope.methodology;

                })
            });
            DomainService.getDomainMethodology().success(function (res) {
                $rootScope.domainData = res;
                $scope.data = $filter('orderBy')(res, 'domainName');
                //$http.get(location.protocol + '//' + location.host + '/api/CheckSiteRefreshing').success(function (response) {
                //    if (response.siteRefresh) {
                //        alerting.addAlert('danger', 'we are making some content updates and the site is being refreshed. Please try again after 5 minutes');
                //        $state.go('home');
                //    }
                //    else {
                //        UserService.success(function (userInfo) {
                //            $scope.domain = userInfo.selectedDomainId;
                //        });
                //    }

                //});
                $scope.$watch('domain', function () {

                    var filteredData = $scope.data.filter(filterByDomain);
                    if (filteredData !== null && filteredData !== undefined && filteredData.length) {
                        filteredData = filteredData[0];
                        $scope.methodData = $filter('orderBy')(filteredData.methods, 'solutionMethodName');
                        UserService.success(function (userInfo) {
                            if ($scope.domain === userInfo.selectedDomainId) {
                                $scope.methodology = userInfo.selectedMethodologyId;
                            } else {
                                $scope.methodology = null;
                            }
                        });
                    }
                    else {
                        $scope.methodData = [];
                    }
                });
            });



            $scope.loadUserPreferences = function () {
                UserService.success(function (userInfo) {
                    if (($scope.domain === 0 && $scope.methodology === null)) {
                        alerting.addAlert('info', TOAST_MESSAGE.NO_DOMAIN_METHODOLOGY_SELECTED);
                    }
                    else if ($scope.domain === null && $scope.methodology === null && userInfo.selectedDomainId === "" && userInfo.selectedMethodologyId === "") {
                        alerting.addAlert('info', TOAST_MESSAGE.NO_DOMAIN_METHODOLOGY_SELECTED);
                    }
                    else if ($scope.domain && !$scope.methodology) {
                        alerting.addAlert('info', TOAST_MESSAGE.NO_METHODOLOGY_SELECTED);
                    }
                    else {
                        DomainService.getUserPreference($scope.domain ? $scope.domain : 0, $scope.methodology ? $scope.methodology : 0).success(function (res) {
                            if (res.status) {
                                $rootScope.loadDefaultView = true;
                                if (res.selectedDomainId === 0 || res.selectedMethodologyId === 0) {
                                    alerting.addAlert('info', TOAST_MESSAGE.PROFILE_RESET);
                                    userInfo.selectedDomainId = 0;
                                    userInfo.selectedMethodologyId = '';
                                    userInfo.selectedMethodologyName = null;
                                    $rootScope.$emit('updateVisioDetails', res)
                                    userInfo.visioFilePath = res.visioFilePath;
                                    userInfo.phaseDescription = res.phaseDescription;
                                    $scope.domain = 0;
                                    $scope.methodology = null;
                                    $state.go('home');
                                }
                                else {
                                    $state.go('methodology', {
                                        selectedMethodologyId: res.selectedMethodologyId,
                                        solutionMethodName: res.selectedMethodologyName,
                                        selectedMethodologyVisio: res.visioFilePath,
                                        phaseDescription: res.phaseDescription
                                    });
                                }
                                $rootScope.userDomainId = res.selectedDomainId;
                                $rootScope.userMethodologyId = res.selectedMethodologyId;
                                $rootScope.userMethodologyName = res.selectedMethodologyName;
                                $rootScope.phaseName = res['phaseName'];
                                $rootScope.updatedUserPrefernce = true;
                                window.localStorage.clear();
                                window.localStorage.setItem('userMethodologyId', res.selectedMethodologyId);
                                window.localStorage.setItem('userMethodologyName', res.selectedMethodologyName);
                                window.localStorage.setItem('userDomainName', res.selectedDomainName);
                                window.localStorage.setItem('userPhasName', res.phaseName);
                                window.localStorage.setItem('userPhasId', res.phaseId);
                                //window.localStorage.setItem('userPhasId', res.selectPhaseId);
                            }
                            else {
                                alerting.addAlert('danger', res.errorMessage);
                                //$state.go('home');
                                //$window.location.reload();
                            }

                        });
                    }
                });
            }




            $scope.saveUserPreferences = function () {
                UserService.success(function (userInfo) {
                    if ($scope.domain && !$scope.methodology) {
                        alerting.addAlert('info', TOAST_MESSAGE.NO_METHODOLOGY_SELECTED);
                    } else {
                        DomainService.updateUserPreference({
                            selectedDomainId: $scope.domain ? $scope.domain : 0,
                            selectedMethodologyId: $scope.methodology ? $scope.methodology : 0
                        }).success(function (res) {
                            if (res.status) {

                                if ((userInfo.selectedDomainId && userInfo.selectedMethodologyId) && (!res.selectedDomainId || !res.selectedMethodologyId)) {
                                    userInfo.selectedDomainId = '';
                                    userInfo.selectedMethodologyId = '';
                                    userInfo.selectedMethodologyName = null;
                                    //userInfo.visioFilePath = res.visioFilePath;
                                    //userInfo.phaseDescription = res.phaseDescription;
                                    alerting.addAlert('success', TOAST_MESSAGE.PROFILE_DEFAULT);

                                } else {
                                    userInfo.selectedDomainId = res.selectedDomainId;
                                    userInfo.selectedDomainName = res.selectedDomainName;
                                    userInfo.selectedMethodologyId = res.selectedMethodologyId;
                                    userInfo.selectedMethodologyName = res.selectedMethodologyName;
                                    //userInfo.visioFilePath = res.visioFilePath;
                                    //userInfo.phaseDescription = res.phaseDescription;
                                    alerting.addAlert('success', TOAST_MESSAGE.PROFILE_DEFAULT);

                                }
                                $rootScope.userDomainId = res.selectedDomainId;
                                $rootScope.userMethodologyId = res.selectedMethodologyId;
                                SharedService.saveLogEvent({
                                    url: location.protocol + "//" + location.host + res.visioFilePath,
                                    MethodName: res.selectedMethodologyName
                                })
                            }
                            else {
                                alerting.addAlert('danger', res.errorMsg);
                                $state.go('home');
                                //$window.location.reload();
                            }
                        });
                    }
                });

                //$state.go('methodology', { solutionMethodName: 'userInfo.selectedMethodologyName' });
            };
        });
})();
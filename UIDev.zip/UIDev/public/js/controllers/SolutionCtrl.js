﻿(function () {
    angular.module("sdmApp")
		.controller('SolutionCtrl', function () {
		    //var solutionvm = this;
		    

		    //solutionvm.scrollbarConfig = {
		    //    setWidth: '390px',
		    //    autoHideScrollbar: true,
		    //    setHeight: 'calc(100% - 55px)',
		    //    scrollInertia: 500,
		    //    axis: 'y',
		    //    theme: 'minimal-dark',
		    //    scrollButtons: {
		    //        scrollAmount: 'auto',
		    //        enable: true
		    //    }
		    //};



		});
})();

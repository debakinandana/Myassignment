(function () {
    angular.module('sdmApp')
        .controller('ApplicationCtrl', function ($window, $document, $timeout, $scope, $injector, SharedService, alerting, $rootScope, $location, $state, $stateParams, $uibModal, $ocLazyLoad, UserService, AutoCompleteService, FavoriteService, VisioDetailService, WhatsnewService, TOAST_MESSAGE, $http, URLS) {
            var appvm = this;
            appvm.navbarCollapsed = true;
            appvm.subnavCollapsed = true;
            appvm.lastnavCollapsed = true;
            appvm.langCollapsed = true;
            appvm.selectedSearchItem = '';
            appvm.isRetiredCotentAvailable = true;
            appvm.toggledLeft = false;
            appvm.toggledRight = false;
            appvm.menuToggled = false;
            appvm.$state = $state;
            appvm.isFavourite = false;
            appvm.isFullScreen = false;
            appvm.visioWidth = { 'width': '1506px' };
            appvm.solutionMethodName = '';
            $scope.choice = '';
            $rootScope.$on('presetFavorite', function (e, isFavorite) {
                appvm.isFavourite = isFavorite;
            });
            $rootScope.$on('presetRating', function (e, rating) {
                appvm.rating = rating;
            });
            $rootScope.$on('Service error', function (e, errorConfig) {
                SharedService.trackServiceError('Service Exception', { serviceUrl: errorConfig ? errorConfig.config ? errorConfig.config.url : errorConfig : '', status: errorConfig.status, data: JSON.stringify(errorConfig ? errorConfig.config ? errorConfig.config.data : null : null), PageTitle: document.title, PageUrl: window.location.href, type: errorConfig.config ? errorConfig.config.method : null, errorMessage: errorConfig.data, CorrelationId: errorConfig.config ? errorConfig.config.headers.correlationId : "" });
                console.log(errorConfig);
            });

            $rootScope.$on('Service Corelation', function (e, dataConfig) {
                SharedService.sendCorelationId('ServiceRequest', { requestUrl: dataConfig.requestUrl, title: dataConfig.title, correlationId: dataConfig.correlationId });
            })
            appvm.reloadDefaultState = function () {
                //alert('hello')
                $rootScope.loadDefaultView = false;
                $rootScope.$emit('updateUserView');
            }
            appvm.toggleFavourite = function () {
                appvm.isFavourite = !appvm.isFavourite;
                if ($state.includes('topics')) {
                    $rootScope.$emit('togglefav', appvm.isFavourite);
                } else {
                    appvm.visioDetail.isFavorite = appvm.isFavourite;
                    VisioDetailService.updateFavourite(appvm.visioDetail)
                        .success(function (res) {
                            if (appvm.isFavourite) {
                                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_ADDED);
                            }
                            else {
                                alerting.addAlert('success', TOAST_MESSAGE.FAVORITE_REMOVED);
                            }
                        });
                }
            };

            $(document).on('click', function (e) {

                var operationId = e.target.id;
                SharedService.logEvent('EventCalls', { ClickEvent: operationId, url: window.location.href });

            });

            appvm.openPopUp = function (windowTitle, title, url) {
                var w = 900, h = 700, left = screen.width / 2 - w / 2, top = screen.height / 2 - h / 2;
                window.open(url, windowTitle, "resizable=yes, scrollbars=yes, width=" + w + ", height=" + h + ", top=" + top + ", left=" + left + "", true);
            }
            appvm.showChildren = function (e) {
                var submenu = $('.dropdown-menu'), toggleButton = $('.dropdown-toggle');
                var childList = e.currentTarget.children;
                if (event.keyCode === 32) { // space bar - open/close submenu
                    if ($(e.currentTarget).hasClass('open')) {
                        $(e.target).attr('aria-expanded', 'false');
                        $(e.currentTarget).removeClass('open')
                        submenu.attr('aria-hidden', true);
                    } else {
                        $(e.currentTarget).addClass('open')
                        $(e.target).attr('aria-expanded', 'true');
                        submenu.attr('aria-hidden', false);
                    }
                    event.stopImmediatePropagation();
                    event.preventDefault();
                }
                if (event.keyCode === 9 && $(e.currentTarget).hasClass('open')) {
                    var childList = $(e.currentTarget).find('ul').find('li').find('a');
                    $(childList[0]).focus();
                    event.stopImmediatePropagation();
                    event.preventDefault();
                }
                //else if (event.keyCode === 40) {
                //    $(e.currentTarget).addClass('open')
                //    $(e.target).attr('aria-expanded', 'true');
                //    submenu.attr('aria-hidden', false);
                //    var childList = $(e.currentTarget).find('ul').find('li').find('a');
                //    $(childList[0]).focus();
                //    //$(childList[0]).focus();
                //}


            }
            appvm.reload = function () {
                window.location.href = "/";
            }
            appvm.showMenuItem = function (e, status, keyName) {
                if (e.keyCode === 40) {
                    status[keyName] = !status[keyName]
                    setTimeout(function () { $(e.currentTarget.parentElement).find('ul').find('li:first-child').find('a').focus(); e.stopPropagation(); }, 20);

                }


            }
            appvm.handleChildren = function (event) {
                if ($(event.target.parentElement).is(':last-child')) {
                    if (event.keyCode === 9 && !event.shiftKey) {
                        if ($(event.currentTarget.parentElement).hasClass('open')) {
                            $(event.currentTarget.parentElement).removeClass('open')
                            if (!$(event.currentTarget.parentElement).is(':last-child')) {
                                event.stopPropagation();

                                $timeout(function () {
                                    $(event.currentTarget.parentElement).find('a').attr('aria-expanded', 'false');
                                    $($(event.currentTarget.parentElement).next('li:not(.divider):not(.disabled):visible')).find('a').focus()
                                }, 50);
                            }
                        }
                        else
                            return;
                    }
                }
                else if ($(event.target.parentElement).is(':first-child')) {
                    if (event.keyCode === 9 && event.shiftKey) {
                        if ($(event.currentTarget.parentElement).hasClass('open')) {
                            event.stopPropagation();
                            $(event.currentTarget.parentElement).removeClass('open')
                            $timeout(function () { $($(event.currentTarget.parentElement)[0]).focus() }, 50);
                            $(event.currentTarget.parentElement)[0].find('a').attr('aria-expanded', 'false')
                        }

                    }
                }
                if (event.keyCode === 13) {
                    if ($(event.currentTarget.parentElement).hasClass('open')) {
                        $(event.currentTarget.parentElement).removeClass('open')
                        $(event.currentTarget.parentElement).find('a').attr('aria-expanded', 'false')
                        event.stopImmediatePropagation();
                    }
                }
                if (event.keyCode === 16) {
                    if ($(event.currentTarget.parentElement).hasClass('open')) {
                        event.stopPropagation();
                        $(event.currentTarget.parentElement).removeClass('open')
                        $($(event.currentTarget.parentElement)[0]).find('a').attr('aria-expanded', 'false')
                    }
                }
                if (event.keyCode === 9) {
                    $timeout(function () {
                        $($(event.target.parentElement).next('li:not(.divider):not(.disabled):visible')).find('a').focus();
                        event.stopImmediatePropagation();
                    }, 0);
                }
                //if (event.keyCode === 40) {
                //    if (!$(event.target.parentElement).is(':last-child')) {
                //        $timeout(function () {
                //            $($(event.target.parentElement).next('li:not(.divider):not(.disabled):visible')).find('a').focus();
                //            event.stopImmediatePropagation();
                //        }, 0);
                //    }
                //    else {
                //        $(event.currentTarget.parentElement).removeClass('open');
                //        var childList = $(event.currentTarget.parentElement).find('a');
                //        $(childList[0]).attr('aria-expanded', 'false')
                //        //$(event.currentTarget.parentElement).find('a').attr('aria-expanded', 'false')
                //        $(event.target.parentElement).next('li:not(.divider):not(.disabled):visible').find('a').focus();
                //        $timeout(function () {
                //            var nextElem = $(event.currentTarget.parentElement).nextAll('li:not(.divider):not(.disabled):visible').find('a');
                //            if (!$(event.currentTarget.parentElement).is(':last-child')) {
                //                $(nextElem[0]).focus();
                //            }
                //            else {
                //                $(event.currentTarget.parentElement).find('a').focus();
                //            }

                //        }, 0);
                //        event.stopImmediatePropagation();
                //    }

                //}
                //
                //event.preventDefault();

            }
            appvm.openRating = function () {
                if ($state.includes('home') || $state.includes('methodology')) {
                    $ocLazyLoad.load(['components/common/commoncss/modal.css']);
                    var modalInstance = $uibModal.open({
                        templateUrl: 'components/common/modals/rating.html',
                        controller: 'RatingCtrl',
                        aria: 'rating',
                        size: 'sm',
                        resolve: {
                            selectedItem: function () {
                                return appvm.visioDetail;
                            }
                        }
                    });
                    modalInstance.result.then(function (selectedItem) {
                        appvm.visioDetail.title = selectedItem.title || selectedItem.name;
                        appvm.visioDetail.visioFilePath = selectedItem.visioFilePath;
                        appvm.visioDetail.version = null;
                        appvm.visioDetail.comment = selectedItem.comment;
                        appvm.visioDetail.rating = selectedItem.rating;

                    });
                }
                else if ($state.includes('topics.detail')) {
                    $rootScope.$emit('ratingOption', appvm.visioDetail);
                }
            };
            appvm.showOrHideMenu = function (e, status, keyName) {
                if ($(e.target.parentElement).is(':last-child')) {
                    if (e.keyCode === 9 && !event.shiftKey)
                        status[keyName] = !status[keyName];
                    else
                        return;
                }
                else if ($(e.target.parentElement).is(':first-child')) {
                    if (e.keyCode === 9 && event.shiftKey)
                        status[keyName] = !status[keyName];
                    else
                        return;
                }
                if (e.keyCode === 40) {
                    if (!$(event.target.parentElement).is(':last-child')) {
                        $($(event.target.parentElement).next('li:not(.divider):not(.disabled):visible')).find('a').focus()
                    }
                }

            }




            appvm.visioDetail = {};
            appvm.userInfo = {};


            //$rootScope.$on('updateVisioDetail', function(e, visio){
            //    appvm.visioDetail.visioFilePath = visio.visioFilePath;
            //});

            $rootScope.$on('gotVisioDetail', function (e, visioDetail) {
                appvm.visioDetail = visioDetail;
                appvm.phaseDescription = visioDetail.phaseDescription;
                appvm.isFavourite = visioDetail.isFavorite ? visioDetail.isFavorite : false;
            });

            //appvm.gotVisio = function (visioDetail) {
            //    console.log(visioDetail)
            //    appvm.visioDetail = visioDetail;
            //    //UserService.success(function (userInfo) {
            //    //    userInfo.title = visioDetail.title;
            //    //    userInfo.phaseDescription = visioDetail.description;
            //    //    userInfo.visioFilePath = visioDetail.visioFilePath;
            //    //});
            //};
            function getPlayBooks() {
                $http.get(URLS.playbooks).success(function (response) {
                    appvm.playbooks = response;
                })
            }
            function getSolutionMethods() {
                $http.get(URLS.solutionMethods).success(function (response) {
                    appvm.solutionMethods = response;
                })
            }
            getSolutionMethods();
            getPlayBooks();
            function detectIE() {
                var ua = window.navigator.userAgent;

                var msie = ua.indexOf('MSIE ');
                if (msie > 0) {
                    // IE 10 or older => return version number
                    return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
                }

                var trident = ua.indexOf('Trident/');
                if (trident > 0) {
                    // IE 11 => return version number
                    var rv = ua.indexOf('rv:');
                    return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
                }

                var edge = ua.indexOf('Edge/');
                if (edge > 0) {
                    // Edge (IE 12+) => return version number
                    return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
                }
                var chrome = ua.indexOf('Chrome/');
                if (chrome > 0) {

                    return parseInt(ua.substring(chrome + 5, ua.indexOf('.', chrome)), 10);
                }
                // other browser
                return false;
            }

            appvm.toggleFullScreen = function () {

                var el = document.documentElement,
     rfs = el.requestFullscreen
       || el.webkitRequestFullScreen
       || el.mozRequestFullScreen
       || el.msRequestFullscreen
                ;

                rfs.call(el);
            }
            //    if (detectIE() == 10) {
            //        alerting.addAlert('info', TOAST_MESSAGE.FULLSCREEN_NOT_SUPPORTED);
            //    }
            //    if (screenfull.enabled) {

            //        screenfull.toggle();
            //        $document[0].addEventListener(screenfull.raw.fullscreenchange, function () {
            //            $scope.$apply(function () {
            //                if (screenfull.isFullscreen) {
            //                    appvm.isFullScreen = true;
            //                } else {
            //                    appvm.isFullScreen = false;
            //                }
            //            });
            //        });
            //    }
            //};


            appvm.checkContent = function (retiredContent) {
                if (retiredContent.visioFilePath == null) {
                    alerting.addAlert('danger', TOAST_MESSAGE.NO_RETIRED_CONTENT);
                }
                else {
                    $state.go('methodology', { selectedMethodologyVisio: retiredContent.visioFilePath });
                }
            };
            function getRetiredContent() {
                $http.get(URLS.retiredContent).success(function (response) {
                    appvm.retiredContent = response;
                    if (appvm.retiredContent.length) {
                        appvm.isRetiredCotentAvailable = true;
                    }
                    else {
                        appvm.isRetiredCotentAvailable = false;
                    }
                })
            }
            getRetiredContent();
            appvm.toggleSidebar = function (rightSidebarToggle, elementContainer) {
                if (rightSidebarToggle) {
                    appvm.toggledRight = !appvm.toggledRight;
                } else {
                    appvm.toggledLeft = !appvm.toggledLeft;
                }
                if (elementContainer) {
                    $timeout(function () {
                        angular.element(elementContainer).focus()
                    }, 50)

                }
            };
            appvm.closeOnEscape = function (e, rightSidebarToggle, elementContainer) {
                if (e.keyCode === 27) {
                    if (rightSidebarToggle) {
                        appvm.toggledRight = !appvm.toggledRight;
                    } else {
                        appvm.toggledLeft = !appvm.toggledLeft;
                    }
                    if (elementContainer) {
                        $timeout(function () {
                            angular.element(elementContainer).focus()
                        }, 50)

                    }
                }
            }
            UserService.success(function (userInfo) {
                if (userInfo.showWhatsNew) {
                    appvm.toggledLeft = true;
                }
            });
            var pinStatus = $rootScope.$on('pinStatus', function (e, isPin) {
                if (isPin) {
                    appvm.toggledLeft = true;
                }
                else {
                    appvm.toggledLeft = false;
                }
            });

            appvm.showSidebar = function (selectedPhase) {
                appvm.toggledLeft = true;
                appvm.selectedPhase = selectedPhase;
            };
            appvm.clickoutClose = function () {
                appvm.toggledLeft = false;
            }
            appvm.toggleMenu = function () {
                appvm.menuToggled = !appvm.menuToggled;
            };
            appvm.demoEvent = function () {
                // console.log("clicked");
            };
            $scope.linkClicked = function (link) {
                // console.log('hello');
            };

            appvm.scrollbarConfig = {
                autoHideScrollbar: true,
                setHeight: 'calc(100% - 55px)',
                //setWidth: '280px',
                //setWidth: '390px',
                scrollInertia: 500,
                axis: 'y',
                theme: 'minimal-dark',
                scrollButtons: {
                    scrollAmount: 'auto',
                    enable: true
                }
            };

            $rootScope.$on('gotSelectedTopic', function (e, topic) {
                appvm.topic = topic;
                appvm.isFavourite = topic.isFavorite;
                appvm.rating = topic.rating;
                appvm.phaseDescription = topic.description;
            });

            appvm.shareUrl = function () {
                var subject = 'mailto:?subject=Link to ';

                if ($state.includes('home') || $state.includes('methodology')) {
                    var visioTitle = appvm.visioDetail.title && appvm.visioDetail.title[0].toUpperCase() + appvm.visioDetail.title.slice(1);
                    subject += (appvm.visioDetail.visioLevel || '') + ' - ' + (visioTitle || $rootScope.title);
                } else if ($state.includes('topics.detail')) {
                    subject += $rootScope.title + ' - ' + appvm.visioDetail.name;
                } else if ($state.includes('topics')) {
                    subject += $rootScope.title;
                }
                else {
                    subject += $rootScope.title;
                }

                $window.location = subject + '&body=' + encodeURIComponent($location.absUrl());
            };

            appvm.maskScreen = function () {
                appvm.screenMask = !appvm.screenMask;
                $rootScope.$broadcast('maskHidden');
                //template.templateExpanded = !template.templateExpanded;
            };

            appvm.openFeedback = function (openFeedback) {
                $ocLazyLoad.load('components/feedback/FeedbackService.js')
                    .then(function () {
                        var FeedbackService = $injector.get('FeedbackService');
                        FeedbackService.getSurvey().success(function (res) {
                            if (res.showFeedBack || openFeedback) {
                                $ocLazyLoad.load(['components/common/commoncss/button-outline.css'])
                                    .then(function () {
                                        var modalInstance = $uibModal.open({
                                            templateUrl: 'components/feedback/feedback.html',
                                            controller: 'FeedbackCtrl',
                                            size: 'lg',
                                            aria: 'SDM User Experience Survey',
                                            resolve: {
                                                feedbackData: function () {
                                                    return res;
                                                }
                                            }
                                        });

                                    });
                            }
                        });


                    });

            };
            //appvm.openFeedback();

            appvm.getAutoCompleteList = function (titleVal) {

                return AutoCompleteService.getAutoCompleteSearchList(titleVal)
                    .then(function (res) {
                        return res.data;
                    });

            };

            appvm.toggleSearch = function () {
                appvm.isGlobalSearch = !appvm.isGlobalSearch;
                angular.element('.search').trigger('focus');
            };

            appvm.searchItemSelected = function ($item, $model, $label, $event) {
                appvm.isGlobalSearch = false;
                if ($item.itemTypeId === 1) {
                    $state.go('templateDetail', { id: $item.id });
                } else if ($item.itemTypeId === 2) {
                    $state.go('activityDetail', { id: $item.id });
                } else if ($item.itemTypeId === 10) {
                    $state.go('topics.detail', { topicName: $item.title });
                }
                else if ($item.itemTypeId === 15) {
                    $state.go('methodology', { selectedMethodologyVisio: encodeURIComponent($item.fileLocation) });
                }

                appvm.selectedSearchItem = '';

            };
            appvm.focusOnContainer = function (container) {
                if (container) {
                    angular.element(container).find('#focusableContainer').focus();
                    
                 
                }


            }
            appvm.searchItems = function (event, searchText, buttonClicked) {
                if (event.keyCode == 13 && searchText) {
                    appvm.isGlobalSearch = false;
                    appvm.spinning = false;
                    appvm.selectedSearchItem = '';
                    SharedService.logEvent('GlobalSearch', { title: searchText, url: window.location.href });
                    $state.go('search.grid', { searchText: searchText }, { reload: true });
                }
                else if (searchText && buttonClicked) {
                    appvm.isGlobalSearch = false;
                    appvm.spinning = false;
                    SharedService.logEvent('GlobalSearch', { title: searchText, url: window.location.href });
                    $state.go('search.grid', { searchText: searchText }, { reload: true });
                }
               
                //var globalValue = document.getElementById("selectedSearchItem");
                //var searchKey = globalValue.value;
                
                SharedService.logEvent('GlobalSearch', { title: searchText, url: window.location.href });

            };
            $scope.$watch('appvm.toggledLeft', function (oldValue, newValue) {
                appvm.visioWidth = 'width:1232px';
            });
            appvm.openTileDesc = function (template) {
                var modalInstance = $uibModal.open({
                    templateUrl: 'components/common/modals/tile-desc.html',
                    controller: 'openTileDescCtrl',
                    resolve: {
                        selectedItem: function () {
                            return template;
                        }
                    }
                });
            };

            appvm.hide = function () {
                appvm.isGlobalSearch = false;
                appvm.selectedSearchItem = '';
            };

            $rootScope.$on('$stateChangeStart', function () {
                appvm.selectedSearchItem = '';
            });


            appvm.openModal = function (pageType, title, url, phaseDescription) {
                localStorage.setItem('linkUrl', url);
                SharedService.openModal(pageType, title, url);
                if (pageType === 'Topic' && url) {
                    appvm.phaseDescription = phaseDescription;
                    $(window).scrollTop(0);
                }
            };

            appvm.trackDownload = function (title, url, event, complexityName, type, version, phaseName, phaseId, templateId, referrer) {
               
            
                if (/\.net\//.test(url)) {
                    event.preventDefault();
                    SharedService.openModal('Template', title, url, complexityName);
                } else {
                    if (type === 'template') {
                        if (url && url.length) {
                            SharedService.trackTemplateView('Template', title, url.substring(url.indexOf('path'), url.length), complexityName, version, phaseName, phaseId, templateId, false, window.location.href, referrer);
                            // window.open(url.substring(url.indexOf('path'), url.length));
                        }


                    }

                }
            };
            $scope.$on('$destroy', function () {
                pinStatus();
            });

        })
        .controller('FeedbackCtrl', function ($scope, $uibModalInstance, FeedbackService, alerting, TOAST_MESSAGE, feedbackData) {
            var valid = true;
            $scope.isSubmit = false;
            $scope.color = '';
            $scope.formData = feedbackData;
            $scope.surveyAnswers = {};
            $scope.surveyAnswers.answers = {};
            $scope.addFeedback = function (formData) {

                $scope.isSubmit = true;
                formData.isSubmit = true;

                feedbackData.surveyQuestions.forEach(function (questionObj) {

                    if (questionObj.choice === '0') {
                        valid = false;

                    }
                    //else {
                    // valid = true;
                    //formData.isSubmit = true;
                    //}
                    // }
                })
                $scope.valid = valid;
                if (valid) {
                    FeedbackService.addSurvey(formData)
                        .success(function () {

                            alerting.addAlert('success', TOAST_MESSAGE.FEEDBACK_RECORDED);

                        });
                    $scope.cancel();
                }
                else {
                    alerting.addAlert('danger', TOAST_MESSAGE.NO_FEEDBACK_CHOICE);
                    valid = true;
                }
            };
            $scope.closeOverlay = function (e) {
                if (e.keyCode === 27) {
                    var links = angular.element('.navbar-nav')[0];
                    $($(links).find('li')[3]).find('a').focus();
                    $scope.cancel();
                }
            }
            $scope.weekCount = 2;

            $scope.askLater = function (weekCount) {
                var feedbackMsg = weekCount !== 1 ? weekCount + ' weeks' : '1 week';
                FeedbackService.addSurvey({ isSubmit: false, askAfter: weekCount })
                    .success(function () {
                        alerting.addAlert('success', TOAST_MESSAGE.FEEDBACK_REMINDER + feedbackMsg);
                    });
                $scope.cancel();
            };

            $scope.ok = function () {
                $uibModalInstance.close();
            };

            $scope.cancel = function (element) {
                $uibModalInstance.dismiss('cancel');
                if (element) {
                    angular.element(angular.element(element).find('.nav')[0]).find('a').focus();
                }

            };
        })
        .controller('openTileDescCtrl', function ($scope, $uibModalInstance, selectedItem) {
            $scope.selectedTemplate = selectedItem;

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('openOfflineCtrl', function ($scope, $uibModalInstance) {
            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
        })
        .controller('RatingCtrl', function ($scope, $rootScope, $location, $uibModalInstance, SharedService, alerting, TOAST_MESSAGE, selectedItem, UserService, profileService) {
            $scope.ratingData = angular.copy(selectedItem);
            $scope.originalData = selectedItem;
            $scope.title = selectedItem.title;
            $scope.placeholder = "Tell us why? (optional)";
            $scope.ratingYes = function (e) {
                $scope.ratingData.rating = true;
                $scope.placeholder = "Tell us why? (optional)";
            };

            $scope.ratingNo = function (e) {
                $scope.ratingData.rating = false;
                $scope.placeholder = "I'm changing my previous opinion. Document is no longer relevant as it doesn't reflect recent process changes."
            };

            $scope.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

            $scope.trackRating = function (ratingData, event) {
                var emailType = localStorage.getItem('userPhasName') === "null" ? localStorage.getItem('userMethodologyName') === "null" ? 1 : 1 : 2;
                //methodName: localStorage.getItem('userMethodologyName'), phaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'), emailType: emailType, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: null, url: window.location.href
                ratingData.isSubmit = true;
                var data = {
                    itemTypeId: 11,
                    title: $scope.originalData.title,
                    url: window.location.href,
                    version: $scope.originalData.version,
                    rating: ratingData.rating,
                    comment: ratingData.comment,
                    MethodName: localStorage.getItem('userMethodologyName') === "null" ? null : localStorage.getItem('userMethodologyName'),
                    PhaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'),
                    Domain: localStorage.getItem('userDomainName'),
                    Methodology: localStorage.getItem('userMethodologyName')
                };
                if (ratingData.rating === null || ratingData.rating === undefined) {
                    alerting.addAlert('info', TOAST_MESSAGE.NO_RATING_SELECTED);
                } else {
                    SharedService.logEvent('Rating', data);
                    if (JSON.parse(localStorage.getItem('userMethodologyId')) > 0) {
                        SharedService.sendUserFeedback({ methodId: JSON.parse(localStorage.getItem('userMethodologyId')), methodName: localStorage.getItem('userMethodologyName') === "null" ? null : localStorage.getItem('userMethodologyName'), phaseName: localStorage.getItem('userPhasName') === "null" ? null : localStorage.getItem('userPhasName'), phaseId: JSON.parse(localStorage.getItem('userPhasId')), emailType: emailType, contentRating: ratingData.rating, feedback: ratingData.comment, activityName: null, url: window.location.href }).success(function (res) {
                            if (res.status) {
                                alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                            }
                            else {
                                alerting.alert('danger', res.errorMessage)
                            }
                            $scope.cancel();
                        })
                    }
                    else {
                        alerting.addAlert('success', TOAST_MESSAGE.RATING_SUBMITTED);
                        $scope.cancel();
                    }
                }



            };


        });
    //.directive('ngBlur', function () {
    //    return {
    //        link: function (scope, element, attrs) {
    //            var viewLink = element[0].querySelector('.viewLink');
    //            viewLink.addEventListener('click', function (e) {
    //                var t = e.target;
    //                console.log(element[0].querySelector('.popover'));
    //                element[0].querySelector('.popover').bind('blur', function () {
    //                });

    //            });
    //        }
    //    }
    //});

})();

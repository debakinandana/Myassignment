﻿(function () {
    angular.module('sdmApp')
	.service('AutoCompleteService', function ($http, URLS) {
	    this.getAutoCompleteSearchList = function (titleVal) {
            return $http.get(URLS.autocomplete, {
	                    params: {
	                        q: titleVal
	                    }
	                });
	    };
	    
	});
})();
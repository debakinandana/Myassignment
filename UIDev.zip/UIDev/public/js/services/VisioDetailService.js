﻿(function () {
    angular.module('sdmApp')
	.service('VisioDetailService', function ($http, URLS) {
	    this.getVisioDetail = function (visioPath) {
	        return $http.get(URLS.visio, { params: { filename: visioPath } });
	        //return $http.get('https://sdmplusapi.azurewebsites.net/visio');
	    };

	    this.updateFavourite = function (data) {
	        return $http.patch(URLS.visio, data);
	    };
	    this.getActivityDescription = function (id) {
	        return $http.get(URLS.GetDynamicActivityContent, { params: { activityIdentifier: id } });
	    };

	});
})();
﻿angular.module('sdmApp')
	.service('DomainService', function ($http, URLS) {
	    this.getDomainMethodology = function () {
	        return $http.get(URLS.domains);
	    };

	    this.getUserPreference = function (selectedDomainId, selectedMethodologyId) {
	        return $http.get(URLS.userpreference + "?domainId=" +selectedDomainId + "&methodId=" + selectedMethodologyId);
	    };

	    this.updateUserPreference = function (data) {
	        var config = URLS.AntiforgeryConfig;
	        return $http.post(URLS.updateUserprefernce, data, config);
	    };
	    this.getUserDetail =function(){
	        return $http.get(URLS.profileUrl);
	    }
	});
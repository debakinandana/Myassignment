angular.module('sdmApp')
	.factory('URLS', function ($location) {
	    var urlModule = angular.module('sdmApp'),
            prod = true,
            URL = {},
            port = $location.port(),
            BASE_URL = '',
            instrumentationKey = 'b30b267f-045a-4961-ba9f-ae7e0a664877';
	    var instrumentationKeyList = [{
	        hostName: 'sdmplus-dev.azurewebsites.net',
	        instrumentationKey: 'cc03d068-3d54-4e9e-a637-4b2f872bd0ae'
	    }, {
	        hostName: 'sdmplus-test.azurewebsites.net',
	        instrumentationKey: '4757f7dd-ca68-4df8-8a9d-809f9e9c6146'
	    }, {
	        hostName: 'sdmplus-uat.azurewebsites.net',
	        instrumentationKey: '7de5309f-2195-46bd-a614-160d60f50204'
	    }, {
	        hostName: 'sdmplus.azurewebsites.net',
	        instrumentationKey: '872736d4-8dec-4b64-a447-9d63e370ccf0'
	    },
	    {
	        hostName: 'sdmplusdigi-dev.azurewebsites.net',
	        instrumentationKey: 'b30b267f-045a-4961-ba9f-ae7e0a664877'
	    }, {
	        hostName: 'sdmplusdigi-test.azurewebsites.net',
	        instrumentationKey: 'df48b277-4b80-417d-b67f-2167969d3bff'
	    }, {
	        hostName: 'sdmplusdigi-uat.azurewebsites.net',
	        instrumentationKey: '8ade9937-b2b7-47b4-8103-77134536a4c6'
	    }, {
	        hostName: 'sdmplusdigi.azurewebsites.net',
	        instrumentationKey: '757dd375-bb4b-4fc5-b457-584723cdd54f'
	    }, {
	        hostName: 'localhost',
	        instrumentationKey: '1f894d03-9e08-4db3-9ff8-41b1ab85a1ab'
	    }, {
	        hostName: 'sdmplusdev.azurewebsites.net',
	        instrumentationKey: 'f561c415-c692-4c21-a71d-8558ce50401a'
	    }, {
	        hostName: 'sdmplustest.azurewebsites.net',
	        instrumentationKey: '4091743e-60c1-435f-9c56-b0807c4275b4'
	    }, {
	        hostName: 'sdmplusuat.azurewebsites.net',
	        instrumentationKey: '71d3be0f-b9de-49a5-aabb-f407251336da'
	    }, {
	        hostName: 'sdmplusbackup.azurewebsites.net',
	        instrumentationKey: '692ab400-493b-400d-8fc2-61289d59d289'
	    }, {
	        hostName: "devsdmplus.azurewebsites.net",
	        instrumentationKey: "b51f7e05-2582-4cfc-aa21-9853a5b8021a",
	    }, {
	        hostName: "testsdmplus.azurewebsites.net",
	        instrumentationKey: "192cfb0b-f90d-4ecf-a456-4a019e4c537e",
	    }, {
	        hostName: "uatsdmplus.azurewebsites.net",
	        instrumentationKey: "564d17fc-dd64-43d1-88ff-9df3dd746ccf",
	    }]
	    if (port === 44300) {
	        BASE_URL = 'https://localhost:44300/';
	        //BASE_URL = 'https://sdmplusapi.azurewebsites.net/';
	    } else if ($location.host().indexOf('sdmplus-dev') > -1) {
	        BASE_URL = 'https://sdmplus-dev.azurewebsites.net/';
	        instrumentationKey = 'cc03d068-3d54-4e9e-a637-4b2f872bd0ae';
	    } else if ($location.host().indexOf('sdmplus-uat') > -1) {
	        BASE_URL = 'https://sdmplus-uat.azurewebsites.net/';
	        instrumentationKey = '7de5309f-2195-46bd-a614-160d60f50204';
	    } else if ($location.host().indexOf('sdmplus-test') > -1) {
	        BASE_URL = 'https://sdmplus-test.azurewebsites.net/';
	        instrumentationKey = '4757f7dd-ca68-4df8-8a9d-809f9e9c6146';
	    } else if ($location.host().indexOf('sdmplusperf') > -1) {
	        BASE_URL = 'https://sdmplusperf.azurewebsites.net/';
	        instrumentationKey = 'f6b0bcc0-e3af-4b48-9ee9-70ff0c84c244';
	    } else if ($location.host().indexOf('sdmplusdigi') > -1) {
	        BASE_URL = 'https://sdmplusdigi.azurewebsites.net/';
	        instrumentationKey = '757dd375-bb4b-4fc5-b457-584723cdd54f';
	    } else if ($location.host().indexOf('sdmplusdigi-dev') > -1) {
	        BASE_URL = 'https://sdmplusdigi-dev.azurewebsites.net/';
	        instrumentationKey = 'b30b267f-045a-4961-ba9f-ae7e0a664877';
	    } else if ($location.host().indexOf('sdmplusdigi-test') > -1) {
	        BASE_URL = 'https://sdmplusdigi-test.azurewebsites.net/';
	        instrumentationKey = 'df48b277-4b80-417d-b67f-2167969d3bff';
	    } else if ($location.host().indexOf('sdmplusdigi-uat') > -1) {
	        BASE_URL = 'https://sdmplusdigi-uat.azurewebsites.net/';
	        instrumentationKey = '8ade9937-b2b7-47b4-8103-77134536a4c6';
	    } else if ($location.host().indexOf('sdmplus') > -1) {
	        BASE_URL = 'https://sdmplus.azurewebsites.net/';
	        instrumentationKey = '872736d4-8dec-4b64-a447-9d63e370ccf0';
	    } else if ($location.host().indexOf('devsdmplus') > -1) {
	        BASE_URL = 'https://devsdmplus.azurewebsites.net/';
	        instrumentationKey = 'b51f7e05-2582-4cfc-aa21-9853a5b8021a';
	    } else if ($location.host().indexOf('testsdmplus') > -1) {
	        BASE_URL = 'https://testsdmplus.azurewebsites.net/';
	        instrumentationKey = '192cfb0b-f90d-4ecf-a456-4a019e4c537e';
	    } else if ($location.host().indexOf('uatsdmplus') > -1) {
	        BASE_URL = 'https://uatsdmplus.azurewebsites.net/';
	        instrumentationKey = '564d17fc-dd64-43d1-88ff-9df3dd746ccf';
	    } else {
	        //BASE_URL = 'https://sdmplusapi.azurewebsites.net/'
	        BASE_URL = 'https://flickering-fire-6339.firebaseio.com/';
	        prod = false;
	    }

	    //var urlsDev = {
	    //    profileUrl: BASE_URL + 'userInfo',
	    //    domains: BASE_URL + 'domains',
	    //    updateUserprefernce: BASE_URL + 'userInfo',
	    //    templates: BASE_URL + 'templates/',
	    //    downloads: BASE_URL + 'api/templates/download',
	    //    languages: BASE_URL + 'languages',
	    //    activities: BASE_URL + 'activities',
	    //    topics: BASE_URL + 'topics',
	    //    favorites: BASE_URL + 'favorites',
	    //    addfavourite: BASE_URL + 'api/favourite/add.json',
	    //    phases: BASE_URL + 'phases',
	    //    autocomplete: BASE_URL + 'autocomplete',
	    //    search: BASE_URL + 'search',
	    //    visio: BASE_URL + 'visio',
	    //    roles: BASE_URL + 'roles',
	    //    methodologyPhases: BASE_URL + 'phase',
	    //    survey: BASE_URL + 'survey',
	    //    visioactivities: BASE_URL + 'visioactivities'
	    //};
	    function getInstrumentationKey(currentHost) {
	        return instrumentationKeyList.filter(function (keyListObj, index) {
	            return keyListObj.hostName === currentHost ? instrumentationKeyList[index] : null;
	        })
	    }
	    var keyObj = getInstrumentationKey(location.hostname);
	    keyObj = keyObj.length > 0 ? keyObj[keyObj.length - 1] : {};
	    var urlsDev = {
	        profileUrl: BASE_URL + 'api/user/profile.json',
	        domains: BASE_URL + 'api/domains/.json',
	        updateUserprefernce: BASE_URL + 'api/user/update/.json',
	        updateWhatsnew: BASE_URL + 'api/user/updatewhatsnew/.json',
	        templates: BASE_URL + 'api/templates/.json',
	        downloads: BASE_URL + 'api/templates/download.json',
	        activities: BASE_URL + 'api/activities.json',
	        topics: BASE_URL + 'api/topics.json',
	        favorites: BASE_URL + 'api/favorites.json',
	        addfavourite: BASE_URL + 'api/favourite/add.json',
	        phases: BASE_URL + 'api/phases/.json',
	        autocomplete: BASE_URL + 'api/autocomplete.json',
	        search: BASE_URL + 'api/search.json',
	        visio: BASE_URL + 'api/visiopage.json',
	        roles: BASE_URL + 'api/roles.json',
	        methodologyPhases: BASE_URL + 'api/methodologies/.json',
	        survey: BASE_URL + 'api/survey.json',
	        whatsnew: BASE_URL + 'api/whatsnew.json',
	        sdmrefresh: BASE_URL + 'api/SDMRefresh.json',
	        visioactivities: BASE_URL + 'api/visioactivities.json',
	        templatesbyphase: BASE_URL + 'api/templates/templatesbyphase',
	        GetDynamicActivityContent: BASE_URL + '/api/activities/activityContent',
	        signout: BASE_URL + 'home/signout',
	        countries: BASE_URL + 'sdm/js/json/countries.js',
	        languages: BASE_URL + 'sdm/js/json/languages.js',
	        playbooks: BASE_URL + 'sdm/js/json/DePlaybooks.js',
	    };


	    var urlsProd = {
	        profileUrl: location.origin + '/api/user/profile',
	        domains: location.origin + '/api/domains/',
	        updateUserprefernce: location.origin + '/api/user/update/',
	        updateWhatsnew: location.origin + '/api/user/updatewhatsnew/',
	        templates: location.origin + '/api/templates/',
	        downloads: location.origin + '/api/templates/download',
	        activities: location.origin + '/api/activities',
	        topics: location.origin + '/api/topics',
	        favorites: location.origin + '/api/favorites',
	        addfavourite: location.origin + '/api/favourite/add',
	        phases: location.origin + '/api/phases/',
	        autocomplete: location.origin + '/api/autocomplete',
	        search: location.origin + '/api/search',
	        visio: location.origin + '/api/visiopage',
	        roles: location.origin + '/api/roles',
	        getMethodologies: location.origin + '/api/solutionmethods',
	        downloadMethodologies: location.origin + '/api/downloadword',
	        methodologyPhases: location.origin + '/api/methodologies/',
	        survey: location.origin + '/api/survey',
	        whatsnew: location.origin + '/api/whatsnew',
	        sdmrefresh: location.origin + '/api/SDMRefresh',
	        visioactivities: location.origin + '/api/visioactivities',
	        templatesbyphase: location.origin + '/api/templates/templatesbyphase',
	        signout: location.origin + '/home/signout',
	        adminTemplates: location.origin + '/api/admin/templates/',
	        adminActivities: location.origin + '/api/admin/activities/',
	        adminTopics: location.origin + '/api/admin/topics/',
	        adminRoles: location.origin + '/api/admin/roles',
	        adminMethods: location.origin + '/api/admin/methods',
	        adminPhases: location.origin + '/api/admin/phases',
	        adminLocalTemplates: location.origin + '/api/admin/locTemplates',
	        adminWhatsNew: location.origin + '/api/admin/whatsnew',
	        adminProcessGroups: location.origin + '/api/admin/processgroups',
	        adminSampleTemplates: location.origin + '/api/admin/sampletemplates',
	        retiredContent: location.origin + '/api/retiredmethods',
	        countries: location.origin + '/sdm/js/json/countries.js',
	        languages: location.origin + '/sdm/js/json/languages.js',
	        playbooks: location.origin + '/api/deplaybook',
	        solutionMethods: location.origin + '/sdm/js/json/solutionMethods.js',
	        GetDynamicActivityContent: location.origin + '/api/activities/activityContent',
	        userpreference: location.origin + '/api/load',
	        instrumentationKey: keyObj ? keyObj.instrumentationKey : "",
	        userActivityFeedBack: location.origin + '/api/activities/contentRatingFeedback',
	        complexity: location.origin + '/api/activities/projectcomplexity',
	        adminActivityAllVersionsJson: location.origin + '/api/admin/getAuditVersionRecord',
	        adminComplexity: location.origin + '/api/admin/adminprojectcomplexity',
	        adminPlayBookList: location.origin + '/api/admin/deplaybook',
	        admindActivityGrid: location.origin + '/api/admin/activitiesgrid',
	        admindActivityRACIGrid: location.origin + '/api/admin/activitiesracigrid',
	        adminActivityDomain: location.origin + '/api/admin/domains',
	        adminDownloadExcel: location.origin + '/api/admin/downloadexcel',
	        adminRACIDownloadExcel: location.origin + '/api/admin/downloadactivityraciexcel',
	        adminExcelMethods: location.origin + '/api/admin/excelmethods',
	        adminUploadExcel: location.origin + '/api/admin/jsonexcelsave',
	        adminTopicCategory: location.origin + '/api/admin/category',
	        adminFileToJson: location.origin + '/api/admin/jsonexcel',
	        adminToJson: location.origin + '/api/admin/jsondb',
	        adminSyncImages: location.origin + '/api/images',
	        siteRefresh: location.origin + '/api/CheckSiteRefreshing',
	        adminTopicVersions: location.origin + '/api/admin/GetTopicAuditVersionRecord',
	        AntiforgeryConfig: { headers: { '__RequestVerificationToken': angular.element("input[name='__RequestVerificationToken']").val() } },
	        sdmCampusUrl: 'https://microsoft.sharepoint.com/sites/campus/Pages/CampusSearch.aspx'
	    };

	    if (prod) {
	        URL = urlsProd;
	    }
	    else {
	        URL = urlsDev;
	    }

	    URL['prod'] = prod;

	    return URL;
	});


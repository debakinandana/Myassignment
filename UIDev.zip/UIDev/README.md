# Grunt build with Angular JS

- clean build directory
- concatenation js & css
- copy extra stuff like fonts, images, favicon.ico to build directory
- css minification
- js minification
- image minification
- js code linting 
- watching js, css, html, less file changes
- code versioning
- Angular JS code annotation

## Run Application

```
npm run dev
// http://localhost:5000
```

## Build Step

```
npm run build
```

**Note:**

Sourcemap have some problem with autoprefixer (gulp-pleeeese) so commented, un-comment for prefixing.

## Git Workflow

```
git clone -b SDMPlusUI_Rewrite/UITeam https://vsogd.visualstudio.com/DefaultCollection/SDMPlusRewrite/_git/SDMPlus_Main
// do some changes
git add --all
// add some history to your local 
git commit -m "1st commit"
git pull
git push origin master
```

## Resources

```
Demo - http://sdmdemo.azurewebsites.net/#/
API - http://sdmplusapi.azurewebsites.net/
```




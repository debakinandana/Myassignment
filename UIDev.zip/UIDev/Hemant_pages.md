﻿# Activity Pages

https://www.cssout.com/#step3

1382 - > 1506

1. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Submit%20Proposal.aspx
2. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_SetupProgramBoard.aspx
3. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_TeamCommunicationPlanning.aspx
4. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_TerminateEngagementorProject.aspx
5. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_TestSecurityThreats.aspx
6. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_TrackStatus.aspx
7. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_TransitiontoOperations.aspx
8. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Review-ReviseMSInternalTeam.aspx
9. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Review-ReviseProgramBoard.aspx
10. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_UpdateandCloseOutCOS.aspx
11. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_UpdateConfigurationDocumentation.aspx
12. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ValidateProductionSolutionPerformance.aspx
13. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_SetUpCampusWorkspace.aspx
14. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ValidateProgramExecutionPlan.aspx
15. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ValidateProject-WorkStreamClosure.aspx
16. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ValidateSkillsRequirements.aspx
17. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_SetupMSInternalTeam.aspx
18. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_VerifyMasterAgreement.aspx
19. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_BuildCubes.aspx
20. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_SetUpSolutionApproachVisionPlan.aspx
21. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_BuildDimensionalModel.aspx
22. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_BuildETLComponents.aspx
23. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_BuildPresentationComponentsReports.aspx
24. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ConductSecurityCodeReview.aspx
25. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ConductUsageTestingofETLandIntegration.aspx
26. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ConductUsageTestingofOLAPandDatabases.aspx
27. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ConductUsageTestingofPresentationandReports.aspx
28. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DefineInitialScopeWBS.aspx
29. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DesignModificationstoNetworkandStorage.aspx
30. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DesignModificationstoTechnicalInfrastructure.aspx
31. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DetermineInitialProjectResources.aspx
32. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DevelopInitialProjectSchedule.aspx
33. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DevelopProjectEstimates.aspx
34. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_DocumentRequirements.aspx
35. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_IdentifyandPrioritizeSubjectAreasfromEnterpriseRequirements.aspx
36. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_IdentifySourceSystemsandIntegrationPoints.aspx
37. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_LoadSampleData.aspx
38. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrioritizeBusinessRequirementswithSponsors.aspx
39. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrototypeCubeDesign.aspx
40. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrototypeDimensionalDesign.aspx
41. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrototypeETLDesign.aspx
42. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrototypePresentationDesign.aspx
43. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_PrototypeSecurityDesign.aspx
44. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ReviewCodeAndTestScripts.aspx
45. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ReviewNetworkandStorageArchitecture.aspx
46. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/subAct_ReviewWindowsTechnicalArchitecture.aspx
48. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_AuthorizeContract.MININT-3HN7D42.aspx
49. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_BuildSolution-MININT-3HN7D42.aspx
50. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_CaptureLessonsLearned-MININT-3HN7D42.aspx
 
1221 -> 1230

51. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldSteeringCommitteeMeetings.aspx
52. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldVisionScopeApprovedCheckpointReview.aspx
53. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Identify-CaptureIssues.aspx
54. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Identify-CaptureRisks.aspx
55. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Identify-CaptureRisksIssuesAssumptions.aspx
56. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_IdentifyInitialRisks.aspx
57. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Identify-InitiateProgramProcesses.aspx
58. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_IdentifyRisks.aspx
59. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_IdentifySuppliersToTheProgram.aspx
60. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ImplementBenefitsRealizationPlanActivities.aspx

1211 -> 1220

61. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldDeploymentCompleteCheckpointReview.aspx
62. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldEngagementLevelCOSDiscussion.aspx
63. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldFinalMSInternalTeamMeeting.aspx
64. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldFinalProgramBoardMeeting.aspx
65. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldInternalKickoffMeeting.aspx
66. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldProgramPlanningWorkshops.aspx
67. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldProjectPlanApprovedCheckpointReview.aspx
68. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldReleaseReadinessApprovedCheckpointReview.aspx
69. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldSalestoDeliveryHandoffMeeting.aspx
70. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldScopeCompleteCheckpointReview.aspx

1201 -> 1210

71. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GetApprovalsforNon-standardTerms.aspx
72. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GetComplexDealApprovedbyQA.aspx
73. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GetComplexDealReviewedApproved.aspx
74. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HandOverOutstandingRisks.aspx
75. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HandOverProjectArtifacts.aspx
76. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Harvest%20IP.aspx
77. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Hold%20Discovery%20Call.aspx
78. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Hold%20Kick-Off%20Meeting.aspx
79. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldCustomerKickoffMeeting.aspx
80. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_HoldDeliveryManagementInitiationCompleteCheckpointReview.aspx

1191-> 1200

81. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gateway1Review.aspx
82. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gateway2Review.aspx
83. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gateway3Review.aspx
84. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gateway4Review.aspx
85. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gateway5Review.aspx
86. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Gather%20Intelligence.aspx
87. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GatherAnalyzePrioritizeRequirementsandFeatures.aspx
88. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GatherCustomerRequirements.aspx
89. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GenerateBenefitsRealizationPlan.aspx
90. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_GenerateTheProgramBudget.aspx  

1182 -> 1190

91. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_EvaluateRisk.aspx
92. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ExecuteFinalProgramReviews.aspx
93. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ExecuteTheT-minusPlan.aspx
94. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_ExecuteTransitionPlans.aspx
95. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_Finalize%20Proposal.aspx
96. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_FinalizeProgramDocumentation.aspx
97. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_FinalizeTrainingMaterials.aspx
98. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_FinalReviewBeforeSubmissiontoCustomer.aspx
99. https://portal.sposites.com/sites/bizdesk/SDMPlusProd/SDM%20ActivityDL%20New/act_FinalSecuritySignoffReview.aspx


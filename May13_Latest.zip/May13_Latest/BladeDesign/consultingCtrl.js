(function () {
    function consultingCtrl($scope) {
        var consultvm = this;
       
        consultvm.getDetails = function () {

                document.getElementById('phases').removeAttribute('hidden');
                var jsonData = [
                {
                    "ID": "1",
                    "Name": "Sprint Planning",
                    "complexity": "ture",
                    "Price": "125.60"
                },
{
    "ID": "2",
    "Name": "Daily Scrums",
    "complexity": "false"

},
{
    "ID": "3",
    "Name": "Daily Team Member Activities",
    "complexity": "ture"

},
{
    "ID": "4",
    "Name": "Daily Team Working agreement",
    "complexity": "ture"

},
  {
      "ID": "5",
      "Name": "Envisioning Workshop",
      "complexity": "ture"

  },
   {
       "ID": "6",
       "Name": "Backlog Refinement Workshop",
       "complexity": "ture"

   },
   {
       "ID": "7",
       "Name": "Draft High-Level Solution Architecture",
       "complexity": "ture"

   },
   {
       "ID": "8",
       "Name": "Draft Security Strategy",
       "complexity": "ture"

   },

                ]

                $("#Name1").val(jsonData[0]['Name']);
                $("#Name2").val(jsonData[1]['Name']);
                $("#Name3").val(jsonData[2]['Name']);
                $("#Name4").val(jsonData[3]['Name']);
                $("#Name5").val(jsonData[3]['Name']);
                $("#Name6").val(jsonData[5]['Name']);
                $("#Name7").val(jsonData[6]['Name']);
                $("#Name8").val(jsonData[7]['Name']);
            }

        

    }
    angular.module("sdmApp").controller("consultingCtrl", consultingCtrl)
})();
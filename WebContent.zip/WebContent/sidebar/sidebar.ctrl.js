/**
 * Created by Srujana on 02-07-2016.
 */
mainApp.controller('sidebarController', function($scope,$localStorage,indexService,$rootScope) {
    this.one='';
    this.two='';
    this.three='';
    $scope.itemsOne = [{
        id: 0,
        label: '--Select Colour--'
    },{
        id: 1,
        label: 'Red'
    }, {
        id: 2,
        label: 'Yellow'
    },{
        id: 3,
        label: 'Green'
    },{
        id: 4,
        label: 'Blue'
    }];
    this.one=$scope.itemsOne[0];
    $scope.itemsTwo = [{
        id: 0,
        label: '--Select Colour--'
    },{
        id: 1,
        label: 'Red'
    }, {
        id: 2,
        label: 'Yellow'
    },{
        id: 3,
        label: 'Green'
    },{
        id: 4,
        label: 'Blue'
    }];
    this.two=$scope.itemsTwo[0];
    $scope.itemsThree = [{
        id: 0,
        label: '--Select Colour--'
    },{
        id: 1,
        label: 'Red'
    }, {
        id: 2,
        label: 'Yellow'
    },{
        id: 3,
        label: 'Green'
    },{
        id: 4,
        label: 'Blue'
    }];
    this.three=$scope.itemsThree[0];
    this.submit = function () {
        indexService.setDropDownOne(this.one);
        indexService.setDropDownTwo(this.two);
        indexService.setDropDownThree(this.three);
        $rootScope.OneValue=this.one.label;
        $rootScope.TwoValue=this.two.label;
        $rootScope.ThreeValue=this.three.label;
    }
});
/**
 * Created by e002239 on 7/1/2016.
 */
mainApp.controller('LoginController', function($scope,$localStorage, $sessionStorage,$location) {//we didnot use $sessionstorage here
    this.username;
    this.password;
    this.login = function () {
        //TODO do some authentication or call authentication service for login
        this.message='';
        alert(this.username+'  '+this.password);
        $localStorage.username = this.username;
        $location.path('/home');
    }
    $scope.message = "Login Page";
});
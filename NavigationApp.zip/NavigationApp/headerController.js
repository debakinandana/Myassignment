/**
 * Created by Srujana on 02-07-2016.
 */
mainApp.controller('headerController', function($scope,$location,$localStorage) {
    this.username = $localStorage.username;
});